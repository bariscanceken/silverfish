setblock ~42 ~0 ~-5 spruce_stairs[facing=south]
fill ~42 ~10 ~-5 ~42 ~12 ~-5 air
setblock ~43 ~0 ~-5 spruce_stairs[facing=south]
fill ~43 ~10 ~-5 ~43 ~12 ~-5 air
setblock ~44 ~0 ~-5 spruce_stairs[facing=south]
fill ~44 ~10 ~-5 ~44 ~12 ~-5 air
setblock ~42 ~1 ~-4 spruce_stairs[facing=south]
setblock ~42 ~0 ~-4 spruce_stairs[facing=north,half=top]
fill ~42 ~10 ~-4 ~42 ~12 ~-4 air
setblock ~43 ~1 ~-4 spruce_stairs[facing=south]
setblock ~43 ~0 ~-4 spruce_stairs[facing=north,half=top]
fill ~43 ~10 ~-4 ~43 ~12 ~-4 air
setblock ~44 ~1 ~-4 spruce_stairs[facing=south]
setblock ~44 ~0 ~-4 spruce_stairs[facing=north,half=top]
fill ~44 ~10 ~-4 ~44 ~12 ~-4 air
setblock ~42 ~2 ~-3 spruce_stairs[facing=south]
setblock ~42 ~1 ~-3 spruce_stairs[facing=north,half=top]
fill ~42 ~10 ~-3 ~42 ~12 ~-3 air
setblock ~43 ~2 ~-3 spruce_stairs[facing=south]
setblock ~43 ~1 ~-3 spruce_stairs[facing=north,half=top]
fill ~43 ~10 ~-3 ~43 ~12 ~-3 air
setblock ~44 ~2 ~-3 spruce_stairs[facing=south]
setblock ~44 ~1 ~-3 spruce_stairs[facing=north,half=top]
fill ~44 ~10 ~-3 ~44 ~12 ~-3 air
setblock ~42 ~3 ~-2 spruce_stairs[facing=south]
setblock ~42 ~2 ~-2 spruce_stairs[facing=north,half=top]
fill ~42 ~10 ~-2 ~42 ~12 ~-2 air
setblock ~43 ~3 ~-2 spruce_stairs[facing=south]
setblock ~43 ~2 ~-2 spruce_stairs[facing=north,half=top]
fill ~43 ~10 ~-2 ~43 ~12 ~-2 air
setblock ~44 ~3 ~-2 spruce_stairs[facing=south]
setblock ~44 ~2 ~-2 spruce_stairs[facing=north,half=top]
fill ~44 ~10 ~-2 ~44 ~12 ~-2 air
setblock ~42 ~4 ~-1 spruce_stairs[facing=south]
setblock ~42 ~3 ~-1 spruce_stairs[facing=north,half=top]
fill ~42 ~10 ~-1 ~42 ~12 ~-1 air
setblock ~43 ~4 ~-1 spruce_stairs[facing=south]
setblock ~43 ~3 ~-1 spruce_stairs[facing=north,half=top]
fill ~43 ~10 ~-1 ~43 ~12 ~-1 air
setblock ~44 ~4 ~-1 spruce_stairs[facing=south]
setblock ~44 ~3 ~-1 spruce_stairs[facing=north,half=top]
fill ~44 ~10 ~-1 ~44 ~12 ~-1 air
setblock ~42 ~5 ~0 spruce_stairs[facing=south]
setblock ~42 ~4 ~0 spruce_stairs[facing=north,half=top]
fill ~42 ~10 ~0 ~42 ~12 ~0 air
setblock ~43 ~5 ~0 spruce_stairs[facing=south]
setblock ~43 ~4 ~0 spruce_stairs[facing=north,half=top]
fill ~43 ~10 ~0 ~43 ~12 ~0 air
setblock ~44 ~5 ~0 spruce_stairs[facing=south]
setblock ~44 ~4 ~0 spruce_stairs[facing=north,half=top]
fill ~44 ~10 ~0 ~44 ~12 ~0 air
setblock ~42 ~6 ~1 spruce_stairs[facing=south]
setblock ~42 ~5 ~1 spruce_stairs[facing=north,half=top]
fill ~42 ~10 ~1 ~42 ~12 ~1 air
setblock ~43 ~6 ~1 spruce_stairs[facing=south]
setblock ~43 ~5 ~1 spruce_stairs[facing=north,half=top]
fill ~43 ~10 ~1 ~43 ~12 ~1 air
setblock ~44 ~6 ~1 spruce_stairs[facing=south]
setblock ~44 ~5 ~1 spruce_stairs[facing=north,half=top]
fill ~44 ~10 ~1 ~44 ~12 ~1 air
setblock ~42 ~7 ~2 spruce_stairs[facing=south]
setblock ~42 ~6 ~2 spruce_stairs[facing=north,half=top]
fill ~42 ~10 ~2 ~42 ~12 ~2 air
setblock ~43 ~7 ~2 spruce_stairs[facing=south]
setblock ~43 ~6 ~2 spruce_stairs[facing=north,half=top]
fill ~43 ~10 ~2 ~43 ~12 ~2 air
setblock ~44 ~7 ~2 spruce_stairs[facing=south]
setblock ~44 ~6 ~2 spruce_stairs[facing=north,half=top]
fill ~44 ~10 ~2 ~44 ~12 ~2 air
setblock ~42 ~8 ~3 spruce_stairs[facing=south]
setblock ~42 ~7 ~3 spruce_stairs[facing=north,half=top]
fill ~42 ~10 ~3 ~42 ~12 ~3 air
setblock ~43 ~8 ~3 spruce_stairs[facing=south]
setblock ~43 ~7 ~3 spruce_stairs[facing=north,half=top]
fill ~43 ~10 ~3 ~43 ~12 ~3 air
setblock ~44 ~8 ~3 spruce_stairs[facing=south]
setblock ~44 ~7 ~3 spruce_stairs[facing=north,half=top]
fill ~44 ~10 ~3 ~44 ~12 ~3 air
setblock ~42 ~9 ~4 spruce_stairs[facing=south]
setblock ~42 ~8 ~4 spruce_stairs[facing=north,half=top]
fill ~42 ~10 ~4 ~42 ~12 ~4 air
setblock ~43 ~9 ~4 spruce_stairs[facing=south]
setblock ~43 ~8 ~4 spruce_stairs[facing=north,half=top]
fill ~43 ~10 ~4 ~43 ~12 ~4 air
setblock ~44 ~9 ~4 spruce_stairs[facing=south]
setblock ~44 ~8 ~4 spruce_stairs[facing=north,half=top]
fill ~44 ~10 ~4 ~44 ~12 ~4 air
setblock ~42 ~10 ~5 spruce_stairs[facing=south]
setblock ~42 ~9 ~5 spruce_stairs[facing=north,half=top]
setblock ~43 ~10 ~5 spruce_stairs[facing=south]
setblock ~43 ~9 ~5 spruce_stairs[facing=north,half=top]
setblock ~44 ~10 ~5 spruce_stairs[facing=south]
setblock ~44 ~9 ~5 spruce_stairs[facing=north,half=top]
setblock ~45 ~10 ~-2 spruce_planks
setblock ~45 ~11 ~-2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~45 ~10 ~-1 spruce_planks
setblock ~45 ~11 ~-1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~45 ~10 ~4 spruce_planks
setblock ~45 ~11 ~4 glass_pane[north=true,south=false,west=false,east=false]
setblock ~45 ~10 ~1 spruce_planks
setblock ~45 ~11 ~1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~41 ~10 ~-6 spruce_planks
setblock ~41 ~11 ~-6 glass_pane[north=false,south=true,west=false,east=true]
setblock ~41 ~10 ~-3 spruce_planks
setblock ~41 ~11 ~-3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~43 ~10 ~-6 spruce_planks
setblock ~43 ~11 ~-6 glass_pane[north=false,south=false,west=true,east=true]
setblock ~41 ~10 ~0 spruce_planks
setblock ~41 ~11 ~0 glass_pane[north=true,south=true,west=false,east=false]
setblock ~41 ~10 ~3 spruce_planks
setblock ~41 ~11 ~3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~45 ~10 ~-3 spruce_planks
setblock ~45 ~11 ~-3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~45 ~10 ~-6 spruce_planks
setblock ~45 ~11 ~-6 glass_pane[north=false,south=true,west=true,east=false]
setblock ~45 ~10 ~0 spruce_planks
setblock ~45 ~11 ~0 glass_pane[north=true,south=true,west=false,east=false]
setblock ~45 ~10 ~3 spruce_planks
setblock ~45 ~11 ~3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~41 ~10 ~-4 spruce_planks
setblock ~41 ~11 ~-4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~41 ~10 ~2 spruce_planks
setblock ~41 ~11 ~2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~45 ~10 ~-4 spruce_planks
setblock ~45 ~11 ~-4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~45 ~10 ~2 spruce_planks
setblock ~45 ~11 ~2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~41 ~10 ~-5 spruce_planks
setblock ~41 ~11 ~-5 glass_pane[north=true,south=true,west=false,east=false]
setblock ~42 ~10 ~-6 spruce_planks
setblock ~42 ~11 ~-6 glass_pane[north=false,south=false,west=true,east=true]
setblock ~41 ~10 ~-2 spruce_planks
setblock ~41 ~11 ~-2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~41 ~10 ~-1 spruce_planks
setblock ~41 ~11 ~-1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~41 ~10 ~4 spruce_planks
setblock ~41 ~11 ~4 glass_pane[north=true,south=false,west=false,east=false]
setblock ~44 ~10 ~-6 spruce_planks
setblock ~44 ~11 ~-6 glass_pane[north=false,south=false,west=true,east=true]
setblock ~41 ~10 ~1 spruce_planks
setblock ~41 ~11 ~1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~45 ~10 ~-5 spruce_planks
setblock ~45 ~11 ~-5 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-44 ~0 ~5 spruce_stairs[facing=north]
fill ~-44 ~10 ~5 ~-44 ~12 ~5 air
setblock ~-43 ~0 ~5 spruce_stairs[facing=north]
fill ~-43 ~10 ~5 ~-43 ~12 ~5 air
setblock ~-42 ~0 ~5 spruce_stairs[facing=north]
fill ~-42 ~10 ~5 ~-42 ~12 ~5 air
setblock ~-44 ~1 ~4 spruce_stairs[facing=north]
setblock ~-44 ~0 ~4 spruce_stairs[facing=south,half=top]
fill ~-44 ~10 ~4 ~-44 ~12 ~4 air
setblock ~-43 ~1 ~4 spruce_stairs[facing=north]
setblock ~-43 ~0 ~4 spruce_stairs[facing=south,half=top]
fill ~-43 ~10 ~4 ~-43 ~12 ~4 air
setblock ~-42 ~1 ~4 spruce_stairs[facing=north]
setblock ~-42 ~0 ~4 spruce_stairs[facing=south,half=top]
fill ~-42 ~10 ~4 ~-42 ~12 ~4 air
setblock ~-44 ~2 ~3 spruce_stairs[facing=north]
setblock ~-44 ~1 ~3 spruce_stairs[facing=south,half=top]
fill ~-44 ~10 ~3 ~-44 ~12 ~3 air
setblock ~-43 ~2 ~3 spruce_stairs[facing=north]
setblock ~-43 ~1 ~3 spruce_stairs[facing=south,half=top]
fill ~-43 ~10 ~3 ~-43 ~12 ~3 air
setblock ~-42 ~2 ~3 spruce_stairs[facing=north]
setblock ~-42 ~1 ~3 spruce_stairs[facing=south,half=top]
fill ~-42 ~10 ~3 ~-42 ~12 ~3 air
setblock ~-44 ~3 ~2 spruce_stairs[facing=north]
setblock ~-44 ~2 ~2 spruce_stairs[facing=south,half=top]
fill ~-44 ~10 ~2 ~-44 ~12 ~2 air
setblock ~-43 ~3 ~2 spruce_stairs[facing=north]
setblock ~-43 ~2 ~2 spruce_stairs[facing=south,half=top]
fill ~-43 ~10 ~2 ~-43 ~12 ~2 air
setblock ~-42 ~3 ~2 spruce_stairs[facing=north]
setblock ~-42 ~2 ~2 spruce_stairs[facing=south,half=top]
fill ~-42 ~10 ~2 ~-42 ~12 ~2 air
setblock ~-44 ~4 ~1 spruce_stairs[facing=north]
setblock ~-44 ~3 ~1 spruce_stairs[facing=south,half=top]
fill ~-44 ~10 ~1 ~-44 ~12 ~1 air
setblock ~-43 ~4 ~1 spruce_stairs[facing=north]
setblock ~-43 ~3 ~1 spruce_stairs[facing=south,half=top]
fill ~-43 ~10 ~1 ~-43 ~12 ~1 air
setblock ~-42 ~4 ~1 spruce_stairs[facing=north]
setblock ~-42 ~3 ~1 spruce_stairs[facing=south,half=top]
fill ~-42 ~10 ~1 ~-42 ~12 ~1 air
setblock ~-44 ~5 ~0 spruce_stairs[facing=north]
setblock ~-44 ~4 ~0 spruce_stairs[facing=south,half=top]
fill ~-44 ~10 ~0 ~-44 ~12 ~0 air
setblock ~-43 ~5 ~0 spruce_stairs[facing=north]
setblock ~-43 ~4 ~0 spruce_stairs[facing=south,half=top]
fill ~-43 ~10 ~0 ~-43 ~12 ~0 air
setblock ~-42 ~5 ~0 spruce_stairs[facing=north]
setblock ~-42 ~4 ~0 spruce_stairs[facing=south,half=top]
fill ~-42 ~10 ~0 ~-42 ~12 ~0 air
setblock ~-44 ~6 ~-1 spruce_stairs[facing=north]
setblock ~-44 ~5 ~-1 spruce_stairs[facing=south,half=top]
fill ~-44 ~10 ~-1 ~-44 ~12 ~-1 air
setblock ~-43 ~6 ~-1 spruce_stairs[facing=north]
setblock ~-43 ~5 ~-1 spruce_stairs[facing=south,half=top]
fill ~-43 ~10 ~-1 ~-43 ~12 ~-1 air
setblock ~-42 ~6 ~-1 spruce_stairs[facing=north]
setblock ~-42 ~5 ~-1 spruce_stairs[facing=south,half=top]
fill ~-42 ~10 ~-1 ~-42 ~12 ~-1 air
setblock ~-44 ~7 ~-2 spruce_stairs[facing=north]
setblock ~-44 ~6 ~-2 spruce_stairs[facing=south,half=top]
fill ~-44 ~10 ~-2 ~-44 ~12 ~-2 air
setblock ~-43 ~7 ~-2 spruce_stairs[facing=north]
setblock ~-43 ~6 ~-2 spruce_stairs[facing=south,half=top]
fill ~-43 ~10 ~-2 ~-43 ~12 ~-2 air
setblock ~-42 ~7 ~-2 spruce_stairs[facing=north]
setblock ~-42 ~6 ~-2 spruce_stairs[facing=south,half=top]
fill ~-42 ~10 ~-2 ~-42 ~12 ~-2 air
setblock ~-44 ~8 ~-3 spruce_stairs[facing=north]
setblock ~-44 ~7 ~-3 spruce_stairs[facing=south,half=top]
fill ~-44 ~10 ~-3 ~-44 ~12 ~-3 air
setblock ~-43 ~8 ~-3 spruce_stairs[facing=north]
setblock ~-43 ~7 ~-3 spruce_stairs[facing=south,half=top]
fill ~-43 ~10 ~-3 ~-43 ~12 ~-3 air
setblock ~-42 ~8 ~-3 spruce_stairs[facing=north]
setblock ~-42 ~7 ~-3 spruce_stairs[facing=south,half=top]
fill ~-42 ~10 ~-3 ~-42 ~12 ~-3 air
setblock ~-44 ~9 ~-4 spruce_stairs[facing=north]
setblock ~-44 ~8 ~-4 spruce_stairs[facing=south,half=top]
fill ~-44 ~10 ~-4 ~-44 ~12 ~-4 air
setblock ~-43 ~9 ~-4 spruce_stairs[facing=north]
setblock ~-43 ~8 ~-4 spruce_stairs[facing=south,half=top]
fill ~-43 ~10 ~-4 ~-43 ~12 ~-4 air
setblock ~-42 ~9 ~-4 spruce_stairs[facing=north]
setblock ~-42 ~8 ~-4 spruce_stairs[facing=south,half=top]
fill ~-42 ~10 ~-4 ~-42 ~12 ~-4 air
setblock ~-44 ~10 ~-5 spruce_stairs[facing=north]
setblock ~-44 ~9 ~-5 spruce_stairs[facing=south,half=top]
setblock ~-43 ~10 ~-5 spruce_stairs[facing=north]
setblock ~-43 ~9 ~-5 spruce_stairs[facing=south,half=top]
setblock ~-42 ~10 ~-5 spruce_stairs[facing=north]
setblock ~-42 ~9 ~-5 spruce_stairs[facing=south,half=top]
setblock ~-41 ~10 ~-1 spruce_planks
setblock ~-41 ~11 ~-1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-41 ~10 ~-2 spruce_planks
setblock ~-41 ~11 ~-2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-41 ~10 ~1 spruce_planks
setblock ~-41 ~11 ~1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-41 ~10 ~4 spruce_planks
setblock ~-41 ~11 ~4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-45 ~10 ~-3 spruce_planks
setblock ~-45 ~11 ~-3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-45 ~10 ~0 spruce_planks
setblock ~-45 ~11 ~0 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-45 ~10 ~3 spruce_planks
setblock ~-45 ~11 ~3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-45 ~10 ~6 spruce_planks
setblock ~-45 ~11 ~6 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-41 ~10 ~-3 spruce_planks
setblock ~-41 ~11 ~-3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-41 ~10 ~0 spruce_planks
setblock ~-41 ~11 ~0 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-43 ~10 ~6 spruce_planks
setblock ~-43 ~11 ~6 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-41 ~10 ~3 spruce_planks
setblock ~-41 ~11 ~3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-41 ~10 ~6 spruce_planks
setblock ~-41 ~11 ~6 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-45 ~10 ~-4 spruce_planks
setblock ~-45 ~11 ~-4 glass_pane[north=false,south=true,west=false,east=false]
setblock ~-45 ~10 ~2 spruce_planks
setblock ~-45 ~11 ~2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-45 ~10 ~5 spruce_planks
setblock ~-45 ~11 ~5 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-41 ~10 ~-4 spruce_planks
setblock ~-41 ~11 ~-4 glass_pane[north=false,south=true,west=false,east=false]
setblock ~-41 ~10 ~2 spruce_planks
setblock ~-41 ~11 ~2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-41 ~10 ~5 spruce_planks
setblock ~-41 ~11 ~5 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-44 ~10 ~6 spruce_planks
setblock ~-44 ~11 ~6 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-45 ~10 ~-1 spruce_planks
setblock ~-45 ~11 ~-1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-45 ~10 ~4 spruce_planks
setblock ~-45 ~11 ~4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-45 ~10 ~-2 spruce_planks
setblock ~-45 ~11 ~-2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-45 ~10 ~1 spruce_planks
setblock ~-45 ~11 ~1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-42 ~10 ~6 spruce_planks
setblock ~-42 ~11 ~6 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-4 ~11 ~-44 spruce_stairs[facing=east]
fill ~-4 ~18 ~-44 ~-4 ~20 ~-44 air
setblock ~-4 ~11 ~-43 spruce_stairs[facing=east]
fill ~-4 ~18 ~-43 ~-4 ~20 ~-43 air
setblock ~-4 ~11 ~-42 spruce_stairs[facing=east]
fill ~-4 ~18 ~-42 ~-4 ~20 ~-42 air
setblock ~-3 ~12 ~-44 spruce_stairs[facing=east]
setblock ~-3 ~11 ~-44 spruce_stairs[facing=west,half=top]
fill ~-3 ~18 ~-44 ~-3 ~20 ~-44 air
setblock ~-3 ~12 ~-43 spruce_stairs[facing=east]
setblock ~-3 ~11 ~-43 spruce_stairs[facing=west,half=top]
fill ~-3 ~18 ~-43 ~-3 ~20 ~-43 air
setblock ~-3 ~12 ~-42 spruce_stairs[facing=east]
setblock ~-3 ~11 ~-42 spruce_stairs[facing=west,half=top]
fill ~-3 ~18 ~-42 ~-3 ~20 ~-42 air
setblock ~-2 ~13 ~-44 spruce_stairs[facing=east]
setblock ~-2 ~12 ~-44 spruce_stairs[facing=west,half=top]
fill ~-2 ~18 ~-44 ~-2 ~20 ~-44 air
setblock ~-2 ~13 ~-43 spruce_stairs[facing=east]
setblock ~-2 ~12 ~-43 spruce_stairs[facing=west,half=top]
fill ~-2 ~18 ~-43 ~-2 ~20 ~-43 air
setblock ~-2 ~13 ~-42 spruce_stairs[facing=east]
setblock ~-2 ~12 ~-42 spruce_stairs[facing=west,half=top]
fill ~-2 ~18 ~-42 ~-2 ~20 ~-42 air
setblock ~-1 ~14 ~-44 spruce_stairs[facing=east]
setblock ~-1 ~13 ~-44 spruce_stairs[facing=west,half=top]
fill ~-1 ~18 ~-44 ~-1 ~20 ~-44 air
setblock ~-1 ~14 ~-43 spruce_stairs[facing=east]
setblock ~-1 ~13 ~-43 spruce_stairs[facing=west,half=top]
fill ~-1 ~18 ~-43 ~-1 ~20 ~-43 air
setblock ~-1 ~14 ~-42 spruce_stairs[facing=east]
setblock ~-1 ~13 ~-42 spruce_stairs[facing=west,half=top]
fill ~-1 ~18 ~-42 ~-1 ~20 ~-42 air
setblock ~0 ~15 ~-44 spruce_stairs[facing=east]
setblock ~0 ~14 ~-44 spruce_stairs[facing=west,half=top]
fill ~0 ~18 ~-44 ~0 ~20 ~-44 air
setblock ~0 ~15 ~-43 spruce_stairs[facing=east]
setblock ~0 ~14 ~-43 spruce_stairs[facing=west,half=top]
fill ~0 ~18 ~-43 ~0 ~20 ~-43 air
setblock ~0 ~15 ~-42 spruce_stairs[facing=east]
setblock ~0 ~14 ~-42 spruce_stairs[facing=west,half=top]
fill ~0 ~18 ~-42 ~0 ~20 ~-42 air
setblock ~1 ~16 ~-44 spruce_stairs[facing=east]
setblock ~1 ~15 ~-44 spruce_stairs[facing=west,half=top]
fill ~1 ~18 ~-44 ~1 ~20 ~-44 air
setblock ~1 ~16 ~-43 spruce_stairs[facing=east]
setblock ~1 ~15 ~-43 spruce_stairs[facing=west,half=top]
fill ~1 ~18 ~-43 ~1 ~20 ~-43 air
setblock ~1 ~16 ~-42 spruce_stairs[facing=east]
setblock ~1 ~15 ~-42 spruce_stairs[facing=west,half=top]
fill ~1 ~18 ~-42 ~1 ~20 ~-42 air
setblock ~2 ~17 ~-44 spruce_stairs[facing=east]
setblock ~2 ~16 ~-44 spruce_stairs[facing=west,half=top]
fill ~2 ~18 ~-44 ~2 ~20 ~-44 air
setblock ~2 ~17 ~-43 spruce_stairs[facing=east]
setblock ~2 ~16 ~-43 spruce_stairs[facing=west,half=top]
fill ~2 ~18 ~-43 ~2 ~20 ~-43 air
setblock ~2 ~17 ~-42 spruce_stairs[facing=east]
setblock ~2 ~16 ~-42 spruce_stairs[facing=west,half=top]
fill ~2 ~18 ~-42 ~2 ~20 ~-42 air
setblock ~3 ~18 ~-44 spruce_stairs[facing=east]
setblock ~3 ~17 ~-44 spruce_stairs[facing=west,half=top]
setblock ~3 ~18 ~-43 spruce_stairs[facing=east]
setblock ~3 ~17 ~-43 spruce_stairs[facing=west,half=top]
setblock ~3 ~18 ~-42 spruce_stairs[facing=east]
setblock ~3 ~17 ~-42 spruce_stairs[facing=west,half=top]
setblock ~-4 ~18 ~-41 spruce_planks
setblock ~-4 ~19 ~-41 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-2 ~18 ~-41 spruce_planks
setblock ~-2 ~19 ~-41 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-1 ~18 ~-41 spruce_planks
setblock ~-1 ~19 ~-41 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-5 ~18 ~-43 spruce_planks
setblock ~-5 ~19 ~-43 glass_pane[north=true,south=true,west=false,east=false]
setblock ~2 ~18 ~-41 spruce_planks
setblock ~2 ~19 ~-41 glass_pane[north=false,south=false,west=true,east=false]
setblock ~0 ~18 ~-41 spruce_planks
setblock ~0 ~19 ~-41 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-4 ~18 ~-45 spruce_planks
setblock ~-4 ~19 ~-45 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-2 ~18 ~-45 spruce_planks
setblock ~-2 ~19 ~-45 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-1 ~18 ~-45 spruce_planks
setblock ~-1 ~19 ~-45 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-5 ~18 ~-44 spruce_planks
setblock ~-5 ~19 ~-44 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-3 ~18 ~-41 spruce_planks
setblock ~-3 ~19 ~-41 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-5 ~18 ~-41 spruce_planks
setblock ~-5 ~19 ~-41 glass_pane[north=true,south=false,west=false,east=true]
setblock ~0 ~18 ~-45 spruce_planks
setblock ~0 ~19 ~-45 glass_pane[north=false,south=false,west=true,east=true]
setblock ~2 ~18 ~-45 spruce_planks
setblock ~2 ~19 ~-45 glass_pane[north=false,south=false,west=true,east=false]
setblock ~1 ~18 ~-41 spruce_planks
setblock ~1 ~19 ~-41 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-5 ~18 ~-45 spruce_planks
setblock ~-5 ~19 ~-45 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-5 ~18 ~-42 spruce_planks
setblock ~-5 ~19 ~-42 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-3 ~18 ~-45 spruce_planks
setblock ~-3 ~19 ~-45 glass_pane[north=false,south=false,west=true,east=true]
setblock ~1 ~18 ~-45 spruce_planks
setblock ~1 ~19 ~-45 glass_pane[north=false,south=false,west=true,east=true]
setblock ~4 ~11 ~42 spruce_stairs[facing=west]
fill ~4 ~18 ~42 ~4 ~20 ~42 air
setblock ~4 ~11 ~43 spruce_stairs[facing=west]
fill ~4 ~18 ~43 ~4 ~20 ~43 air
setblock ~4 ~11 ~44 spruce_stairs[facing=west]
fill ~4 ~18 ~44 ~4 ~20 ~44 air
setblock ~3 ~12 ~42 spruce_stairs[facing=west]
setblock ~3 ~11 ~42 spruce_stairs[facing=east,half=top]
fill ~3 ~18 ~42 ~3 ~20 ~42 air
setblock ~3 ~12 ~43 spruce_stairs[facing=west]
setblock ~3 ~11 ~43 spruce_stairs[facing=east,half=top]
fill ~3 ~18 ~43 ~3 ~20 ~43 air
setblock ~3 ~12 ~44 spruce_stairs[facing=west]
setblock ~3 ~11 ~44 spruce_stairs[facing=east,half=top]
fill ~3 ~18 ~44 ~3 ~20 ~44 air
setblock ~2 ~13 ~42 spruce_stairs[facing=west]
setblock ~2 ~12 ~42 spruce_stairs[facing=east,half=top]
fill ~2 ~18 ~42 ~2 ~20 ~42 air
setblock ~2 ~13 ~43 spruce_stairs[facing=west]
setblock ~2 ~12 ~43 spruce_stairs[facing=east,half=top]
fill ~2 ~18 ~43 ~2 ~20 ~43 air
setblock ~2 ~13 ~44 spruce_stairs[facing=west]
setblock ~2 ~12 ~44 spruce_stairs[facing=east,half=top]
fill ~2 ~18 ~44 ~2 ~20 ~44 air
setblock ~1 ~14 ~42 spruce_stairs[facing=west]
setblock ~1 ~13 ~42 spruce_stairs[facing=east,half=top]
fill ~1 ~18 ~42 ~1 ~20 ~42 air
setblock ~1 ~14 ~43 spruce_stairs[facing=west]
setblock ~1 ~13 ~43 spruce_stairs[facing=east,half=top]
fill ~1 ~18 ~43 ~1 ~20 ~43 air
setblock ~1 ~14 ~44 spruce_stairs[facing=west]
setblock ~1 ~13 ~44 spruce_stairs[facing=east,half=top]
fill ~1 ~18 ~44 ~1 ~20 ~44 air
setblock ~0 ~15 ~42 spruce_stairs[facing=west]
setblock ~0 ~14 ~42 spruce_stairs[facing=east,half=top]
fill ~0 ~18 ~42 ~0 ~20 ~42 air
setblock ~0 ~15 ~43 spruce_stairs[facing=west]
setblock ~0 ~14 ~43 spruce_stairs[facing=east,half=top]
fill ~0 ~18 ~43 ~0 ~20 ~43 air
setblock ~0 ~15 ~44 spruce_stairs[facing=west]
setblock ~0 ~14 ~44 spruce_stairs[facing=east,half=top]
fill ~0 ~18 ~44 ~0 ~20 ~44 air
setblock ~-1 ~16 ~42 spruce_stairs[facing=west]
setblock ~-1 ~15 ~42 spruce_stairs[facing=east,half=top]
fill ~-1 ~18 ~42 ~-1 ~20 ~42 air
setblock ~-1 ~16 ~43 spruce_stairs[facing=west]
setblock ~-1 ~15 ~43 spruce_stairs[facing=east,half=top]
fill ~-1 ~18 ~43 ~-1 ~20 ~43 air
setblock ~-1 ~16 ~44 spruce_stairs[facing=west]
setblock ~-1 ~15 ~44 spruce_stairs[facing=east,half=top]
fill ~-1 ~18 ~44 ~-1 ~20 ~44 air
setblock ~-2 ~17 ~42 spruce_stairs[facing=west]
setblock ~-2 ~16 ~42 spruce_stairs[facing=east,half=top]
fill ~-2 ~18 ~42 ~-2 ~20 ~42 air
setblock ~-2 ~17 ~43 spruce_stairs[facing=west]
setblock ~-2 ~16 ~43 spruce_stairs[facing=east,half=top]
fill ~-2 ~18 ~43 ~-2 ~20 ~43 air
setblock ~-2 ~17 ~44 spruce_stairs[facing=west]
setblock ~-2 ~16 ~44 spruce_stairs[facing=east,half=top]
fill ~-2 ~18 ~44 ~-2 ~20 ~44 air
setblock ~-3 ~18 ~42 spruce_stairs[facing=west]
setblock ~-3 ~17 ~42 spruce_stairs[facing=east,half=top]
setblock ~-3 ~18 ~43 spruce_stairs[facing=west]
setblock ~-3 ~17 ~43 spruce_stairs[facing=east,half=top]
setblock ~-3 ~18 ~44 spruce_stairs[facing=west]
setblock ~-3 ~17 ~44 spruce_stairs[facing=east,half=top]
setblock ~0 ~18 ~45 spruce_planks
setblock ~0 ~19 ~45 glass_pane[north=false,south=false,west=true,east=true]
setblock ~2 ~18 ~45 spruce_planks
setblock ~2 ~19 ~45 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-2 ~18 ~41 spruce_planks
setblock ~-2 ~19 ~41 glass_pane[north=false,south=false,west=false,east=true]
setblock ~-1 ~18 ~41 spruce_planks
setblock ~-1 ~19 ~41 glass_pane[north=false,south=false,west=true,east=true]
setblock ~4 ~18 ~45 spruce_planks
setblock ~4 ~19 ~45 glass_pane[north=false,south=false,west=true,east=true]
setblock ~5 ~18 ~43 spruce_planks
setblock ~5 ~19 ~43 glass_pane[north=true,south=true,west=false,east=false]
setblock ~0 ~18 ~41 spruce_planks
setblock ~0 ~19 ~41 glass_pane[north=false,south=false,west=true,east=true]
setblock ~2 ~18 ~41 spruce_planks
setblock ~2 ~19 ~41 glass_pane[north=false,south=false,west=true,east=true]
setblock ~1 ~18 ~45 spruce_planks
setblock ~1 ~19 ~45 glass_pane[north=false,south=false,west=true,east=true]
setblock ~4 ~18 ~41 spruce_planks
setblock ~4 ~19 ~41 glass_pane[north=false,south=false,west=true,east=true]
setblock ~3 ~18 ~45 spruce_planks
setblock ~3 ~19 ~45 glass_pane[north=false,south=false,west=true,east=true]
setblock ~5 ~18 ~42 spruce_planks
setblock ~5 ~19 ~42 glass_pane[north=true,south=true,west=false,east=false]
setblock ~5 ~18 ~45 spruce_planks
setblock ~5 ~19 ~45 glass_pane[north=true,south=false,west=true,east=false]
setblock ~1 ~18 ~41 spruce_planks
setblock ~1 ~19 ~41 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-1 ~18 ~45 spruce_planks
setblock ~-1 ~19 ~45 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-2 ~18 ~45 spruce_planks
setblock ~-2 ~19 ~45 glass_pane[north=false,south=false,west=false,east=true]
setblock ~3 ~18 ~41 spruce_planks
setblock ~3 ~19 ~41 glass_pane[north=false,south=false,west=true,east=true]
setblock ~5 ~18 ~44 spruce_planks
setblock ~5 ~19 ~44 glass_pane[north=true,south=true,west=false,east=false]
setblock ~5 ~18 ~41 spruce_planks
setblock ~5 ~19 ~41 glass_pane[north=false,south=true,west=true,east=false]
setblock ~42 ~19 ~-4 spruce_stairs[facing=south]
fill ~42 ~26 ~-4 ~42 ~28 ~-4 air
setblock ~43 ~19 ~-4 spruce_stairs[facing=south]
fill ~43 ~26 ~-4 ~43 ~28 ~-4 air
setblock ~44 ~19 ~-4 spruce_stairs[facing=south]
fill ~44 ~26 ~-4 ~44 ~28 ~-4 air
setblock ~42 ~20 ~-3 spruce_stairs[facing=south]
setblock ~42 ~19 ~-3 spruce_stairs[facing=north,half=top]
fill ~42 ~26 ~-3 ~42 ~28 ~-3 air
setblock ~43 ~20 ~-3 spruce_stairs[facing=south]
setblock ~43 ~19 ~-3 spruce_stairs[facing=north,half=top]
fill ~43 ~26 ~-3 ~43 ~28 ~-3 air
setblock ~44 ~20 ~-3 spruce_stairs[facing=south]
setblock ~44 ~19 ~-3 spruce_stairs[facing=north,half=top]
fill ~44 ~26 ~-3 ~44 ~28 ~-3 air
setblock ~42 ~21 ~-2 spruce_stairs[facing=south]
setblock ~42 ~20 ~-2 spruce_stairs[facing=north,half=top]
fill ~42 ~26 ~-2 ~42 ~28 ~-2 air
setblock ~43 ~21 ~-2 spruce_stairs[facing=south]
setblock ~43 ~20 ~-2 spruce_stairs[facing=north,half=top]
fill ~43 ~26 ~-2 ~43 ~28 ~-2 air
setblock ~44 ~21 ~-2 spruce_stairs[facing=south]
setblock ~44 ~20 ~-2 spruce_stairs[facing=north,half=top]
fill ~44 ~26 ~-2 ~44 ~28 ~-2 air
setblock ~42 ~22 ~-1 spruce_stairs[facing=south]
setblock ~42 ~21 ~-1 spruce_stairs[facing=north,half=top]
fill ~42 ~26 ~-1 ~42 ~28 ~-1 air
setblock ~43 ~22 ~-1 spruce_stairs[facing=south]
setblock ~43 ~21 ~-1 spruce_stairs[facing=north,half=top]
fill ~43 ~26 ~-1 ~43 ~28 ~-1 air
setblock ~44 ~22 ~-1 spruce_stairs[facing=south]
setblock ~44 ~21 ~-1 spruce_stairs[facing=north,half=top]
fill ~44 ~26 ~-1 ~44 ~28 ~-1 air
setblock ~42 ~23 ~0 spruce_stairs[facing=south]
setblock ~42 ~22 ~0 spruce_stairs[facing=north,half=top]
fill ~42 ~26 ~0 ~42 ~28 ~0 air
setblock ~43 ~23 ~0 spruce_stairs[facing=south]
setblock ~43 ~22 ~0 spruce_stairs[facing=north,half=top]
fill ~43 ~26 ~0 ~43 ~28 ~0 air
setblock ~44 ~23 ~0 spruce_stairs[facing=south]
setblock ~44 ~22 ~0 spruce_stairs[facing=north,half=top]
fill ~44 ~26 ~0 ~44 ~28 ~0 air
setblock ~42 ~24 ~1 spruce_stairs[facing=south]
setblock ~42 ~23 ~1 spruce_stairs[facing=north,half=top]
fill ~42 ~26 ~1 ~42 ~28 ~1 air
setblock ~43 ~24 ~1 spruce_stairs[facing=south]
setblock ~43 ~23 ~1 spruce_stairs[facing=north,half=top]
fill ~43 ~26 ~1 ~43 ~28 ~1 air
setblock ~44 ~24 ~1 spruce_stairs[facing=south]
setblock ~44 ~23 ~1 spruce_stairs[facing=north,half=top]
fill ~44 ~26 ~1 ~44 ~28 ~1 air
setblock ~42 ~25 ~2 spruce_stairs[facing=south]
setblock ~42 ~24 ~2 spruce_stairs[facing=north,half=top]
fill ~42 ~26 ~2 ~42 ~28 ~2 air
setblock ~43 ~25 ~2 spruce_stairs[facing=south]
setblock ~43 ~24 ~2 spruce_stairs[facing=north,half=top]
fill ~43 ~26 ~2 ~43 ~28 ~2 air
setblock ~44 ~25 ~2 spruce_stairs[facing=south]
setblock ~44 ~24 ~2 spruce_stairs[facing=north,half=top]
fill ~44 ~26 ~2 ~44 ~28 ~2 air
setblock ~42 ~26 ~3 spruce_stairs[facing=south]
setblock ~42 ~25 ~3 spruce_stairs[facing=north,half=top]
setblock ~43 ~26 ~3 spruce_stairs[facing=south]
setblock ~43 ~25 ~3 spruce_stairs[facing=north,half=top]
setblock ~44 ~26 ~3 spruce_stairs[facing=south]
setblock ~44 ~25 ~3 spruce_stairs[facing=north,half=top]
setblock ~45 ~26 ~-2 spruce_planks
setblock ~45 ~27 ~-2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~45 ~26 ~-1 spruce_planks
setblock ~45 ~27 ~-1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~45 ~26 ~1 spruce_planks
setblock ~45 ~27 ~1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~41 ~26 ~-3 spruce_planks
setblock ~41 ~27 ~-3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~41 ~26 ~0 spruce_planks
setblock ~41 ~27 ~0 glass_pane[north=true,south=true,west=false,east=false]
setblock ~45 ~26 ~-3 spruce_planks
setblock ~45 ~27 ~-3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~45 ~26 ~0 spruce_planks
setblock ~45 ~27 ~0 glass_pane[north=true,south=true,west=false,east=false]
setblock ~42 ~26 ~-5 spruce_planks
setblock ~42 ~27 ~-5 glass_pane[north=false,south=false,west=true,east=true]
setblock ~44 ~26 ~-5 spruce_planks
setblock ~44 ~27 ~-5 glass_pane[north=false,south=false,west=true,east=true]
setblock ~41 ~26 ~-4 spruce_planks
setblock ~41 ~27 ~-4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~41 ~26 ~2 spruce_planks
setblock ~41 ~27 ~2 glass_pane[north=true,south=false,west=false,east=false]
setblock ~45 ~26 ~-4 spruce_planks
setblock ~45 ~27 ~-4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~45 ~26 ~2 spruce_planks
setblock ~45 ~27 ~2 glass_pane[north=true,south=false,west=false,east=false]
setblock ~41 ~26 ~-5 spruce_planks
setblock ~41 ~27 ~-5 glass_pane[north=false,south=true,west=false,east=true]
setblock ~41 ~26 ~-2 spruce_planks
setblock ~41 ~27 ~-2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~41 ~26 ~-1 spruce_planks
setblock ~41 ~27 ~-1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~43 ~26 ~-5 spruce_planks
setblock ~43 ~27 ~-5 glass_pane[north=false,south=false,west=true,east=true]
setblock ~41 ~26 ~1 spruce_planks
setblock ~41 ~27 ~1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~45 ~26 ~-5 spruce_planks
setblock ~45 ~27 ~-5 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-44 ~19 ~4 spruce_stairs[facing=north]
fill ~-44 ~26 ~4 ~-44 ~28 ~4 air
setblock ~-43 ~19 ~4 spruce_stairs[facing=north]
fill ~-43 ~26 ~4 ~-43 ~28 ~4 air
setblock ~-42 ~19 ~4 spruce_stairs[facing=north]
fill ~-42 ~26 ~4 ~-42 ~28 ~4 air
setblock ~-44 ~20 ~3 spruce_stairs[facing=north]
setblock ~-44 ~19 ~3 spruce_stairs[facing=south,half=top]
fill ~-44 ~26 ~3 ~-44 ~28 ~3 air
setblock ~-43 ~20 ~3 spruce_stairs[facing=north]
setblock ~-43 ~19 ~3 spruce_stairs[facing=south,half=top]
fill ~-43 ~26 ~3 ~-43 ~28 ~3 air
setblock ~-42 ~20 ~3 spruce_stairs[facing=north]
setblock ~-42 ~19 ~3 spruce_stairs[facing=south,half=top]
fill ~-42 ~26 ~3 ~-42 ~28 ~3 air
setblock ~-44 ~21 ~2 spruce_stairs[facing=north]
setblock ~-44 ~20 ~2 spruce_stairs[facing=south,half=top]
fill ~-44 ~26 ~2 ~-44 ~28 ~2 air
setblock ~-43 ~21 ~2 spruce_stairs[facing=north]
setblock ~-43 ~20 ~2 spruce_stairs[facing=south,half=top]
fill ~-43 ~26 ~2 ~-43 ~28 ~2 air
setblock ~-42 ~21 ~2 spruce_stairs[facing=north]
setblock ~-42 ~20 ~2 spruce_stairs[facing=south,half=top]
fill ~-42 ~26 ~2 ~-42 ~28 ~2 air
setblock ~-44 ~22 ~1 spruce_stairs[facing=north]
setblock ~-44 ~21 ~1 spruce_stairs[facing=south,half=top]
fill ~-44 ~26 ~1 ~-44 ~28 ~1 air
setblock ~-43 ~22 ~1 spruce_stairs[facing=north]
setblock ~-43 ~21 ~1 spruce_stairs[facing=south,half=top]
fill ~-43 ~26 ~1 ~-43 ~28 ~1 air
setblock ~-42 ~22 ~1 spruce_stairs[facing=north]
setblock ~-42 ~21 ~1 spruce_stairs[facing=south,half=top]
fill ~-42 ~26 ~1 ~-42 ~28 ~1 air
setblock ~-44 ~23 ~0 spruce_stairs[facing=north]
setblock ~-44 ~22 ~0 spruce_stairs[facing=south,half=top]
fill ~-44 ~26 ~0 ~-44 ~28 ~0 air
setblock ~-43 ~23 ~0 spruce_stairs[facing=north]
setblock ~-43 ~22 ~0 spruce_stairs[facing=south,half=top]
fill ~-43 ~26 ~0 ~-43 ~28 ~0 air
setblock ~-42 ~23 ~0 spruce_stairs[facing=north]
setblock ~-42 ~22 ~0 spruce_stairs[facing=south,half=top]
fill ~-42 ~26 ~0 ~-42 ~28 ~0 air
setblock ~-44 ~24 ~-1 spruce_stairs[facing=north]
setblock ~-44 ~23 ~-1 spruce_stairs[facing=south,half=top]
fill ~-44 ~26 ~-1 ~-44 ~28 ~-1 air
setblock ~-43 ~24 ~-1 spruce_stairs[facing=north]
setblock ~-43 ~23 ~-1 spruce_stairs[facing=south,half=top]
fill ~-43 ~26 ~-1 ~-43 ~28 ~-1 air
setblock ~-42 ~24 ~-1 spruce_stairs[facing=north]
setblock ~-42 ~23 ~-1 spruce_stairs[facing=south,half=top]
fill ~-42 ~26 ~-1 ~-42 ~28 ~-1 air
setblock ~-44 ~25 ~-2 spruce_stairs[facing=north]
setblock ~-44 ~24 ~-2 spruce_stairs[facing=south,half=top]
fill ~-44 ~26 ~-2 ~-44 ~28 ~-2 air
setblock ~-43 ~25 ~-2 spruce_stairs[facing=north]
setblock ~-43 ~24 ~-2 spruce_stairs[facing=south,half=top]
fill ~-43 ~26 ~-2 ~-43 ~28 ~-2 air
setblock ~-42 ~25 ~-2 spruce_stairs[facing=north]
setblock ~-42 ~24 ~-2 spruce_stairs[facing=south,half=top]
fill ~-42 ~26 ~-2 ~-42 ~28 ~-2 air
setblock ~-44 ~26 ~-3 spruce_stairs[facing=north]
setblock ~-44 ~25 ~-3 spruce_stairs[facing=south,half=top]
setblock ~-43 ~26 ~-3 spruce_stairs[facing=north]
setblock ~-43 ~25 ~-3 spruce_stairs[facing=south,half=top]
setblock ~-42 ~26 ~-3 spruce_stairs[facing=north]
setblock ~-42 ~25 ~-3 spruce_stairs[facing=south,half=top]
setblock ~-41 ~26 ~-1 spruce_planks
setblock ~-41 ~27 ~-1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-41 ~26 ~-2 spruce_planks
setblock ~-41 ~27 ~-2 glass_pane[north=false,south=true,west=false,east=false]
setblock ~-44 ~26 ~5 spruce_planks
setblock ~-44 ~27 ~5 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-41 ~26 ~1 spruce_planks
setblock ~-41 ~27 ~1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-41 ~26 ~4 spruce_planks
setblock ~-41 ~27 ~4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-45 ~26 ~0 spruce_planks
setblock ~-45 ~27 ~0 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-45 ~26 ~3 spruce_planks
setblock ~-45 ~27 ~3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-42 ~26 ~5 spruce_planks
setblock ~-42 ~27 ~5 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-41 ~26 ~0 spruce_planks
setblock ~-41 ~27 ~0 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-41 ~26 ~3 spruce_planks
setblock ~-41 ~27 ~3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-45 ~26 ~2 spruce_planks
setblock ~-45 ~27 ~2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-45 ~26 ~5 spruce_planks
setblock ~-45 ~27 ~5 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-43 ~26 ~5 spruce_planks
setblock ~-43 ~27 ~5 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-41 ~26 ~2 spruce_planks
setblock ~-41 ~27 ~2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-41 ~26 ~5 spruce_planks
setblock ~-41 ~27 ~5 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-45 ~26 ~-1 spruce_planks
setblock ~-45 ~27 ~-1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-45 ~26 ~4 spruce_planks
setblock ~-45 ~27 ~4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-45 ~26 ~-2 spruce_planks
setblock ~-45 ~27 ~-2 glass_pane[north=false,south=true,west=false,east=false]
setblock ~-45 ~26 ~1 spruce_planks
setblock ~-45 ~27 ~1 glass_pane[north=true,south=true,west=false,east=false]
