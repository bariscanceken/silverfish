fill ~-10 ~-1 ~-57 ~10 ~-1 ~-57 smooth_stone
fill ~-15 ~-1 ~-56 ~15 ~-1 ~-56 smooth_stone
fill ~-18 ~-1 ~-55 ~18 ~-1 ~-55 smooth_stone
fill ~-21 ~-1 ~-54 ~21 ~-1 ~-54 smooth_stone
fill ~-23 ~-1 ~-53 ~23 ~-1 ~-53 smooth_stone
fill ~-25 ~-1 ~-52 ~25 ~-1 ~-52 smooth_stone
fill ~-27 ~-1 ~-51 ~27 ~-1 ~-51 smooth_stone
fill ~-29 ~-1 ~-50 ~29 ~-1 ~-50 smooth_stone
fill ~-31 ~-1 ~-49 ~31 ~-1 ~-49 smooth_stone
fill ~-32 ~-1 ~-48 ~32 ~-1 ~-48 smooth_stone
fill ~-33 ~-1 ~-47 ~33 ~-1 ~-47 smooth_stone
fill ~-35 ~-1 ~-46 ~35 ~-1 ~-46 smooth_stone
fill ~-36 ~-1 ~-45 ~36 ~-1 ~-45 smooth_stone
fill ~-37 ~-1 ~-44 ~37 ~-1 ~-44 smooth_stone
fill ~-38 ~-1 ~-43 ~38 ~-1 ~-43 smooth_stone
fill ~-39 ~-1 ~-42 ~39 ~-1 ~-42 smooth_stone
fill ~-41 ~-1 ~-41 ~41 ~-1 ~-41 smooth_stone
fill ~-41 ~-1 ~-40 ~41 ~-1 ~-40 smooth_stone
fill ~-42 ~-1 ~-39 ~42 ~-1 ~-39 smooth_stone
fill ~-43 ~-1 ~-38 ~43 ~-1 ~-38 smooth_stone
fill ~-44 ~-1 ~-37 ~44 ~-1 ~-37 smooth_stone
fill ~-45 ~-1 ~-36 ~45 ~-1 ~-36 smooth_stone
fill ~-46 ~-1 ~-35 ~46 ~-1 ~-35 smooth_stone
fill ~-46 ~-1 ~-34 ~46 ~-1 ~-34 smooth_stone
fill ~-47 ~-1 ~-33 ~47 ~-1 ~-33 smooth_stone
fill ~-48 ~-1 ~-32 ~48 ~-1 ~-32 smooth_stone
fill ~-49 ~-1 ~-31 ~49 ~-1 ~-31 smooth_stone
fill ~-49 ~-1 ~-30 ~49 ~-1 ~-30 smooth_stone
fill ~-50 ~-1 ~-29 ~50 ~-1 ~-29 smooth_stone
fill ~-50 ~-1 ~-28 ~50 ~-1 ~-28 smooth_stone
fill ~-51 ~-1 ~-27 ~51 ~-1 ~-27 smooth_stone
fill ~-51 ~-1 ~-26 ~51 ~-1 ~-26 smooth_stone
fill ~-52 ~-1 ~-25 ~52 ~-1 ~-25 smooth_stone
fill ~-52 ~-1 ~-24 ~52 ~-1 ~-24 smooth_stone
fill ~-53 ~-1 ~-23 ~53 ~-1 ~-23 smooth_stone
fill ~-53 ~-1 ~-22 ~53 ~-1 ~-22 smooth_stone
fill ~-54 ~-1 ~-21 ~54 ~-1 ~-21 smooth_stone
fill ~-54 ~-1 ~-20 ~54 ~-1 ~-20 smooth_stone
fill ~-54 ~-1 ~-19 ~54 ~-1 ~-19 smooth_stone
fill ~-55 ~-1 ~-18 ~55 ~-1 ~-18 smooth_stone
fill ~-55 ~-1 ~-17 ~55 ~-1 ~-17 smooth_stone
fill ~-55 ~-1 ~-16 ~55 ~-1 ~-16 smooth_stone
fill ~-56 ~-1 ~-15 ~56 ~-1 ~-15 smooth_stone
fill ~-56 ~-1 ~-14 ~56 ~-1 ~-14 smooth_stone
fill ~-56 ~-1 ~-13 ~56 ~-1 ~-13 smooth_stone
fill ~-56 ~-1 ~-12 ~56 ~-1 ~-12 smooth_stone
fill ~-56 ~-1 ~-11 ~56 ~-1 ~-11 smooth_stone
fill ~-57 ~-1 ~-10 ~57 ~-1 ~-10 smooth_stone
fill ~-57 ~-1 ~-9 ~57 ~-1 ~-9 smooth_stone
fill ~-57 ~-1 ~-8 ~57 ~-1 ~-8 smooth_stone
fill ~-57 ~-1 ~-7 ~57 ~-1 ~-7 smooth_stone
fill ~-57 ~-1 ~-6 ~57 ~-1 ~-6 smooth_stone
fill ~-57 ~-1 ~-5 ~57 ~-1 ~-5 smooth_stone
fill ~-57 ~-1 ~-4 ~57 ~-1 ~-4 smooth_stone
fill ~-57 ~-1 ~-3 ~57 ~-1 ~-3 smooth_stone
fill ~-57 ~-1 ~-2 ~57 ~-1 ~-2 smooth_stone
fill ~-57 ~-1 ~-1 ~57 ~-1 ~-1 smooth_stone
fill ~-57 ~-1 ~0 ~57 ~-1 ~0 smooth_stone
fill ~-57 ~-1 ~1 ~57 ~-1 ~1 smooth_stone
fill ~-57 ~-1 ~2 ~57 ~-1 ~2 smooth_stone
fill ~-57 ~-1 ~3 ~57 ~-1 ~3 smooth_stone
fill ~-57 ~-1 ~4 ~57 ~-1 ~4 smooth_stone
fill ~-57 ~-1 ~5 ~57 ~-1 ~5 smooth_stone
fill ~-57 ~-1 ~6 ~57 ~-1 ~6 smooth_stone
fill ~-57 ~-1 ~7 ~57 ~-1 ~7 smooth_stone
fill ~-57 ~-1 ~8 ~57 ~-1 ~8 smooth_stone
fill ~-57 ~-1 ~9 ~57 ~-1 ~9 smooth_stone
fill ~-57 ~-1 ~10 ~57 ~-1 ~10 smooth_stone
fill ~-56 ~-1 ~11 ~56 ~-1 ~11 smooth_stone
fill ~-56 ~-1 ~12 ~56 ~-1 ~12 smooth_stone
fill ~-56 ~-1 ~13 ~56 ~-1 ~13 smooth_stone
fill ~-56 ~-1 ~14 ~56 ~-1 ~14 smooth_stone
fill ~-56 ~-1 ~15 ~56 ~-1 ~15 smooth_stone
fill ~-55 ~-1 ~16 ~55 ~-1 ~16 smooth_stone
fill ~-55 ~-1 ~17 ~55 ~-1 ~17 smooth_stone
fill ~-55 ~-1 ~18 ~55 ~-1 ~18 smooth_stone
fill ~-54 ~-1 ~19 ~54 ~-1 ~19 smooth_stone
fill ~-54 ~-1 ~20 ~54 ~-1 ~20 smooth_stone
fill ~-54 ~-1 ~21 ~54 ~-1 ~21 smooth_stone
fill ~-53 ~-1 ~22 ~53 ~-1 ~22 smooth_stone
fill ~-53 ~-1 ~23 ~53 ~-1 ~23 smooth_stone
fill ~-52 ~-1 ~24 ~52 ~-1 ~24 smooth_stone
fill ~-52 ~-1 ~25 ~52 ~-1 ~25 smooth_stone
fill ~-51 ~-1 ~26 ~51 ~-1 ~26 smooth_stone
fill ~-51 ~-1 ~27 ~51 ~-1 ~27 smooth_stone
fill ~-50 ~-1 ~28 ~50 ~-1 ~28 smooth_stone
fill ~-50 ~-1 ~29 ~50 ~-1 ~29 smooth_stone
fill ~-49 ~-1 ~30 ~49 ~-1 ~30 smooth_stone
fill ~-49 ~-1 ~31 ~49 ~-1 ~31 smooth_stone
fill ~-48 ~-1 ~32 ~48 ~-1 ~32 smooth_stone
fill ~-47 ~-1 ~33 ~47 ~-1 ~33 smooth_stone
fill ~-46 ~-1 ~34 ~46 ~-1 ~34 smooth_stone
fill ~-46 ~-1 ~35 ~46 ~-1 ~35 smooth_stone
fill ~-45 ~-1 ~36 ~45 ~-1 ~36 smooth_stone
fill ~-44 ~-1 ~37 ~44 ~-1 ~37 smooth_stone
fill ~-43 ~-1 ~38 ~43 ~-1 ~38 smooth_stone
fill ~-42 ~-1 ~39 ~42 ~-1 ~39 smooth_stone
fill ~-41 ~-1 ~40 ~41 ~-1 ~40 smooth_stone
fill ~-41 ~-1 ~41 ~41 ~-1 ~41 smooth_stone
fill ~-39 ~-1 ~42 ~39 ~-1 ~42 smooth_stone
fill ~-38 ~-1 ~43 ~38 ~-1 ~43 smooth_stone
fill ~-37 ~-1 ~44 ~37 ~-1 ~44 smooth_stone
fill ~-36 ~-1 ~45 ~36 ~-1 ~45 smooth_stone
fill ~-35 ~-1 ~46 ~35 ~-1 ~46 smooth_stone
fill ~-33 ~-1 ~47 ~33 ~-1 ~47 smooth_stone
fill ~-32 ~-1 ~48 ~32 ~-1 ~48 smooth_stone
fill ~-31 ~-1 ~49 ~31 ~-1 ~49 smooth_stone
fill ~-29 ~-1 ~50 ~29 ~-1 ~50 smooth_stone
fill ~-27 ~-1 ~51 ~27 ~-1 ~51 smooth_stone
fill ~-25 ~-1 ~52 ~25 ~-1 ~52 smooth_stone
fill ~-23 ~-1 ~53 ~23 ~-1 ~53 smooth_stone
fill ~-21 ~-1 ~54 ~21 ~-1 ~54 smooth_stone
fill ~-18 ~-1 ~55 ~18 ~-1 ~55 smooth_stone
fill ~-15 ~-1 ~56 ~15 ~-1 ~56 smooth_stone
fill ~-10 ~-1 ~57 ~10 ~-1 ~57 smooth_stone
fill ~-8 ~-1 ~-48 ~8 ~-1 ~-48 spruce_planks
fill ~-13 ~-1 ~-47 ~13 ~-1 ~-47 spruce_planks
fill ~-16 ~-1 ~-46 ~16 ~-1 ~-46 spruce_planks
fill ~-18 ~-1 ~-45 ~18 ~-1 ~-45 spruce_planks
fill ~-21 ~-1 ~-44 ~21 ~-1 ~-44 spruce_planks
fill ~-23 ~-1 ~-43 ~23 ~-1 ~-43 spruce_planks
fill ~-24 ~-1 ~-42 ~24 ~-1 ~-42 spruce_planks
fill ~-26 ~-1 ~-41 ~26 ~-1 ~-41 spruce_planks
fill ~-27 ~-1 ~-40 ~27 ~-1 ~-40 spruce_planks
fill ~-29 ~-1 ~-39 ~29 ~-1 ~-39 spruce_planks
fill ~-30 ~-1 ~-38 ~30 ~-1 ~-38 spruce_planks
fill ~-31 ~-1 ~-37 ~31 ~-1 ~-37 spruce_planks
fill ~-32 ~-1 ~-36 ~32 ~-1 ~-36 spruce_planks
fill ~-34 ~-1 ~-35 ~34 ~-1 ~-35 spruce_planks
fill ~-35 ~-1 ~-34 ~35 ~-1 ~-34 spruce_planks
fill ~-35 ~-1 ~-33 ~35 ~-1 ~-33 spruce_planks
fill ~-36 ~-1 ~-32 ~36 ~-1 ~-32 spruce_planks
fill ~-37 ~-1 ~-31 ~37 ~-1 ~-31 spruce_planks
fill ~-38 ~-1 ~-30 ~38 ~-1 ~-30 spruce_planks
fill ~-39 ~-1 ~-29 ~39 ~-1 ~-29 spruce_planks
fill ~-39 ~-1 ~-28 ~39 ~-1 ~-28 spruce_planks
fill ~-40 ~-1 ~-27 ~40 ~-1 ~-27 spruce_planks
fill ~-41 ~-1 ~-26 ~41 ~-1 ~-26 spruce_planks
fill ~-41 ~-1 ~-25 ~41 ~-1 ~-25 spruce_planks
fill ~-42 ~-1 ~-24 ~42 ~-1 ~-24 spruce_planks
fill ~-43 ~-1 ~-23 ~43 ~-1 ~-23 spruce_planks
fill ~-43 ~-1 ~-22 ~43 ~-1 ~-22 spruce_planks
fill ~-44 ~-1 ~-21 ~44 ~-1 ~-21 spruce_planks
fill ~-44 ~-1 ~-20 ~44 ~-1 ~-20 spruce_planks
fill ~-44 ~-1 ~-19 ~44 ~-1 ~-19 spruce_planks
fill ~-45 ~-1 ~-18 ~45 ~-1 ~-18 spruce_planks
fill ~-45 ~-1 ~-17 ~45 ~-1 ~-17 spruce_planks
fill ~-46 ~-1 ~-16 ~46 ~-1 ~-16 spruce_planks
fill ~-46 ~-1 ~-15 ~46 ~-1 ~-15 spruce_planks
fill ~-46 ~-1 ~-14 ~46 ~-1 ~-14 spruce_planks
fill ~-47 ~-1 ~-13 ~47 ~-1 ~-13 spruce_planks
fill ~-47 ~-1 ~-12 ~47 ~-1 ~-12 spruce_planks
fill ~-47 ~-1 ~-11 ~47 ~-1 ~-11 spruce_planks
fill ~-47 ~-1 ~-10 ~47 ~-1 ~-10 spruce_planks
fill ~-47 ~-1 ~-9 ~47 ~-1 ~-9 spruce_planks
fill ~-48 ~-1 ~-8 ~48 ~-1 ~-8 spruce_planks
fill ~-48 ~-1 ~-7 ~48 ~-1 ~-7 spruce_planks
fill ~-48 ~-1 ~-6 ~48 ~-1 ~-6 spruce_planks
fill ~-48 ~-1 ~-5 ~48 ~-1 ~-5 spruce_planks
fill ~-48 ~-1 ~-4 ~48 ~-1 ~-4 spruce_planks
fill ~-48 ~-1 ~-3 ~48 ~-1 ~-3 spruce_planks
fill ~-48 ~-1 ~-2 ~48 ~-1 ~-2 spruce_planks
fill ~-48 ~-1 ~-1 ~48 ~-1 ~-1 spruce_planks
fill ~-48 ~-1 ~0 ~48 ~-1 ~0 spruce_planks
fill ~-48 ~-1 ~1 ~48 ~-1 ~1 spruce_planks
fill ~-48 ~-1 ~2 ~48 ~-1 ~2 spruce_planks
fill ~-48 ~-1 ~3 ~48 ~-1 ~3 spruce_planks
fill ~-48 ~-1 ~4 ~48 ~-1 ~4 spruce_planks
fill ~-48 ~-1 ~5 ~48 ~-1 ~5 spruce_planks
fill ~-48 ~-1 ~6 ~48 ~-1 ~6 spruce_planks
fill ~-48 ~-1 ~7 ~48 ~-1 ~7 spruce_planks
fill ~-48 ~-1 ~8 ~48 ~-1 ~8 spruce_planks
fill ~-47 ~-1 ~9 ~47 ~-1 ~9 spruce_planks
fill ~-47 ~-1 ~10 ~47 ~-1 ~10 spruce_planks
fill ~-47 ~-1 ~11 ~47 ~-1 ~11 spruce_planks
fill ~-47 ~-1 ~12 ~47 ~-1 ~12 spruce_planks
fill ~-47 ~-1 ~13 ~47 ~-1 ~13 spruce_planks
fill ~-46 ~-1 ~14 ~46 ~-1 ~14 spruce_planks
fill ~-46 ~-1 ~15 ~46 ~-1 ~15 spruce_planks
fill ~-46 ~-1 ~16 ~46 ~-1 ~16 spruce_planks
fill ~-45 ~-1 ~17 ~45 ~-1 ~17 spruce_planks
fill ~-45 ~-1 ~18 ~45 ~-1 ~18 spruce_planks
fill ~-44 ~-1 ~19 ~44 ~-1 ~19 spruce_planks
fill ~-44 ~-1 ~20 ~44 ~-1 ~20 spruce_planks
fill ~-44 ~-1 ~21 ~44 ~-1 ~21 spruce_planks
fill ~-43 ~-1 ~22 ~43 ~-1 ~22 spruce_planks
fill ~-43 ~-1 ~23 ~43 ~-1 ~23 spruce_planks
fill ~-42 ~-1 ~24 ~42 ~-1 ~24 spruce_planks
fill ~-41 ~-1 ~25 ~41 ~-1 ~25 spruce_planks
fill ~-41 ~-1 ~26 ~41 ~-1 ~26 spruce_planks
fill ~-40 ~-1 ~27 ~40 ~-1 ~27 spruce_planks
fill ~-39 ~-1 ~28 ~39 ~-1 ~28 spruce_planks
fill ~-39 ~-1 ~29 ~39 ~-1 ~29 spruce_planks
fill ~-38 ~-1 ~30 ~38 ~-1 ~30 spruce_planks
fill ~-37 ~-1 ~31 ~37 ~-1 ~31 spruce_planks
fill ~-36 ~-1 ~32 ~36 ~-1 ~32 spruce_planks
fill ~-35 ~-1 ~33 ~35 ~-1 ~33 spruce_planks
fill ~-35 ~-1 ~34 ~35 ~-1 ~34 spruce_planks
fill ~-34 ~-1 ~35 ~34 ~-1 ~35 spruce_planks
fill ~-32 ~-1 ~36 ~32 ~-1 ~36 spruce_planks
fill ~-31 ~-1 ~37 ~31 ~-1 ~37 spruce_planks
fill ~-30 ~-1 ~38 ~30 ~-1 ~38 spruce_planks
fill ~-29 ~-1 ~39 ~29 ~-1 ~39 spruce_planks
fill ~-27 ~-1 ~40 ~27 ~-1 ~40 spruce_planks
fill ~-26 ~-1 ~41 ~26 ~-1 ~41 spruce_planks
fill ~-24 ~-1 ~42 ~24 ~-1 ~42 spruce_planks
fill ~-23 ~-1 ~43 ~23 ~-1 ~43 spruce_planks
fill ~-21 ~-1 ~44 ~21 ~-1 ~44 spruce_planks
fill ~-18 ~-1 ~45 ~18 ~-1 ~45 spruce_planks
fill ~-16 ~-1 ~46 ~16 ~-1 ~46 spruce_planks
fill ~-13 ~-1 ~47 ~13 ~-1 ~47 spruce_planks
fill ~-8 ~-1 ~48 ~8 ~-1 ~48 spruce_planks
setblock ~-40 ~-1 ~-20 ochre_froglight
setblock ~-40 ~-1 ~-15 ochre_froglight
setblock ~-40 ~-1 ~-10 ochre_froglight
setblock ~-40 ~-1 ~-5 ochre_froglight
setblock ~-40 ~-1 ~0 ochre_froglight
setblock ~-40 ~-1 ~5 ochre_froglight
setblock ~-40 ~-1 ~10 ochre_froglight
setblock ~-40 ~-1 ~15 ochre_froglight
setblock ~-40 ~-1 ~20 ochre_froglight
setblock ~-35 ~-1 ~-25 ochre_froglight
setblock ~-35 ~-1 ~-20 ochre_froglight
setblock ~-35 ~-1 ~-15 ochre_froglight
setblock ~-35 ~-1 ~-10 ochre_froglight
setblock ~-35 ~-1 ~-5 ochre_froglight
setblock ~-35 ~-1 ~0 ochre_froglight
setblock ~-35 ~-1 ~5 ochre_froglight
setblock ~-35 ~-1 ~10 ochre_froglight
setblock ~-35 ~-1 ~15 ochre_froglight
setblock ~-35 ~-1 ~20 ochre_froglight
setblock ~-35 ~-1 ~25 ochre_froglight
setblock ~-30 ~-1 ~-30 ochre_froglight
setblock ~-30 ~-1 ~-25 ochre_froglight
setblock ~-30 ~-1 ~-20 ochre_froglight
setblock ~-30 ~-1 ~-15 ochre_froglight
setblock ~-30 ~-1 ~-10 ochre_froglight
setblock ~-30 ~-1 ~-5 ochre_froglight
setblock ~-30 ~-1 ~0 ochre_froglight
setblock ~-30 ~-1 ~5 ochre_froglight
setblock ~-30 ~-1 ~10 ochre_froglight
setblock ~-30 ~-1 ~15 ochre_froglight
setblock ~-30 ~-1 ~20 ochre_froglight
setblock ~-30 ~-1 ~25 ochre_froglight
setblock ~-30 ~-1 ~30 ochre_froglight
setblock ~-25 ~-1 ~-35 ochre_froglight
setblock ~-25 ~-1 ~-30 ochre_froglight
setblock ~-25 ~-1 ~-25 ochre_froglight
setblock ~-25 ~-1 ~-20 ochre_froglight
setblock ~-25 ~-1 ~-15 ochre_froglight
setblock ~-25 ~-1 ~-10 ochre_froglight
setblock ~-25 ~-1 ~-5 ochre_froglight
setblock ~-25 ~-1 ~0 ochre_froglight
setblock ~-25 ~-1 ~5 ochre_froglight
setblock ~-25 ~-1 ~10 ochre_froglight
setblock ~-25 ~-1 ~15 ochre_froglight
setblock ~-25 ~-1 ~20 ochre_froglight
setblock ~-25 ~-1 ~25 ochre_froglight
setblock ~-25 ~-1 ~30 ochre_froglight
setblock ~-25 ~-1 ~35 ochre_froglight
setblock ~-20 ~-1 ~-40 ochre_froglight
setblock ~-20 ~-1 ~-35 ochre_froglight
setblock ~-20 ~-1 ~-30 ochre_froglight
setblock ~-20 ~-1 ~-25 ochre_froglight
setblock ~-20 ~-1 ~-20 ochre_froglight
setblock ~-20 ~-1 ~-15 ochre_froglight
setblock ~-20 ~-1 ~-10 ochre_froglight
setblock ~-20 ~-1 ~-5 ochre_froglight
setblock ~-20 ~-1 ~0 ochre_froglight
setblock ~-20 ~-1 ~5 ochre_froglight
setblock ~-20 ~-1 ~10 ochre_froglight
setblock ~-20 ~-1 ~15 ochre_froglight
setblock ~-20 ~-1 ~20 ochre_froglight
setblock ~-20 ~-1 ~25 ochre_froglight
setblock ~-20 ~-1 ~30 ochre_froglight
setblock ~-20 ~-1 ~35 ochre_froglight
setblock ~-20 ~-1 ~40 ochre_froglight
setblock ~-15 ~-1 ~-40 ochre_froglight
setblock ~-15 ~-1 ~-35 ochre_froglight
setblock ~-15 ~-1 ~-30 ochre_froglight
setblock ~-15 ~-1 ~-25 ochre_froglight
setblock ~-15 ~-1 ~-20 ochre_froglight
setblock ~-15 ~-1 ~-15 ochre_froglight
setblock ~-15 ~-1 ~-10 ochre_froglight
setblock ~-15 ~-1 ~-5 ochre_froglight
setblock ~-15 ~-1 ~0 ochre_froglight
setblock ~-15 ~-1 ~5 ochre_froglight
setblock ~-15 ~-1 ~10 ochre_froglight
setblock ~-15 ~-1 ~15 ochre_froglight
setblock ~-15 ~-1 ~20 ochre_froglight
setblock ~-15 ~-1 ~25 ochre_froglight
setblock ~-15 ~-1 ~30 ochre_froglight
setblock ~-15 ~-1 ~35 ochre_froglight
setblock ~-15 ~-1 ~40 ochre_froglight
setblock ~-10 ~-1 ~-40 ochre_froglight
setblock ~-10 ~-1 ~-35 ochre_froglight
setblock ~-10 ~-1 ~-30 ochre_froglight
setblock ~-10 ~-1 ~-25 ochre_froglight
setblock ~-10 ~-1 ~-20 ochre_froglight
setblock ~-10 ~-1 ~-15 ochre_froglight
setblock ~-10 ~-1 ~-10 ochre_froglight
setblock ~-10 ~-1 ~-5 ochre_froglight
setblock ~-10 ~-1 ~0 ochre_froglight
setblock ~-10 ~-1 ~5 ochre_froglight
setblock ~-10 ~-1 ~10 ochre_froglight
setblock ~-10 ~-1 ~15 ochre_froglight
setblock ~-10 ~-1 ~20 ochre_froglight
setblock ~-10 ~-1 ~25 ochre_froglight
setblock ~-10 ~-1 ~30 ochre_froglight
setblock ~-10 ~-1 ~35 ochre_froglight
setblock ~-10 ~-1 ~40 ochre_froglight
setblock ~-5 ~-1 ~-40 ochre_froglight
setblock ~-5 ~-1 ~-35 ochre_froglight
setblock ~-5 ~-1 ~-30 ochre_froglight
setblock ~-5 ~-1 ~-25 ochre_froglight
setblock ~-5 ~-1 ~-20 ochre_froglight
setblock ~-5 ~-1 ~-15 ochre_froglight
setblock ~-5 ~-1 ~-10 ochre_froglight
setblock ~-5 ~-1 ~-5 ochre_froglight
setblock ~-5 ~-1 ~0 ochre_froglight
setblock ~-5 ~-1 ~5 ochre_froglight
setblock ~-5 ~-1 ~10 ochre_froglight
setblock ~-5 ~-1 ~15 ochre_froglight
setblock ~-5 ~-1 ~20 ochre_froglight
setblock ~-5 ~-1 ~25 ochre_froglight
setblock ~-5 ~-1 ~30 ochre_froglight
setblock ~-5 ~-1 ~35 ochre_froglight
setblock ~-5 ~-1 ~40 ochre_froglight
setblock ~0 ~-1 ~-40 ochre_froglight
setblock ~0 ~-1 ~-35 ochre_froglight
setblock ~0 ~-1 ~-30 ochre_froglight
setblock ~0 ~-1 ~-25 ochre_froglight
setblock ~0 ~-1 ~-20 ochre_froglight
setblock ~0 ~-1 ~-15 ochre_froglight
setblock ~0 ~-1 ~-10 ochre_froglight
setblock ~0 ~-1 ~-5 ochre_froglight
setblock ~0 ~-1 ~0 ochre_froglight
setblock ~0 ~-1 ~5 ochre_froglight
setblock ~0 ~-1 ~10 ochre_froglight
setblock ~0 ~-1 ~15 ochre_froglight
setblock ~0 ~-1 ~20 ochre_froglight
setblock ~0 ~-1 ~25 ochre_froglight
setblock ~0 ~-1 ~30 ochre_froglight
setblock ~0 ~-1 ~35 ochre_froglight
setblock ~0 ~-1 ~40 ochre_froglight
setblock ~5 ~-1 ~-40 ochre_froglight
setblock ~5 ~-1 ~-35 ochre_froglight
setblock ~5 ~-1 ~-30 ochre_froglight
setblock ~5 ~-1 ~-25 ochre_froglight
setblock ~5 ~-1 ~-20 ochre_froglight
setblock ~5 ~-1 ~-15 ochre_froglight
setblock ~5 ~-1 ~-10 ochre_froglight
setblock ~5 ~-1 ~-5 ochre_froglight
setblock ~5 ~-1 ~0 ochre_froglight
setblock ~5 ~-1 ~5 ochre_froglight
setblock ~5 ~-1 ~10 ochre_froglight
setblock ~5 ~-1 ~15 ochre_froglight
setblock ~5 ~-1 ~20 ochre_froglight
setblock ~5 ~-1 ~25 ochre_froglight
setblock ~5 ~-1 ~30 ochre_froglight
setblock ~5 ~-1 ~35 ochre_froglight
setblock ~5 ~-1 ~40 ochre_froglight
setblock ~10 ~-1 ~-40 ochre_froglight
setblock ~10 ~-1 ~-35 ochre_froglight
setblock ~10 ~-1 ~-30 ochre_froglight
setblock ~10 ~-1 ~-25 ochre_froglight
setblock ~10 ~-1 ~-20 ochre_froglight
setblock ~10 ~-1 ~-15 ochre_froglight
setblock ~10 ~-1 ~-10 ochre_froglight
setblock ~10 ~-1 ~-5 ochre_froglight
setblock ~10 ~-1 ~0 ochre_froglight
setblock ~10 ~-1 ~5 ochre_froglight
setblock ~10 ~-1 ~10 ochre_froglight
setblock ~10 ~-1 ~15 ochre_froglight
setblock ~10 ~-1 ~20 ochre_froglight
setblock ~10 ~-1 ~25 ochre_froglight
setblock ~10 ~-1 ~30 ochre_froglight
setblock ~10 ~-1 ~35 ochre_froglight
setblock ~10 ~-1 ~40 ochre_froglight
setblock ~15 ~-1 ~-40 ochre_froglight
setblock ~15 ~-1 ~-35 ochre_froglight
setblock ~15 ~-1 ~-30 ochre_froglight
setblock ~15 ~-1 ~-25 ochre_froglight
setblock ~15 ~-1 ~-20 ochre_froglight
setblock ~15 ~-1 ~-15 ochre_froglight
setblock ~15 ~-1 ~-10 ochre_froglight
setblock ~15 ~-1 ~-5 ochre_froglight
setblock ~15 ~-1 ~0 ochre_froglight
setblock ~15 ~-1 ~5 ochre_froglight
setblock ~15 ~-1 ~10 ochre_froglight
setblock ~15 ~-1 ~15 ochre_froglight
setblock ~15 ~-1 ~20 ochre_froglight
setblock ~15 ~-1 ~25 ochre_froglight
setblock ~15 ~-1 ~30 ochre_froglight
setblock ~15 ~-1 ~35 ochre_froglight
setblock ~15 ~-1 ~40 ochre_froglight
setblock ~20 ~-1 ~-40 ochre_froglight
setblock ~20 ~-1 ~-35 ochre_froglight
setblock ~20 ~-1 ~-30 ochre_froglight
setblock ~20 ~-1 ~-25 ochre_froglight
setblock ~20 ~-1 ~-20 ochre_froglight
setblock ~20 ~-1 ~-15 ochre_froglight
setblock ~20 ~-1 ~-10 ochre_froglight
setblock ~20 ~-1 ~-5 ochre_froglight
setblock ~20 ~-1 ~0 ochre_froglight
setblock ~20 ~-1 ~5 ochre_froglight
setblock ~20 ~-1 ~10 ochre_froglight
setblock ~20 ~-1 ~15 ochre_froglight
setblock ~20 ~-1 ~20 ochre_froglight
setblock ~20 ~-1 ~25 ochre_froglight
setblock ~20 ~-1 ~30 ochre_froglight
setblock ~20 ~-1 ~35 ochre_froglight
setblock ~20 ~-1 ~40 ochre_froglight
setblock ~25 ~-1 ~-35 ochre_froglight
setblock ~25 ~-1 ~-30 ochre_froglight
setblock ~25 ~-1 ~-25 ochre_froglight
setblock ~25 ~-1 ~-20 ochre_froglight
setblock ~25 ~-1 ~-15 ochre_froglight
setblock ~25 ~-1 ~-10 ochre_froglight
setblock ~25 ~-1 ~-5 ochre_froglight
setblock ~25 ~-1 ~0 ochre_froglight
setblock ~25 ~-1 ~5 ochre_froglight
setblock ~25 ~-1 ~10 ochre_froglight
setblock ~25 ~-1 ~15 ochre_froglight
setblock ~25 ~-1 ~20 ochre_froglight
setblock ~25 ~-1 ~25 ochre_froglight
setblock ~25 ~-1 ~30 ochre_froglight
setblock ~25 ~-1 ~35 ochre_froglight
setblock ~30 ~-1 ~-30 ochre_froglight
setblock ~30 ~-1 ~-25 ochre_froglight
setblock ~30 ~-1 ~-20 ochre_froglight
setblock ~30 ~-1 ~-15 ochre_froglight
setblock ~30 ~-1 ~-10 ochre_froglight
setblock ~30 ~-1 ~-5 ochre_froglight
setblock ~30 ~-1 ~0 ochre_froglight
setblock ~30 ~-1 ~5 ochre_froglight
setblock ~30 ~-1 ~10 ochre_froglight
setblock ~30 ~-1 ~15 ochre_froglight
setblock ~30 ~-1 ~20 ochre_froglight
setblock ~30 ~-1 ~25 ochre_froglight
setblock ~30 ~-1 ~30 ochre_froglight
setblock ~35 ~-1 ~-25 ochre_froglight
setblock ~35 ~-1 ~-20 ochre_froglight
setblock ~35 ~-1 ~-15 ochre_froglight
setblock ~35 ~-1 ~-10 ochre_froglight
setblock ~35 ~-1 ~-5 ochre_froglight
setblock ~35 ~-1 ~0 ochre_froglight
setblock ~35 ~-1 ~5 ochre_froglight
setblock ~35 ~-1 ~10 ochre_froglight
setblock ~35 ~-1 ~15 ochre_froglight
setblock ~35 ~-1 ~20 ochre_froglight
setblock ~35 ~-1 ~25 ochre_froglight
setblock ~40 ~-1 ~-20 ochre_froglight
setblock ~40 ~-1 ~-15 ochre_froglight
setblock ~40 ~-1 ~-10 ochre_froglight
setblock ~40 ~-1 ~-5 ochre_froglight
setblock ~40 ~-1 ~0 ochre_froglight
setblock ~40 ~-1 ~5 ochre_froglight
setblock ~40 ~-1 ~10 ochre_froglight
setblock ~40 ~-1 ~15 ochre_froglight
setblock ~40 ~-1 ~20 ochre_froglight
fill ~-9 ~0 ~-45 ~9 ~0 ~-45 cyan_carpet
fill ~-13 ~0 ~-44 ~13 ~0 ~-44 cyan_carpet
fill ~-16 ~0 ~-43 ~16 ~0 ~-43 cyan_carpet
fill ~-18 ~0 ~-42 ~18 ~0 ~-42 cyan_carpet
fill ~-20 ~0 ~-41 ~20 ~0 ~-41 cyan_carpet
fill ~-22 ~0 ~-40 ~22 ~0 ~-40 cyan_carpet
fill ~-24 ~0 ~-39 ~24 ~0 ~-39 cyan_carpet
fill ~-25 ~0 ~-38 ~25 ~0 ~-38 cyan_carpet
fill ~-27 ~0 ~-37 ~27 ~0 ~-37 cyan_carpet
fill ~-28 ~0 ~-36 ~28 ~0 ~-36 cyan_carpet
fill ~-29 ~0 ~-35 ~29 ~0 ~-35 cyan_carpet
fill ~-30 ~0 ~-34 ~30 ~0 ~-34 cyan_carpet
fill ~-32 ~0 ~-33 ~32 ~0 ~-33 cyan_carpet
fill ~-33 ~0 ~-32 ~33 ~0 ~-32 cyan_carpet
fill ~-33 ~0 ~-31 ~33 ~0 ~-31 cyan_carpet
fill ~-34 ~0 ~-30 ~34 ~0 ~-30 cyan_carpet
fill ~-35 ~0 ~-29 ~35 ~0 ~-29 cyan_carpet
fill ~-36 ~0 ~-28 ~36 ~0 ~-28 cyan_carpet
fill ~-37 ~0 ~-27 ~37 ~0 ~-27 cyan_carpet
fill ~-37 ~0 ~-26 ~37 ~0 ~-26 cyan_carpet
fill ~-38 ~0 ~-25 ~38 ~0 ~-25 cyan_carpet
fill ~-39 ~0 ~-24 ~39 ~0 ~-24 cyan_carpet
fill ~-39 ~0 ~-23 ~39 ~0 ~-23 cyan_carpet
fill ~-40 ~0 ~-22 ~40 ~0 ~-22 cyan_carpet
fill ~-40 ~0 ~-21 ~40 ~0 ~-21 cyan_carpet
fill ~-41 ~0 ~-20 ~41 ~0 ~-20 cyan_carpet
fill ~-41 ~0 ~-19 ~41 ~0 ~-19 cyan_carpet
fill ~-42 ~0 ~-18 ~42 ~0 ~-18 cyan_carpet
fill ~-42 ~0 ~-17 ~42 ~0 ~-17 cyan_carpet
fill ~-43 ~0 ~-16 ~43 ~0 ~-16 cyan_carpet
fill ~-43 ~0 ~-15 ~43 ~0 ~-15 cyan_carpet
fill ~-43 ~0 ~-14 ~43 ~0 ~-14 cyan_carpet
fill ~-44 ~0 ~-13 ~44 ~0 ~-13 cyan_carpet
fill ~-44 ~0 ~-12 ~44 ~0 ~-12 cyan_carpet
fill ~-44 ~0 ~-11 ~44 ~0 ~-11 cyan_carpet
fill ~-44 ~0 ~-10 ~44 ~0 ~-10 cyan_carpet
fill ~-45 ~0 ~-9 ~45 ~0 ~-9 cyan_carpet
fill ~-45 ~0 ~-8 ~45 ~0 ~-8 cyan_carpet
fill ~-45 ~0 ~-7 ~45 ~0 ~-7 cyan_carpet
fill ~-45 ~0 ~-6 ~45 ~0 ~-6 cyan_carpet
fill ~-45 ~0 ~-5 ~45 ~0 ~-5 cyan_carpet
fill ~-45 ~0 ~-4 ~45 ~0 ~-4 cyan_carpet
fill ~-45 ~0 ~-3 ~45 ~0 ~-3 cyan_carpet
fill ~-45 ~0 ~-2 ~45 ~0 ~-2 cyan_carpet
fill ~-45 ~0 ~-1 ~45 ~0 ~-1 cyan_carpet
fill ~-45 ~0 ~0 ~45 ~0 ~0 cyan_carpet
fill ~-45 ~0 ~1 ~45 ~0 ~1 cyan_carpet
fill ~-45 ~0 ~2 ~45 ~0 ~2 cyan_carpet
fill ~-45 ~0 ~3 ~45 ~0 ~3 cyan_carpet
fill ~-45 ~0 ~4 ~45 ~0 ~4 cyan_carpet
fill ~-45 ~0 ~5 ~45 ~0 ~5 cyan_carpet
fill ~-45 ~0 ~6 ~45 ~0 ~6 cyan_carpet
fill ~-45 ~0 ~7 ~45 ~0 ~7 cyan_carpet
fill ~-45 ~0 ~8 ~45 ~0 ~8 cyan_carpet
fill ~-45 ~0 ~9 ~45 ~0 ~9 cyan_carpet
fill ~-44 ~0 ~10 ~44 ~0 ~10 cyan_carpet
fill ~-44 ~0 ~11 ~44 ~0 ~11 cyan_carpet
fill ~-44 ~0 ~12 ~44 ~0 ~12 cyan_carpet
fill ~-44 ~0 ~13 ~44 ~0 ~13 cyan_carpet
fill ~-43 ~0 ~14 ~43 ~0 ~14 cyan_carpet
fill ~-43 ~0 ~15 ~43 ~0 ~15 cyan_carpet
fill ~-43 ~0 ~16 ~43 ~0 ~16 cyan_carpet
fill ~-42 ~0 ~17 ~42 ~0 ~17 cyan_carpet
fill ~-42 ~0 ~18 ~42 ~0 ~18 cyan_carpet
fill ~-41 ~0 ~19 ~41 ~0 ~19 cyan_carpet
fill ~-41 ~0 ~20 ~41 ~0 ~20 cyan_carpet
fill ~-40 ~0 ~21 ~40 ~0 ~21 cyan_carpet
fill ~-40 ~0 ~22 ~40 ~0 ~22 cyan_carpet
fill ~-39 ~0 ~23 ~39 ~0 ~23 cyan_carpet
fill ~-39 ~0 ~24 ~39 ~0 ~24 cyan_carpet
fill ~-38 ~0 ~25 ~38 ~0 ~25 cyan_carpet
fill ~-37 ~0 ~26 ~37 ~0 ~26 cyan_carpet
fill ~-37 ~0 ~27 ~37 ~0 ~27 cyan_carpet
fill ~-36 ~0 ~28 ~36 ~0 ~28 cyan_carpet
fill ~-35 ~0 ~29 ~35 ~0 ~29 cyan_carpet
fill ~-34 ~0 ~30 ~34 ~0 ~30 cyan_carpet
fill ~-33 ~0 ~31 ~33 ~0 ~31 cyan_carpet
fill ~-33 ~0 ~32 ~33 ~0 ~32 cyan_carpet
fill ~-32 ~0 ~33 ~32 ~0 ~33 cyan_carpet
fill ~-30 ~0 ~34 ~30 ~0 ~34 cyan_carpet
fill ~-29 ~0 ~35 ~29 ~0 ~35 cyan_carpet
fill ~-28 ~0 ~36 ~28 ~0 ~36 cyan_carpet
fill ~-27 ~0 ~37 ~27 ~0 ~37 cyan_carpet
fill ~-25 ~0 ~38 ~25 ~0 ~38 cyan_carpet
fill ~-24 ~0 ~39 ~24 ~0 ~39 cyan_carpet
fill ~-22 ~0 ~40 ~22 ~0 ~40 cyan_carpet
fill ~-20 ~0 ~41 ~20 ~0 ~41 cyan_carpet
fill ~-18 ~0 ~42 ~18 ~0 ~42 cyan_carpet
fill ~-16 ~0 ~43 ~16 ~0 ~43 cyan_carpet
fill ~-13 ~0 ~44 ~13 ~0 ~44 cyan_carpet
fill ~-9 ~0 ~45 ~9 ~0 ~45 cyan_carpet
fill ~-2 ~0 ~-9 ~2 ~0 ~-9 blue_carpet
fill ~-4 ~0 ~-8 ~-3 ~0 ~-8 blue_carpet
fill ~3 ~0 ~-8 ~4 ~0 ~-8 blue_carpet
fill ~-6 ~0 ~-7 ~-5 ~0 ~-7 blue_carpet
fill ~5 ~0 ~-7 ~6 ~0 ~-7 blue_carpet
fill ~-7 ~0 ~-6 ~-7 ~0 ~-6 blue_carpet
fill ~7 ~0 ~-6 ~7 ~0 ~-6 blue_carpet
fill ~-7 ~0 ~-5 ~-7 ~0 ~-5 blue_carpet
fill ~7 ~0 ~-5 ~7 ~0 ~-5 blue_carpet
fill ~-8 ~0 ~-4 ~-8 ~0 ~-4 blue_carpet
fill ~8 ~0 ~-4 ~8 ~0 ~-4 blue_carpet
fill ~-8 ~0 ~-3 ~-8 ~0 ~-3 blue_carpet
fill ~8 ~0 ~-3 ~8 ~0 ~-3 blue_carpet
fill ~-9 ~0 ~-2 ~-9 ~0 ~-2 blue_carpet
fill ~9 ~0 ~-2 ~9 ~0 ~-2 blue_carpet
fill ~-9 ~0 ~-1 ~-9 ~0 ~-1 blue_carpet
fill ~9 ~0 ~-1 ~9 ~0 ~-1 blue_carpet
fill ~-9 ~0 ~0 ~-9 ~0 ~0 blue_carpet
fill ~9 ~0 ~0 ~9 ~0 ~0 blue_carpet
fill ~-9 ~0 ~1 ~-9 ~0 ~1 blue_carpet
fill ~9 ~0 ~1 ~9 ~0 ~1 blue_carpet
fill ~-9 ~0 ~2 ~-9 ~0 ~2 blue_carpet
fill ~9 ~0 ~2 ~9 ~0 ~2 blue_carpet
fill ~-8 ~0 ~3 ~-8 ~0 ~3 blue_carpet
fill ~8 ~0 ~3 ~8 ~0 ~3 blue_carpet
fill ~-8 ~0 ~4 ~-8 ~0 ~4 blue_carpet
fill ~8 ~0 ~4 ~8 ~0 ~4 blue_carpet
fill ~-7 ~0 ~5 ~-7 ~0 ~5 blue_carpet
fill ~7 ~0 ~5 ~7 ~0 ~5 blue_carpet
fill ~-7 ~0 ~6 ~-7 ~0 ~6 blue_carpet
fill ~7 ~0 ~6 ~7 ~0 ~6 blue_carpet
fill ~-6 ~0 ~7 ~-5 ~0 ~7 blue_carpet
fill ~5 ~0 ~7 ~6 ~0 ~7 blue_carpet
fill ~-4 ~0 ~8 ~-3 ~0 ~8 blue_carpet
fill ~3 ~0 ~8 ~4 ~0 ~8 blue_carpet
fill ~-2 ~0 ~9 ~2 ~0 ~9 blue_carpet
fill ~-3 ~0 ~-13 ~3 ~0 ~-13 blue_carpet
fill ~-5 ~0 ~-12 ~-4 ~0 ~-12 blue_carpet
fill ~4 ~0 ~-12 ~5 ~0 ~-12 blue_carpet
fill ~-7 ~0 ~-11 ~-6 ~0 ~-11 blue_carpet
fill ~6 ~0 ~-11 ~7 ~0 ~-11 blue_carpet
fill ~-8 ~0 ~-10 ~-8 ~0 ~-10 blue_carpet
fill ~8 ~0 ~-10 ~8 ~0 ~-10 blue_carpet
fill ~-9 ~0 ~-9 ~-9 ~0 ~-9 blue_carpet
fill ~9 ~0 ~-9 ~9 ~0 ~-9 blue_carpet
fill ~-10 ~0 ~-8 ~-10 ~0 ~-8 blue_carpet
fill ~10 ~0 ~-8 ~10 ~0 ~-8 blue_carpet
fill ~-11 ~0 ~-7 ~-11 ~0 ~-7 blue_carpet
fill ~11 ~0 ~-7 ~11 ~0 ~-7 blue_carpet
fill ~-11 ~0 ~-6 ~-11 ~0 ~-6 blue_carpet
fill ~11 ~0 ~-6 ~11 ~0 ~-6 blue_carpet
fill ~-12 ~0 ~-5 ~-12 ~0 ~-5 blue_carpet
fill ~12 ~0 ~-5 ~12 ~0 ~-5 blue_carpet
fill ~-12 ~0 ~-4 ~-12 ~0 ~-4 blue_carpet
fill ~12 ~0 ~-4 ~12 ~0 ~-4 blue_carpet
fill ~-13 ~0 ~-3 ~-13 ~0 ~-3 blue_carpet
fill ~13 ~0 ~-3 ~13 ~0 ~-3 blue_carpet
fill ~-13 ~0 ~-2 ~-13 ~0 ~-2 blue_carpet
fill ~13 ~0 ~-2 ~13 ~0 ~-2 blue_carpet
fill ~-13 ~0 ~-1 ~-13 ~0 ~-1 blue_carpet
fill ~13 ~0 ~-1 ~13 ~0 ~-1 blue_carpet
fill ~-13 ~0 ~0 ~-13 ~0 ~0 blue_carpet
fill ~13 ~0 ~0 ~13 ~0 ~0 blue_carpet
fill ~-13 ~0 ~1 ~-13 ~0 ~1 blue_carpet
fill ~13 ~0 ~1 ~13 ~0 ~1 blue_carpet
fill ~-13 ~0 ~2 ~-13 ~0 ~2 blue_carpet
fill ~13 ~0 ~2 ~13 ~0 ~2 blue_carpet
fill ~-13 ~0 ~3 ~-13 ~0 ~3 blue_carpet
fill ~13 ~0 ~3 ~13 ~0 ~3 blue_carpet
fill ~-12 ~0 ~4 ~-12 ~0 ~4 blue_carpet
fill ~12 ~0 ~4 ~12 ~0 ~4 blue_carpet
fill ~-12 ~0 ~5 ~-12 ~0 ~5 blue_carpet
fill ~12 ~0 ~5 ~12 ~0 ~5 blue_carpet
fill ~-11 ~0 ~6 ~-11 ~0 ~6 blue_carpet
fill ~11 ~0 ~6 ~11 ~0 ~6 blue_carpet
fill ~-11 ~0 ~7 ~-11 ~0 ~7 blue_carpet
fill ~11 ~0 ~7 ~11 ~0 ~7 blue_carpet
fill ~-10 ~0 ~8 ~-10 ~0 ~8 blue_carpet
fill ~10 ~0 ~8 ~10 ~0 ~8 blue_carpet
fill ~-9 ~0 ~9 ~-9 ~0 ~9 blue_carpet
fill ~9 ~0 ~9 ~9 ~0 ~9 blue_carpet
fill ~-8 ~0 ~10 ~-8 ~0 ~10 blue_carpet
fill ~8 ~0 ~10 ~8 ~0 ~10 blue_carpet
fill ~-7 ~0 ~11 ~-6 ~0 ~11 blue_carpet
fill ~6 ~0 ~11 ~7 ~0 ~11 blue_carpet
fill ~-5 ~0 ~12 ~-4 ~0 ~12 blue_carpet
fill ~4 ~0 ~12 ~5 ~0 ~12 blue_carpet
fill ~-3 ~0 ~13 ~3 ~0 ~13 blue_carpet
fill ~-3 ~0 ~-17 ~3 ~0 ~-17 blue_carpet
fill ~-6 ~0 ~-16 ~-5 ~0 ~-16 blue_carpet
fill ~5 ~0 ~-16 ~6 ~0 ~-16 blue_carpet
fill ~-8 ~0 ~-15 ~-7 ~0 ~-15 blue_carpet
fill ~7 ~0 ~-15 ~8 ~0 ~-15 blue_carpet
fill ~-10 ~0 ~-14 ~-9 ~0 ~-14 blue_carpet
fill ~9 ~0 ~-14 ~10 ~0 ~-14 blue_carpet
fill ~-11 ~0 ~-13 ~-11 ~0 ~-13 blue_carpet
fill ~11 ~0 ~-13 ~11 ~0 ~-13 blue_carpet
fill ~-12 ~0 ~-12 ~-12 ~0 ~-12 blue_carpet
fill ~12 ~0 ~-12 ~12 ~0 ~-12 blue_carpet
fill ~-13 ~0 ~-11 ~-13 ~0 ~-11 blue_carpet
fill ~13 ~0 ~-11 ~13 ~0 ~-11 blue_carpet
fill ~-14 ~0 ~-10 ~-14 ~0 ~-10 blue_carpet
fill ~14 ~0 ~-10 ~14 ~0 ~-10 blue_carpet
fill ~-14 ~0 ~-9 ~-14 ~0 ~-9 blue_carpet
fill ~14 ~0 ~-9 ~14 ~0 ~-9 blue_carpet
fill ~-15 ~0 ~-8 ~-15 ~0 ~-8 blue_carpet
fill ~15 ~0 ~-8 ~15 ~0 ~-8 blue_carpet
fill ~-15 ~0 ~-7 ~-15 ~0 ~-7 blue_carpet
fill ~15 ~0 ~-7 ~15 ~0 ~-7 blue_carpet
fill ~-16 ~0 ~-6 ~-16 ~0 ~-6 blue_carpet
fill ~16 ~0 ~-6 ~16 ~0 ~-6 blue_carpet
fill ~-16 ~0 ~-5 ~-16 ~0 ~-5 blue_carpet
fill ~16 ~0 ~-5 ~16 ~0 ~-5 blue_carpet
fill ~-17 ~0 ~-3 ~-17 ~0 ~-3 blue_carpet
fill ~17 ~0 ~-3 ~17 ~0 ~-3 blue_carpet
fill ~-17 ~0 ~-2 ~-17 ~0 ~-2 blue_carpet
fill ~17 ~0 ~-2 ~17 ~0 ~-2 blue_carpet
fill ~-17 ~0 ~-1 ~-17 ~0 ~-1 blue_carpet
fill ~17 ~0 ~-1 ~17 ~0 ~-1 blue_carpet
fill ~-17 ~0 ~0 ~-17 ~0 ~0 blue_carpet
fill ~17 ~0 ~0 ~17 ~0 ~0 blue_carpet
fill ~-17 ~0 ~1 ~-17 ~0 ~1 blue_carpet
fill ~17 ~0 ~1 ~17 ~0 ~1 blue_carpet
fill ~-17 ~0 ~2 ~-17 ~0 ~2 blue_carpet
fill ~17 ~0 ~2 ~17 ~0 ~2 blue_carpet
fill ~-17 ~0 ~3 ~-17 ~0 ~3 blue_carpet
fill ~17 ~0 ~3 ~17 ~0 ~3 blue_carpet
fill ~-16 ~0 ~5 ~-16 ~0 ~5 blue_carpet
fill ~16 ~0 ~5 ~16 ~0 ~5 blue_carpet
fill ~-16 ~0 ~6 ~-16 ~0 ~6 blue_carpet
fill ~16 ~0 ~6 ~16 ~0 ~6 blue_carpet
fill ~-15 ~0 ~7 ~-15 ~0 ~7 blue_carpet
fill ~15 ~0 ~7 ~15 ~0 ~7 blue_carpet
fill ~-15 ~0 ~8 ~-15 ~0 ~8 blue_carpet
fill ~15 ~0 ~8 ~15 ~0 ~8 blue_carpet
fill ~-14 ~0 ~9 ~-14 ~0 ~9 blue_carpet
fill ~14 ~0 ~9 ~14 ~0 ~9 blue_carpet
fill ~-14 ~0 ~10 ~-14 ~0 ~10 blue_carpet
fill ~14 ~0 ~10 ~14 ~0 ~10 blue_carpet
fill ~-13 ~0 ~11 ~-13 ~0 ~11 blue_carpet
fill ~13 ~0 ~11 ~13 ~0 ~11 blue_carpet
fill ~-12 ~0 ~12 ~-12 ~0 ~12 blue_carpet
fill ~12 ~0 ~12 ~12 ~0 ~12 blue_carpet
fill ~-11 ~0 ~13 ~-11 ~0 ~13 blue_carpet
fill ~11 ~0 ~13 ~11 ~0 ~13 blue_carpet
fill ~-10 ~0 ~14 ~-9 ~0 ~14 blue_carpet
fill ~9 ~0 ~14 ~10 ~0 ~14 blue_carpet
fill ~-8 ~0 ~15 ~-7 ~0 ~15 blue_carpet
fill ~7 ~0 ~15 ~8 ~0 ~15 blue_carpet
fill ~-6 ~0 ~16 ~-5 ~0 ~16 blue_carpet
fill ~5 ~0 ~16 ~6 ~0 ~16 blue_carpet
fill ~-3 ~0 ~17 ~3 ~0 ~17 blue_carpet
fill ~-6 ~0 ~-21 ~6 ~0 ~-21 blue_carpet
fill ~-8 ~0 ~-20 ~-7 ~0 ~-20 blue_carpet
fill ~7 ~0 ~-20 ~8 ~0 ~-20 blue_carpet
fill ~-10 ~0 ~-19 ~-9 ~0 ~-19 blue_carpet
fill ~9 ~0 ~-19 ~10 ~0 ~-19 blue_carpet
fill ~-12 ~0 ~-18 ~-11 ~0 ~-18 blue_carpet
fill ~11 ~0 ~-18 ~12 ~0 ~-18 blue_carpet
fill ~-13 ~0 ~-17 ~-13 ~0 ~-17 blue_carpet
fill ~13 ~0 ~-17 ~13 ~0 ~-17 blue_carpet
fill ~-14 ~0 ~-16 ~-14 ~0 ~-16 blue_carpet
fill ~14 ~0 ~-16 ~14 ~0 ~-16 blue_carpet
fill ~-15 ~0 ~-15 ~-15 ~0 ~-15 blue_carpet
fill ~15 ~0 ~-15 ~15 ~0 ~-15 blue_carpet
fill ~-16 ~0 ~-14 ~-16 ~0 ~-14 blue_carpet
fill ~16 ~0 ~-14 ~16 ~0 ~-14 blue_carpet
fill ~-17 ~0 ~-13 ~-17 ~0 ~-13 blue_carpet
fill ~17 ~0 ~-13 ~17 ~0 ~-13 blue_carpet
fill ~-18 ~0 ~-12 ~-18 ~0 ~-12 blue_carpet
fill ~18 ~0 ~-12 ~18 ~0 ~-12 blue_carpet
fill ~-18 ~0 ~-11 ~-18 ~0 ~-11 blue_carpet
fill ~18 ~0 ~-11 ~18 ~0 ~-11 blue_carpet
fill ~-19 ~0 ~-10 ~-19 ~0 ~-10 blue_carpet
fill ~19 ~0 ~-10 ~19 ~0 ~-10 blue_carpet
fill ~-19 ~0 ~-9 ~-19 ~0 ~-9 blue_carpet
fill ~19 ~0 ~-9 ~19 ~0 ~-9 blue_carpet
fill ~-20 ~0 ~-8 ~-20 ~0 ~-8 blue_carpet
fill ~20 ~0 ~-8 ~20 ~0 ~-8 blue_carpet
fill ~-20 ~0 ~-7 ~-20 ~0 ~-7 blue_carpet
fill ~20 ~0 ~-7 ~20 ~0 ~-7 blue_carpet
fill ~-21 ~0 ~-6 ~-21 ~0 ~-6 blue_carpet
fill ~21 ~0 ~-6 ~21 ~0 ~-6 blue_carpet
fill ~-21 ~0 ~-5 ~-21 ~0 ~-5 blue_carpet
fill ~21 ~0 ~-5 ~21 ~0 ~-5 blue_carpet
fill ~-21 ~0 ~-4 ~-21 ~0 ~-4 blue_carpet
fill ~21 ~0 ~-4 ~21 ~0 ~-4 blue_carpet
fill ~-21 ~0 ~-3 ~-21 ~0 ~-3 blue_carpet
fill ~21 ~0 ~-3 ~21 ~0 ~-3 blue_carpet
fill ~-21 ~0 ~-2 ~-21 ~0 ~-2 blue_carpet
fill ~21 ~0 ~-2 ~21 ~0 ~-2 blue_carpet
fill ~-21 ~0 ~-1 ~-21 ~0 ~-1 blue_carpet
fill ~21 ~0 ~-1 ~21 ~0 ~-1 blue_carpet
fill ~-21 ~0 ~0 ~-21 ~0 ~0 blue_carpet
fill ~21 ~0 ~0 ~21 ~0 ~0 blue_carpet
fill ~-21 ~0 ~1 ~-21 ~0 ~1 blue_carpet
fill ~21 ~0 ~1 ~21 ~0 ~1 blue_carpet
fill ~-21 ~0 ~2 ~-21 ~0 ~2 blue_carpet
fill ~21 ~0 ~2 ~21 ~0 ~2 blue_carpet
fill ~-21 ~0 ~3 ~-21 ~0 ~3 blue_carpet
fill ~21 ~0 ~3 ~21 ~0 ~3 blue_carpet
fill ~-21 ~0 ~4 ~-21 ~0 ~4 blue_carpet
fill ~21 ~0 ~4 ~21 ~0 ~4 blue_carpet
fill ~-21 ~0 ~5 ~-21 ~0 ~5 blue_carpet
fill ~21 ~0 ~5 ~21 ~0 ~5 blue_carpet
fill ~-21 ~0 ~6 ~-21 ~0 ~6 blue_carpet
fill ~21 ~0 ~6 ~21 ~0 ~6 blue_carpet
fill ~-20 ~0 ~7 ~-20 ~0 ~7 blue_carpet
fill ~20 ~0 ~7 ~20 ~0 ~7 blue_carpet
fill ~-20 ~0 ~8 ~-20 ~0 ~8 blue_carpet
fill ~20 ~0 ~8 ~20 ~0 ~8 blue_carpet
fill ~-19 ~0 ~9 ~-19 ~0 ~9 blue_carpet
fill ~19 ~0 ~9 ~19 ~0 ~9 blue_carpet
fill ~-19 ~0 ~10 ~-19 ~0 ~10 blue_carpet
fill ~19 ~0 ~10 ~19 ~0 ~10 blue_carpet
fill ~-18 ~0 ~11 ~-18 ~0 ~11 blue_carpet
fill ~18 ~0 ~11 ~18 ~0 ~11 blue_carpet
fill ~-18 ~0 ~12 ~-18 ~0 ~12 blue_carpet
fill ~18 ~0 ~12 ~18 ~0 ~12 blue_carpet
fill ~-17 ~0 ~13 ~-17 ~0 ~13 blue_carpet
fill ~17 ~0 ~13 ~17 ~0 ~13 blue_carpet
fill ~-16 ~0 ~14 ~-16 ~0 ~14 blue_carpet
fill ~16 ~0 ~14 ~16 ~0 ~14 blue_carpet
fill ~-15 ~0 ~15 ~-15 ~0 ~15 blue_carpet
fill ~15 ~0 ~15 ~15 ~0 ~15 blue_carpet
fill ~-14 ~0 ~16 ~-14 ~0 ~16 blue_carpet
fill ~14 ~0 ~16 ~14 ~0 ~16 blue_carpet
fill ~-13 ~0 ~17 ~-13 ~0 ~17 blue_carpet
fill ~13 ~0 ~17 ~13 ~0 ~17 blue_carpet
fill ~-12 ~0 ~18 ~-11 ~0 ~18 blue_carpet
fill ~11 ~0 ~18 ~12 ~0 ~18 blue_carpet
fill ~-10 ~0 ~19 ~-9 ~0 ~19 blue_carpet
fill ~9 ~0 ~19 ~10 ~0 ~19 blue_carpet
fill ~-8 ~0 ~20 ~-7 ~0 ~20 blue_carpet
fill ~7 ~0 ~20 ~8 ~0 ~20 blue_carpet
fill ~-6 ~0 ~21 ~6 ~0 ~21 blue_carpet
fill ~-7 ~0 ~-30 ~7 ~0 ~-30 blue_carpet
fill ~-10 ~0 ~-29 ~-8 ~0 ~-29 blue_carpet
fill ~8 ~0 ~-29 ~10 ~0 ~-29 blue_carpet
fill ~-13 ~0 ~-28 ~-11 ~0 ~-28 blue_carpet
fill ~11 ~0 ~-28 ~13 ~0 ~-28 blue_carpet
fill ~-15 ~0 ~-27 ~-14 ~0 ~-27 blue_carpet
fill ~14 ~0 ~-27 ~15 ~0 ~-27 blue_carpet
fill ~-16 ~0 ~-26 ~-15 ~0 ~-26 blue_carpet
fill ~15 ~0 ~-26 ~16 ~0 ~-26 blue_carpet
fill ~-18 ~0 ~-25 ~-17 ~0 ~-25 blue_carpet
fill ~17 ~0 ~-25 ~18 ~0 ~-25 blue_carpet
fill ~-19 ~0 ~-24 ~-18 ~0 ~-24 blue_carpet
fill ~18 ~0 ~-24 ~19 ~0 ~-24 blue_carpet
fill ~-20 ~0 ~-23 ~-20 ~0 ~-23 blue_carpet
fill ~20 ~0 ~-23 ~20 ~0 ~-23 blue_carpet
fill ~-21 ~0 ~-22 ~-21 ~0 ~-22 blue_carpet
fill ~21 ~0 ~-22 ~21 ~0 ~-22 blue_carpet
fill ~-22 ~0 ~-21 ~-22 ~0 ~-21 blue_carpet
fill ~22 ~0 ~-21 ~22 ~0 ~-21 blue_carpet
fill ~-23 ~0 ~-20 ~-23 ~0 ~-20 blue_carpet
fill ~23 ~0 ~-20 ~23 ~0 ~-20 blue_carpet
fill ~-24 ~0 ~-19 ~-24 ~0 ~-19 blue_carpet
fill ~24 ~0 ~-19 ~24 ~0 ~-19 blue_carpet
fill ~-25 ~0 ~-18 ~-24 ~0 ~-18 blue_carpet
fill ~24 ~0 ~-18 ~25 ~0 ~-18 blue_carpet
fill ~-25 ~0 ~-17 ~-25 ~0 ~-17 blue_carpet
fill ~25 ~0 ~-17 ~25 ~0 ~-17 blue_carpet
fill ~-26 ~0 ~-16 ~-26 ~0 ~-16 blue_carpet
fill ~26 ~0 ~-16 ~26 ~0 ~-16 blue_carpet
fill ~-27 ~0 ~-15 ~-26 ~0 ~-15 blue_carpet
fill ~26 ~0 ~-15 ~27 ~0 ~-15 blue_carpet
fill ~-27 ~0 ~-14 ~-27 ~0 ~-14 blue_carpet
fill ~27 ~0 ~-14 ~27 ~0 ~-14 blue_carpet
fill ~-28 ~0 ~-13 ~-28 ~0 ~-13 blue_carpet
fill ~28 ~0 ~-13 ~28 ~0 ~-13 blue_carpet
fill ~-28 ~0 ~-12 ~-28 ~0 ~-12 blue_carpet
fill ~28 ~0 ~-12 ~28 ~0 ~-12 blue_carpet
fill ~-28 ~0 ~-11 ~-28 ~0 ~-11 blue_carpet
fill ~28 ~0 ~-11 ~28 ~0 ~-11 blue_carpet
fill ~-29 ~0 ~-10 ~-29 ~0 ~-10 blue_carpet
fill ~29 ~0 ~-10 ~29 ~0 ~-10 blue_carpet
fill ~-29 ~0 ~-9 ~-29 ~0 ~-9 blue_carpet
fill ~29 ~0 ~-9 ~29 ~0 ~-9 blue_carpet
fill ~-29 ~0 ~-8 ~-29 ~0 ~-8 blue_carpet
fill ~29 ~0 ~-8 ~29 ~0 ~-8 blue_carpet
fill ~-30 ~0 ~-7 ~-30 ~0 ~-7 blue_carpet
fill ~30 ~0 ~-7 ~30 ~0 ~-7 blue_carpet
fill ~-30 ~0 ~-6 ~-30 ~0 ~-6 blue_carpet
fill ~30 ~0 ~-6 ~30 ~0 ~-6 blue_carpet
fill ~-30 ~0 ~-5 ~-30 ~0 ~-5 blue_carpet
fill ~30 ~0 ~-5 ~30 ~0 ~-5 blue_carpet
fill ~-30 ~0 ~-4 ~-30 ~0 ~-4 blue_carpet
fill ~30 ~0 ~-4 ~30 ~0 ~-4 blue_carpet
fill ~-30 ~0 ~-3 ~-30 ~0 ~-3 blue_carpet
fill ~30 ~0 ~-3 ~30 ~0 ~-3 blue_carpet
fill ~-30 ~0 ~-2 ~-30 ~0 ~-2 blue_carpet
fill ~30 ~0 ~-2 ~30 ~0 ~-2 blue_carpet
fill ~-30 ~0 ~-1 ~-30 ~0 ~-1 blue_carpet
fill ~30 ~0 ~-1 ~30 ~0 ~-1 blue_carpet
fill ~-30 ~0 ~0 ~-30 ~0 ~0 blue_carpet
fill ~30 ~0 ~0 ~30 ~0 ~0 blue_carpet
fill ~-30 ~0 ~1 ~-30 ~0 ~1 blue_carpet
fill ~30 ~0 ~1 ~30 ~0 ~1 blue_carpet
fill ~-30 ~0 ~2 ~-30 ~0 ~2 blue_carpet
fill ~30 ~0 ~2 ~30 ~0 ~2 blue_carpet
fill ~-30 ~0 ~3 ~-30 ~0 ~3 blue_carpet
fill ~30 ~0 ~3 ~30 ~0 ~3 blue_carpet
fill ~-30 ~0 ~4 ~-30 ~0 ~4 blue_carpet
fill ~30 ~0 ~4 ~30 ~0 ~4 blue_carpet
fill ~-30 ~0 ~5 ~-30 ~0 ~5 blue_carpet
fill ~30 ~0 ~5 ~30 ~0 ~5 blue_carpet
fill ~-30 ~0 ~6 ~-30 ~0 ~6 blue_carpet
fill ~30 ~0 ~6 ~30 ~0 ~6 blue_carpet
fill ~-30 ~0 ~7 ~-30 ~0 ~7 blue_carpet
fill ~30 ~0 ~7 ~30 ~0 ~7 blue_carpet
fill ~-29 ~0 ~8 ~-29 ~0 ~8 blue_carpet
fill ~29 ~0 ~8 ~29 ~0 ~8 blue_carpet
fill ~-29 ~0 ~9 ~-29 ~0 ~9 blue_carpet
fill ~29 ~0 ~9 ~29 ~0 ~9 blue_carpet
fill ~-29 ~0 ~10 ~-29 ~0 ~10 blue_carpet
fill ~29 ~0 ~10 ~29 ~0 ~10 blue_carpet
fill ~-28 ~0 ~11 ~-28 ~0 ~11 blue_carpet
fill ~28 ~0 ~11 ~28 ~0 ~11 blue_carpet
fill ~-28 ~0 ~12 ~-28 ~0 ~12 blue_carpet
fill ~28 ~0 ~12 ~28 ~0 ~12 blue_carpet
fill ~-28 ~0 ~13 ~-28 ~0 ~13 blue_carpet
fill ~28 ~0 ~13 ~28 ~0 ~13 blue_carpet
fill ~-27 ~0 ~14 ~-27 ~0 ~14 blue_carpet
fill ~27 ~0 ~14 ~27 ~0 ~14 blue_carpet
fill ~-27 ~0 ~15 ~-26 ~0 ~15 blue_carpet
fill ~26 ~0 ~15 ~27 ~0 ~15 blue_carpet
fill ~-26 ~0 ~16 ~-26 ~0 ~16 blue_carpet
fill ~26 ~0 ~16 ~26 ~0 ~16 blue_carpet
fill ~-25 ~0 ~17 ~-25 ~0 ~17 blue_carpet
fill ~25 ~0 ~17 ~25 ~0 ~17 blue_carpet
fill ~-25 ~0 ~18 ~-24 ~0 ~18 blue_carpet
fill ~24 ~0 ~18 ~25 ~0 ~18 blue_carpet
fill ~-24 ~0 ~19 ~-24 ~0 ~19 blue_carpet
fill ~24 ~0 ~19 ~24 ~0 ~19 blue_carpet
fill ~-23 ~0 ~20 ~-23 ~0 ~20 blue_carpet
fill ~23 ~0 ~20 ~23 ~0 ~20 blue_carpet
fill ~-22 ~0 ~21 ~-22 ~0 ~21 blue_carpet
fill ~22 ~0 ~21 ~22 ~0 ~21 blue_carpet
fill ~-21 ~0 ~22 ~-21 ~0 ~22 blue_carpet
fill ~21 ~0 ~22 ~21 ~0 ~22 blue_carpet
fill ~-20 ~0 ~23 ~-20 ~0 ~23 blue_carpet
fill ~20 ~0 ~23 ~20 ~0 ~23 blue_carpet
fill ~-19 ~0 ~24 ~-18 ~0 ~24 blue_carpet
fill ~18 ~0 ~24 ~19 ~0 ~24 blue_carpet
fill ~-18 ~0 ~25 ~-17 ~0 ~25 blue_carpet
fill ~17 ~0 ~25 ~18 ~0 ~25 blue_carpet
fill ~-16 ~0 ~26 ~-15 ~0 ~26 blue_carpet
fill ~15 ~0 ~26 ~16 ~0 ~26 blue_carpet
fill ~-15 ~0 ~27 ~-14 ~0 ~27 blue_carpet
fill ~14 ~0 ~27 ~15 ~0 ~27 blue_carpet
fill ~-13 ~0 ~28 ~-11 ~0 ~28 blue_carpet
fill ~11 ~0 ~28 ~13 ~0 ~28 blue_carpet
fill ~-10 ~0 ~29 ~-8 ~0 ~29 blue_carpet
fill ~8 ~0 ~29 ~10 ~0 ~29 blue_carpet
fill ~-7 ~0 ~30 ~7 ~0 ~30 blue_carpet
fill ~-8 ~0 ~-38 ~8 ~0 ~-38 blue_carpet
fill ~-12 ~0 ~-37 ~-9 ~0 ~-37 blue_carpet
fill ~9 ~0 ~-37 ~12 ~0 ~-37 blue_carpet
fill ~-14 ~0 ~-36 ~-13 ~0 ~-36 blue_carpet
fill ~13 ~0 ~-36 ~14 ~0 ~-36 blue_carpet
fill ~-16 ~0 ~-35 ~-15 ~0 ~-35 blue_carpet
fill ~15 ~0 ~-35 ~16 ~0 ~-35 blue_carpet
fill ~-18 ~0 ~-34 ~-17 ~0 ~-34 blue_carpet
fill ~17 ~0 ~-34 ~18 ~0 ~-34 blue_carpet
fill ~-20 ~0 ~-33 ~-19 ~0 ~-33 blue_carpet
fill ~19 ~0 ~-33 ~20 ~0 ~-33 blue_carpet
fill ~-22 ~0 ~-32 ~-21 ~0 ~-32 blue_carpet
fill ~21 ~0 ~-32 ~22 ~0 ~-32 blue_carpet
fill ~-23 ~0 ~-31 ~-22 ~0 ~-31 blue_carpet
fill ~22 ~0 ~-31 ~23 ~0 ~-31 blue_carpet
fill ~-24 ~0 ~-30 ~-24 ~0 ~-30 blue_carpet
fill ~24 ~0 ~-30 ~24 ~0 ~-30 blue_carpet
fill ~-25 ~0 ~-29 ~-25 ~0 ~-29 blue_carpet
fill ~25 ~0 ~-29 ~25 ~0 ~-29 blue_carpet
fill ~-27 ~0 ~-28 ~-26 ~0 ~-28 blue_carpet
fill ~26 ~0 ~-28 ~27 ~0 ~-28 blue_carpet
fill ~-28 ~0 ~-27 ~-27 ~0 ~-27 blue_carpet
fill ~27 ~0 ~-27 ~28 ~0 ~-27 blue_carpet
fill ~-28 ~0 ~-26 ~-28 ~0 ~-26 blue_carpet
fill ~28 ~0 ~-26 ~28 ~0 ~-26 blue_carpet
fill ~-29 ~0 ~-25 ~-29 ~0 ~-25 blue_carpet
fill ~29 ~0 ~-25 ~29 ~0 ~-25 blue_carpet
fill ~-30 ~0 ~-24 ~-30 ~0 ~-24 blue_carpet
fill ~30 ~0 ~-24 ~30 ~0 ~-24 blue_carpet
fill ~-31 ~0 ~-23 ~-31 ~0 ~-23 blue_carpet
fill ~31 ~0 ~-23 ~31 ~0 ~-23 blue_carpet
fill ~-32 ~0 ~-22 ~-31 ~0 ~-22 blue_carpet
fill ~31 ~0 ~-22 ~32 ~0 ~-22 blue_carpet
fill ~-32 ~0 ~-21 ~-32 ~0 ~-21 blue_carpet
fill ~32 ~0 ~-21 ~32 ~0 ~-21 blue_carpet
fill ~-33 ~0 ~-20 ~-33 ~0 ~-20 blue_carpet
fill ~33 ~0 ~-20 ~33 ~0 ~-20 blue_carpet
fill ~-33 ~0 ~-19 ~-33 ~0 ~-19 blue_carpet
fill ~33 ~0 ~-19 ~33 ~0 ~-19 blue_carpet
fill ~-34 ~0 ~-18 ~-34 ~0 ~-18 blue_carpet
fill ~34 ~0 ~-18 ~34 ~0 ~-18 blue_carpet
fill ~-34 ~0 ~-17 ~-34 ~0 ~-17 blue_carpet
fill ~34 ~0 ~-17 ~34 ~0 ~-17 blue_carpet
fill ~-35 ~0 ~-16 ~-35 ~0 ~-16 blue_carpet
fill ~35 ~0 ~-16 ~35 ~0 ~-16 blue_carpet
fill ~-35 ~0 ~-15 ~-35 ~0 ~-15 blue_carpet
fill ~35 ~0 ~-15 ~35 ~0 ~-15 blue_carpet
fill ~-36 ~0 ~-14 ~-36 ~0 ~-14 blue_carpet
fill ~36 ~0 ~-14 ~36 ~0 ~-14 blue_carpet
fill ~-36 ~0 ~-13 ~-36 ~0 ~-13 blue_carpet
fill ~36 ~0 ~-13 ~36 ~0 ~-13 blue_carpet
fill ~-37 ~0 ~-12 ~-37 ~0 ~-12 blue_carpet
fill ~37 ~0 ~-12 ~37 ~0 ~-12 blue_carpet
fill ~-37 ~0 ~-11 ~-37 ~0 ~-11 blue_carpet
fill ~37 ~0 ~-11 ~37 ~0 ~-11 blue_carpet
fill ~-37 ~0 ~-10 ~-37 ~0 ~-10 blue_carpet
fill ~37 ~0 ~-10 ~37 ~0 ~-10 blue_carpet
fill ~-37 ~0 ~-9 ~-37 ~0 ~-9 blue_carpet
fill ~37 ~0 ~-9 ~37 ~0 ~-9 blue_carpet
fill ~-38 ~0 ~-8 ~-38 ~0 ~-8 blue_carpet
fill ~38 ~0 ~-8 ~38 ~0 ~-8 blue_carpet
fill ~-38 ~0 ~-7 ~-38 ~0 ~-7 blue_carpet
fill ~38 ~0 ~-7 ~38 ~0 ~-7 blue_carpet
fill ~-38 ~0 ~-6 ~-38 ~0 ~-6 blue_carpet
fill ~38 ~0 ~-6 ~38 ~0 ~-6 blue_carpet
fill ~-38 ~0 ~-5 ~-38 ~0 ~-5 blue_carpet
fill ~38 ~0 ~-5 ~38 ~0 ~-5 blue_carpet
fill ~-38 ~0 ~-4 ~-38 ~0 ~-4 blue_carpet
fill ~38 ~0 ~-4 ~38 ~0 ~-4 blue_carpet
fill ~-38 ~0 ~-3 ~-38 ~0 ~-3 blue_carpet
fill ~38 ~0 ~-3 ~38 ~0 ~-3 blue_carpet
fill ~-38 ~0 ~-2 ~-38 ~0 ~-2 blue_carpet
fill ~38 ~0 ~-2 ~38 ~0 ~-2 blue_carpet
fill ~-38 ~0 ~-1 ~-38 ~0 ~-1 blue_carpet
fill ~38 ~0 ~-1 ~38 ~0 ~-1 blue_carpet
fill ~-38 ~0 ~0 ~-38 ~0 ~0 blue_carpet
fill ~38 ~0 ~0 ~38 ~0 ~0 blue_carpet
fill ~-38 ~0 ~1 ~-38 ~0 ~1 blue_carpet
fill ~38 ~0 ~1 ~38 ~0 ~1 blue_carpet
fill ~-38 ~0 ~2 ~-38 ~0 ~2 blue_carpet
fill ~38 ~0 ~2 ~38 ~0 ~2 blue_carpet
fill ~-38 ~0 ~3 ~-38 ~0 ~3 blue_carpet
fill ~38 ~0 ~3 ~38 ~0 ~3 blue_carpet
fill ~-38 ~0 ~4 ~-38 ~0 ~4 blue_carpet
fill ~38 ~0 ~4 ~38 ~0 ~4 blue_carpet
fill ~-38 ~0 ~5 ~-38 ~0 ~5 blue_carpet
fill ~38 ~0 ~5 ~38 ~0 ~5 blue_carpet
fill ~-38 ~0 ~6 ~-38 ~0 ~6 blue_carpet
fill ~38 ~0 ~6 ~38 ~0 ~6 blue_carpet
fill ~-38 ~0 ~7 ~-38 ~0 ~7 blue_carpet
fill ~38 ~0 ~7 ~38 ~0 ~7 blue_carpet
fill ~-38 ~0 ~8 ~-38 ~0 ~8 blue_carpet
fill ~38 ~0 ~8 ~38 ~0 ~8 blue_carpet
fill ~-37 ~0 ~9 ~-37 ~0 ~9 blue_carpet
fill ~37 ~0 ~9 ~37 ~0 ~9 blue_carpet
fill ~-37 ~0 ~10 ~-37 ~0 ~10 blue_carpet
fill ~37 ~0 ~10 ~37 ~0 ~10 blue_carpet
fill ~-37 ~0 ~11 ~-37 ~0 ~11 blue_carpet
fill ~37 ~0 ~11 ~37 ~0 ~11 blue_carpet
fill ~-37 ~0 ~12 ~-37 ~0 ~12 blue_carpet
fill ~37 ~0 ~12 ~37 ~0 ~12 blue_carpet
fill ~-36 ~0 ~13 ~-36 ~0 ~13 blue_carpet
fill ~36 ~0 ~13 ~36 ~0 ~13 blue_carpet
fill ~-36 ~0 ~14 ~-36 ~0 ~14 blue_carpet
fill ~36 ~0 ~14 ~36 ~0 ~14 blue_carpet
fill ~-35 ~0 ~15 ~-35 ~0 ~15 blue_carpet
fill ~35 ~0 ~15 ~35 ~0 ~15 blue_carpet
fill ~-35 ~0 ~16 ~-35 ~0 ~16 blue_carpet
fill ~35 ~0 ~16 ~35 ~0 ~16 blue_carpet
fill ~-34 ~0 ~17 ~-34 ~0 ~17 blue_carpet
fill ~34 ~0 ~17 ~34 ~0 ~17 blue_carpet
fill ~-34 ~0 ~18 ~-34 ~0 ~18 blue_carpet
fill ~34 ~0 ~18 ~34 ~0 ~18 blue_carpet
fill ~-33 ~0 ~19 ~-33 ~0 ~19 blue_carpet
fill ~33 ~0 ~19 ~33 ~0 ~19 blue_carpet
fill ~-33 ~0 ~20 ~-33 ~0 ~20 blue_carpet
fill ~33 ~0 ~20 ~33 ~0 ~20 blue_carpet
fill ~-32 ~0 ~21 ~-32 ~0 ~21 blue_carpet
fill ~32 ~0 ~21 ~32 ~0 ~21 blue_carpet
fill ~-32 ~0 ~22 ~-31 ~0 ~22 blue_carpet
fill ~31 ~0 ~22 ~32 ~0 ~22 blue_carpet
fill ~-31 ~0 ~23 ~-31 ~0 ~23 blue_carpet
fill ~31 ~0 ~23 ~31 ~0 ~23 blue_carpet
fill ~-30 ~0 ~24 ~-30 ~0 ~24 blue_carpet
fill ~30 ~0 ~24 ~30 ~0 ~24 blue_carpet
fill ~-29 ~0 ~25 ~-29 ~0 ~25 blue_carpet
fill ~29 ~0 ~25 ~29 ~0 ~25 blue_carpet
fill ~-28 ~0 ~26 ~-28 ~0 ~26 blue_carpet
fill ~28 ~0 ~26 ~28 ~0 ~26 blue_carpet
fill ~-28 ~0 ~27 ~-27 ~0 ~27 blue_carpet
fill ~27 ~0 ~27 ~28 ~0 ~27 blue_carpet
fill ~-27 ~0 ~28 ~-26 ~0 ~28 blue_carpet
fill ~26 ~0 ~28 ~27 ~0 ~28 blue_carpet
fill ~-25 ~0 ~29 ~-25 ~0 ~29 blue_carpet
fill ~25 ~0 ~29 ~25 ~0 ~29 blue_carpet
fill ~-24 ~0 ~30 ~-24 ~0 ~30 blue_carpet
fill ~24 ~0 ~30 ~24 ~0 ~30 blue_carpet
fill ~-23 ~0 ~31 ~-22 ~0 ~31 blue_carpet
fill ~22 ~0 ~31 ~23 ~0 ~31 blue_carpet
fill ~-22 ~0 ~32 ~-21 ~0 ~32 blue_carpet
fill ~21 ~0 ~32 ~22 ~0 ~32 blue_carpet
fill ~-20 ~0 ~33 ~-19 ~0 ~33 blue_carpet
fill ~19 ~0 ~33 ~20 ~0 ~33 blue_carpet
fill ~-18 ~0 ~34 ~-17 ~0 ~34 blue_carpet
fill ~17 ~0 ~34 ~18 ~0 ~34 blue_carpet
fill ~-16 ~0 ~35 ~-15 ~0 ~35 blue_carpet
fill ~15 ~0 ~35 ~16 ~0 ~35 blue_carpet
fill ~-14 ~0 ~36 ~-13 ~0 ~36 blue_carpet
fill ~13 ~0 ~36 ~14 ~0 ~36 blue_carpet
fill ~-12 ~0 ~37 ~-9 ~0 ~37 blue_carpet
fill ~9 ~0 ~37 ~12 ~0 ~37 blue_carpet
fill ~-8 ~0 ~38 ~8 ~0 ~38 blue_carpet
fill ~-4 ~0 ~-24 ~4 ~0 ~-24 yellow_carpet
fill ~-8 ~0 ~-23 ~-5 ~0 ~-23 yellow_carpet
fill ~5 ~0 ~-23 ~8 ~0 ~-23 yellow_carpet
fill ~-10 ~0 ~-22 ~-9 ~0 ~-22 yellow_carpet
fill ~9 ~0 ~-22 ~10 ~0 ~-22 yellow_carpet
fill ~-12 ~0 ~-21 ~-11 ~0 ~-21 yellow_carpet
fill ~11 ~0 ~-21 ~12 ~0 ~-21 yellow_carpet
fill ~-13 ~0 ~-20 ~-13 ~0 ~-20 yellow_carpet
fill ~13 ~0 ~-20 ~13 ~0 ~-20 yellow_carpet
fill ~-15 ~0 ~-19 ~-14 ~0 ~-19 yellow_carpet
fill ~14 ~0 ~-19 ~15 ~0 ~-19 yellow_carpet
fill ~-16 ~0 ~-18 ~-16 ~0 ~-18 yellow_carpet
fill ~16 ~0 ~-18 ~16 ~0 ~-18 yellow_carpet
fill ~-17 ~0 ~-17 ~-17 ~0 ~-17 yellow_carpet
fill ~17 ~0 ~-17 ~17 ~0 ~-17 yellow_carpet
fill ~-18 ~0 ~-16 ~-18 ~0 ~-16 yellow_carpet
fill ~18 ~0 ~-16 ~18 ~0 ~-16 yellow_carpet
fill ~-19 ~0 ~-15 ~-19 ~0 ~-15 yellow_carpet
fill ~19 ~0 ~-15 ~19 ~0 ~-15 yellow_carpet
fill ~-19 ~0 ~-14 ~-19 ~0 ~-14 yellow_carpet
fill ~19 ~0 ~-14 ~19 ~0 ~-14 yellow_carpet
fill ~-20 ~0 ~-13 ~-20 ~0 ~-13 yellow_carpet
fill ~20 ~0 ~-13 ~20 ~0 ~-13 yellow_carpet
fill ~-21 ~0 ~-12 ~-21 ~0 ~-12 yellow_carpet
fill ~21 ~0 ~-12 ~21 ~0 ~-12 yellow_carpet
fill ~-21 ~0 ~-11 ~-21 ~0 ~-11 yellow_carpet
fill ~21 ~0 ~-11 ~21 ~0 ~-11 yellow_carpet
fill ~-22 ~0 ~-10 ~-22 ~0 ~-10 yellow_carpet
fill ~22 ~0 ~-10 ~22 ~0 ~-10 yellow_carpet
fill ~-22 ~0 ~-9 ~-22 ~0 ~-9 yellow_carpet
fill ~22 ~0 ~-9 ~22 ~0 ~-9 yellow_carpet
fill ~-23 ~0 ~-8 ~-23 ~0 ~-8 yellow_carpet
fill ~23 ~0 ~-8 ~23 ~0 ~-8 yellow_carpet
fill ~-23 ~0 ~-7 ~-23 ~0 ~-7 yellow_carpet
fill ~23 ~0 ~-7 ~23 ~0 ~-7 yellow_carpet
fill ~-23 ~0 ~-6 ~-23 ~0 ~-6 yellow_carpet
fill ~23 ~0 ~-6 ~23 ~0 ~-6 yellow_carpet
fill ~-23 ~0 ~-5 ~-23 ~0 ~-5 yellow_carpet
fill ~23 ~0 ~-5 ~23 ~0 ~-5 yellow_carpet
fill ~-24 ~0 ~-4 ~-24 ~0 ~-4 yellow_carpet
fill ~24 ~0 ~-4 ~24 ~0 ~-4 yellow_carpet
fill ~-24 ~0 ~-3 ~-24 ~0 ~-3 yellow_carpet
fill ~24 ~0 ~-3 ~24 ~0 ~-3 yellow_carpet
fill ~-24 ~0 ~-2 ~-24 ~0 ~-2 yellow_carpet
fill ~24 ~0 ~-2 ~24 ~0 ~-2 yellow_carpet
fill ~-24 ~0 ~-1 ~-24 ~0 ~-1 yellow_carpet
fill ~24 ~0 ~-1 ~24 ~0 ~-1 yellow_carpet
fill ~-24 ~0 ~0 ~-24 ~0 ~0 yellow_carpet
fill ~24 ~0 ~0 ~24 ~0 ~0 yellow_carpet
fill ~-24 ~0 ~1 ~-24 ~0 ~1 yellow_carpet
fill ~24 ~0 ~1 ~24 ~0 ~1 yellow_carpet
fill ~-24 ~0 ~2 ~-24 ~0 ~2 yellow_carpet
fill ~24 ~0 ~2 ~24 ~0 ~2 yellow_carpet
fill ~-24 ~0 ~3 ~-24 ~0 ~3 yellow_carpet
fill ~24 ~0 ~3 ~24 ~0 ~3 yellow_carpet
fill ~-24 ~0 ~4 ~-24 ~0 ~4 yellow_carpet
fill ~24 ~0 ~4 ~24 ~0 ~4 yellow_carpet
fill ~-23 ~0 ~5 ~-23 ~0 ~5 yellow_carpet
fill ~23 ~0 ~5 ~23 ~0 ~5 yellow_carpet
fill ~-23 ~0 ~6 ~-23 ~0 ~6 yellow_carpet
fill ~23 ~0 ~6 ~23 ~0 ~6 yellow_carpet
fill ~-23 ~0 ~7 ~-23 ~0 ~7 yellow_carpet
fill ~23 ~0 ~7 ~23 ~0 ~7 yellow_carpet
fill ~-23 ~0 ~8 ~-23 ~0 ~8 yellow_carpet
fill ~23 ~0 ~8 ~23 ~0 ~8 yellow_carpet
fill ~-22 ~0 ~9 ~-22 ~0 ~9 yellow_carpet
fill ~22 ~0 ~9 ~22 ~0 ~9 yellow_carpet
fill ~-22 ~0 ~10 ~-22 ~0 ~10 yellow_carpet
fill ~22 ~0 ~10 ~22 ~0 ~10 yellow_carpet
fill ~-21 ~0 ~11 ~-21 ~0 ~11 yellow_carpet
fill ~21 ~0 ~11 ~21 ~0 ~11 yellow_carpet
fill ~-21 ~0 ~12 ~-21 ~0 ~12 yellow_carpet
fill ~21 ~0 ~12 ~21 ~0 ~12 yellow_carpet
fill ~-20 ~0 ~13 ~-20 ~0 ~13 yellow_carpet
fill ~20 ~0 ~13 ~20 ~0 ~13 yellow_carpet
fill ~-19 ~0 ~14 ~-19 ~0 ~14 yellow_carpet
fill ~19 ~0 ~14 ~19 ~0 ~14 yellow_carpet
fill ~-19 ~0 ~15 ~-19 ~0 ~15 yellow_carpet
fill ~19 ~0 ~15 ~19 ~0 ~15 yellow_carpet
fill ~-18 ~0 ~16 ~-18 ~0 ~16 yellow_carpet
fill ~18 ~0 ~16 ~18 ~0 ~16 yellow_carpet
fill ~-17 ~0 ~17 ~-17 ~0 ~17 yellow_carpet
fill ~17 ~0 ~17 ~17 ~0 ~17 yellow_carpet
fill ~-16 ~0 ~18 ~-16 ~0 ~18 yellow_carpet
fill ~16 ~0 ~18 ~16 ~0 ~18 yellow_carpet
fill ~-15 ~0 ~19 ~-14 ~0 ~19 yellow_carpet
fill ~14 ~0 ~19 ~15 ~0 ~19 yellow_carpet
fill ~-13 ~0 ~20 ~-13 ~0 ~20 yellow_carpet
fill ~13 ~0 ~20 ~13 ~0 ~20 yellow_carpet
fill ~-12 ~0 ~21 ~-11 ~0 ~21 yellow_carpet
fill ~11 ~0 ~21 ~12 ~0 ~21 yellow_carpet
fill ~-10 ~0 ~22 ~-9 ~0 ~22 yellow_carpet
fill ~9 ~0 ~22 ~10 ~0 ~22 yellow_carpet
fill ~-8 ~0 ~23 ~-5 ~0 ~23 yellow_carpet
fill ~5 ~0 ~23 ~8 ~0 ~23 yellow_carpet
fill ~-4 ~0 ~24 ~4 ~0 ~24 yellow_carpet
fill ~-4 ~-1 ~49 ~4 ~-1 ~49 polished_diorite
fill ~-4 ~-1 ~50 ~4 ~-1 ~50 polished_diorite
fill ~-4 ~-1 ~51 ~4 ~-1 ~51 polished_diorite
fill ~-4 ~-1 ~52 ~4 ~-1 ~52 polished_diorite
fill ~-4 ~-1 ~53 ~4 ~-1 ~53 polished_diorite
fill ~-4 ~-1 ~54 ~4 ~-1 ~54 polished_diorite
fill ~-4 ~-1 ~55 ~4 ~-1 ~55 polished_diorite
fill ~-4 ~-1 ~56 ~4 ~-1 ~56 polished_diorite
fill ~-4 ~-1 ~57 ~4 ~-1 ~57 polished_diorite
