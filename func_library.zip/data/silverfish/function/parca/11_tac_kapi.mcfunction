fill ~-10 ~0 ~48 ~10 ~22 ~53 calcite
fill ~-10 ~23 ~48 ~10 ~23 ~53 smooth_quartz
fill ~-10 ~0 ~53 ~-10 ~23 ~53 quartz_pillar[axis=y]
setblock ~-10 ~24 ~53 gold_block
fill ~10 ~0 ~53 ~10 ~23 ~53 quartz_pillar[axis=y]
setblock ~10 ~24 ~53 gold_block
fill ~-9 ~20 ~53 ~9 ~20 ~53 waxed_cut_copper
fill ~-6 ~0 ~53 ~6 ~15 ~53 chiseled_quartz_block
setblock ~-8 ~12 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~8 ~12 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~-9 ~13 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~-7 ~13 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~7 ~13 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~9 ~13 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~-8 ~14 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~8 ~14 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~-9 ~15 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~-7 ~15 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~7 ~15 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~9 ~15 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~-8 ~16 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~8 ~16 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~-9 ~17 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~-7 ~17 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~7 ~17 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~9 ~17 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~-8 ~18 ~54 smooth_quartz_stairs[facing=south,half=top]
setblock ~8 ~18 ~54 smooth_quartz_stairs[facing=south,half=top]
fill ~-4 ~0 ~45 ~4 ~0 ~54 air
fill ~-4 ~1 ~45 ~4 ~1 ~54 air
fill ~-4 ~2 ~45 ~4 ~2 ~54 air
fill ~-4 ~3 ~45 ~4 ~3 ~54 air
fill ~-4 ~4 ~45 ~4 ~4 ~54 air
fill ~-4 ~5 ~45 ~4 ~5 ~54 air
fill ~-4 ~6 ~45 ~4 ~6 ~54 air
fill ~-4 ~7 ~45 ~4 ~7 ~54 air
fill ~-4 ~8 ~45 ~4 ~8 ~54 air
fill ~-4 ~9 ~45 ~4 ~9 ~54 air
fill ~-3 ~10 ~48 ~3 ~10 ~54 air
fill ~-2 ~11 ~48 ~2 ~11 ~54 air
fill ~-1 ~12 ~48 ~1 ~12 ~54 air
fill ~0 ~13 ~48 ~0 ~13 ~54 air
fill ~-3 ~0 ~45 ~3 ~0 ~45 air
fill ~-3 ~0 ~40 ~3 ~0 ~40 cyan_carpet
fill ~-3 ~0 ~41 ~3 ~0 ~41 cyan_carpet
fill ~-3 ~0 ~42 ~3 ~0 ~42 cyan_carpet
fill ~-3 ~0 ~43 ~3 ~0 ~43 cyan_carpet
fill ~-3 ~0 ~44 ~3 ~0 ~44 cyan_carpet
fill ~-3 ~0 ~45 ~3 ~0 ~45 cyan_carpet
fill ~-3 ~0 ~46 ~3 ~0 ~46 cyan_carpet
fill ~-3 ~0 ~47 ~3 ~0 ~47 cyan_carpet
setblock ~-13 ~0 ~52 moss_block
setblock ~-13 ~1 ~52 flowering_azalea
setblock ~13 ~0 ~52 moss_block
setblock ~13 ~1 ~52 flowering_azalea
fill ~54 ~0 ~0 ~54 ~2 ~0 diorite_wall
setblock ~54 ~3 ~0 lantern
fill ~52 ~0 ~14 ~52 ~2 ~14 diorite_wall
setblock ~52 ~3 ~14 lantern
fill ~47 ~0 ~27 ~47 ~2 ~27 diorite_wall
setblock ~47 ~3 ~27 lantern
fill ~38 ~0 ~38 ~38 ~2 ~38 diorite_wall
setblock ~38 ~3 ~38 lantern
fill ~27 ~0 ~47 ~27 ~2 ~47 diorite_wall
setblock ~27 ~3 ~47 lantern
fill ~14 ~0 ~52 ~14 ~2 ~52 diorite_wall
setblock ~14 ~3 ~52 lantern
fill ~-14 ~0 ~52 ~-14 ~2 ~52 diorite_wall
setblock ~-14 ~3 ~52 lantern
fill ~-27 ~0 ~47 ~-27 ~2 ~47 diorite_wall
setblock ~-27 ~3 ~47 lantern
fill ~-38 ~0 ~38 ~-38 ~2 ~38 diorite_wall
setblock ~-38 ~3 ~38 lantern
fill ~-47 ~0 ~27 ~-47 ~2 ~27 diorite_wall
setblock ~-47 ~3 ~27 lantern
fill ~-52 ~0 ~14 ~-52 ~2 ~14 diorite_wall
setblock ~-52 ~3 ~14 lantern
fill ~-54 ~0 ~0 ~-54 ~2 ~0 diorite_wall
setblock ~-54 ~3 ~0 lantern
fill ~-52 ~0 ~-14 ~-52 ~2 ~-14 diorite_wall
setblock ~-52 ~3 ~-14 lantern
fill ~-47 ~0 ~-27 ~-47 ~2 ~-27 diorite_wall
setblock ~-47 ~3 ~-27 lantern
fill ~-38 ~0 ~-38 ~-38 ~2 ~-38 diorite_wall
setblock ~-38 ~3 ~-38 lantern
fill ~-27 ~0 ~-47 ~-27 ~2 ~-47 diorite_wall
setblock ~-27 ~3 ~-47 lantern
fill ~-14 ~0 ~-52 ~-14 ~2 ~-52 diorite_wall
setblock ~-14 ~3 ~-52 lantern
fill ~0 ~0 ~-54 ~0 ~2 ~-54 diorite_wall
setblock ~0 ~3 ~-54 lantern
fill ~14 ~0 ~-52 ~14 ~2 ~-52 diorite_wall
setblock ~14 ~3 ~-52 lantern
fill ~27 ~0 ~-47 ~27 ~2 ~-47 diorite_wall
setblock ~27 ~3 ~-47 lantern
fill ~38 ~0 ~-38 ~38 ~2 ~-38 diorite_wall
setblock ~38 ~3 ~-38 lantern
fill ~47 ~0 ~-27 ~47 ~2 ~-27 diorite_wall
setblock ~47 ~3 ~-27 lantern
fill ~52 ~0 ~-14 ~52 ~2 ~-14 diorite_wall
setblock ~52 ~3 ~-14 lantern
tellraw @s {text:"Kütüphane hazır! 16968 oymalı kitaplık, 101808 kitap yuvası.",color:"green"}
