fill ~-9 ~10 ~-47 ~9 ~10 ~-47 spruce_planks
fill ~-13 ~10 ~-46 ~13 ~10 ~-46 spruce_planks
fill ~-16 ~10 ~-45 ~16 ~10 ~-45 spruce_planks
fill ~-19 ~10 ~-44 ~19 ~10 ~-44 spruce_planks
fill ~-21 ~10 ~-43 ~21 ~10 ~-43 spruce_planks
fill ~-23 ~10 ~-42 ~23 ~10 ~-42 spruce_planks
fill ~-24 ~10 ~-41 ~24 ~10 ~-41 spruce_planks
fill ~-26 ~10 ~-40 ~26 ~10 ~-40 spruce_planks
fill ~-27 ~10 ~-39 ~27 ~10 ~-39 spruce_planks
fill ~-29 ~10 ~-38 ~29 ~10 ~-38 spruce_planks
fill ~-30 ~10 ~-37 ~30 ~10 ~-37 spruce_planks
fill ~-31 ~10 ~-36 ~31 ~10 ~-36 spruce_planks
fill ~-32 ~10 ~-35 ~32 ~10 ~-35 spruce_planks
fill ~-33 ~10 ~-34 ~33 ~10 ~-34 spruce_planks
fill ~-34 ~10 ~-33 ~34 ~10 ~-33 spruce_planks
fill ~-35 ~10 ~-32 ~35 ~10 ~-32 spruce_planks
fill ~-36 ~10 ~-31 ~36 ~10 ~-31 spruce_planks
fill ~-37 ~10 ~-30 ~37 ~10 ~-30 spruce_planks
fill ~-38 ~10 ~-29 ~38 ~10 ~-29 spruce_planks
fill ~-38 ~10 ~-28 ~38 ~10 ~-28 spruce_planks
fill ~-39 ~10 ~-27 ~39 ~10 ~-27 spruce_planks
fill ~-40 ~10 ~-26 ~40 ~10 ~-26 spruce_planks
fill ~-40 ~10 ~-25 ~40 ~10 ~-25 spruce_planks
fill ~-41 ~10 ~-24 ~41 ~10 ~-24 spruce_planks
fill ~-42 ~10 ~-23 ~42 ~10 ~-23 spruce_planks
fill ~-42 ~10 ~-22 ~42 ~10 ~-22 spruce_planks
fill ~-43 ~10 ~-21 ~43 ~10 ~-21 spruce_planks
fill ~-43 ~10 ~-20 ~43 ~10 ~-20 spruce_planks
fill ~-44 ~10 ~-19 ~-7 ~10 ~-19 spruce_planks
fill ~7 ~10 ~-19 ~44 ~10 ~-19 spruce_planks
fill ~-44 ~10 ~-18 ~-9 ~10 ~-18 spruce_planks
fill ~9 ~10 ~-18 ~44 ~10 ~-18 spruce_planks
fill ~-44 ~10 ~-17 ~-11 ~10 ~-17 spruce_planks
fill ~11 ~10 ~-17 ~44 ~10 ~-17 spruce_planks
fill ~-45 ~10 ~-16 ~-12 ~10 ~-16 spruce_planks
fill ~12 ~10 ~-16 ~45 ~10 ~-16 spruce_planks
fill ~-45 ~10 ~-15 ~-14 ~10 ~-15 spruce_planks
fill ~14 ~10 ~-15 ~45 ~10 ~-15 spruce_planks
fill ~-45 ~10 ~-14 ~-15 ~10 ~-14 spruce_planks
fill ~15 ~10 ~-14 ~45 ~10 ~-14 spruce_planks
fill ~-46 ~10 ~-13 ~-16 ~10 ~-13 spruce_planks
fill ~16 ~10 ~-13 ~46 ~10 ~-13 spruce_planks
fill ~-46 ~10 ~-12 ~-16 ~10 ~-12 spruce_planks
fill ~16 ~10 ~-12 ~46 ~10 ~-12 spruce_planks
fill ~-46 ~10 ~-11 ~-17 ~10 ~-11 spruce_planks
fill ~17 ~10 ~-11 ~46 ~10 ~-11 spruce_planks
fill ~-46 ~10 ~-10 ~-18 ~10 ~-10 spruce_planks
fill ~18 ~10 ~-10 ~46 ~10 ~-10 spruce_planks
fill ~-47 ~10 ~-9 ~-18 ~10 ~-9 spruce_planks
fill ~18 ~10 ~-9 ~47 ~10 ~-9 spruce_planks
fill ~-47 ~10 ~-8 ~-19 ~10 ~-8 spruce_planks
fill ~19 ~10 ~-8 ~47 ~10 ~-8 spruce_planks
fill ~-47 ~10 ~-7 ~-19 ~10 ~-7 spruce_planks
fill ~19 ~10 ~-7 ~47 ~10 ~-7 spruce_planks
fill ~-47 ~10 ~-6 ~-20 ~10 ~-6 spruce_planks
fill ~20 ~10 ~-6 ~47 ~10 ~-6 spruce_planks
fill ~-47 ~10 ~-5 ~-20 ~10 ~-5 spruce_planks
fill ~20 ~10 ~-5 ~47 ~10 ~-5 spruce_planks
fill ~-47 ~10 ~-4 ~-20 ~10 ~-4 spruce_planks
fill ~20 ~10 ~-4 ~47 ~10 ~-4 spruce_planks
fill ~-47 ~10 ~-3 ~-20 ~10 ~-3 spruce_planks
fill ~20 ~10 ~-3 ~47 ~10 ~-3 spruce_planks
fill ~-47 ~10 ~-2 ~-20 ~10 ~-2 spruce_planks
fill ~20 ~10 ~-2 ~47 ~10 ~-2 spruce_planks
fill ~-47 ~10 ~-1 ~-20 ~10 ~-1 spruce_planks
fill ~20 ~10 ~-1 ~47 ~10 ~-1 spruce_planks
fill ~-47 ~10 ~0 ~-20 ~10 ~0 spruce_planks
fill ~20 ~10 ~0 ~47 ~10 ~0 spruce_planks
fill ~-47 ~10 ~1 ~-20 ~10 ~1 spruce_planks
fill ~20 ~10 ~1 ~47 ~10 ~1 spruce_planks
fill ~-47 ~10 ~2 ~-20 ~10 ~2 spruce_planks
fill ~20 ~10 ~2 ~47 ~10 ~2 spruce_planks
fill ~-47 ~10 ~3 ~-20 ~10 ~3 spruce_planks
fill ~20 ~10 ~3 ~47 ~10 ~3 spruce_planks
fill ~-47 ~10 ~4 ~-20 ~10 ~4 spruce_planks
fill ~20 ~10 ~4 ~47 ~10 ~4 spruce_planks
fill ~-47 ~10 ~5 ~-20 ~10 ~5 spruce_planks
fill ~20 ~10 ~5 ~47 ~10 ~5 spruce_planks
fill ~-47 ~10 ~6 ~-20 ~10 ~6 spruce_planks
fill ~20 ~10 ~6 ~47 ~10 ~6 spruce_planks
fill ~-47 ~10 ~7 ~-19 ~10 ~7 spruce_planks
fill ~19 ~10 ~7 ~47 ~10 ~7 spruce_planks
fill ~-47 ~10 ~8 ~-19 ~10 ~8 spruce_planks
fill ~19 ~10 ~8 ~47 ~10 ~8 spruce_planks
fill ~-47 ~10 ~9 ~-18 ~10 ~9 spruce_planks
fill ~18 ~10 ~9 ~47 ~10 ~9 spruce_planks
fill ~-46 ~10 ~10 ~-18 ~10 ~10 spruce_planks
fill ~18 ~10 ~10 ~46 ~10 ~10 spruce_planks
fill ~-46 ~10 ~11 ~-17 ~10 ~11 spruce_planks
fill ~17 ~10 ~11 ~46 ~10 ~11 spruce_planks
fill ~-46 ~10 ~12 ~-16 ~10 ~12 spruce_planks
fill ~16 ~10 ~12 ~46 ~10 ~12 spruce_planks
fill ~-46 ~10 ~13 ~-16 ~10 ~13 spruce_planks
fill ~16 ~10 ~13 ~46 ~10 ~13 spruce_planks
fill ~-45 ~10 ~14 ~-15 ~10 ~14 spruce_planks
fill ~15 ~10 ~14 ~45 ~10 ~14 spruce_planks
fill ~-45 ~10 ~15 ~-14 ~10 ~15 spruce_planks
fill ~14 ~10 ~15 ~45 ~10 ~15 spruce_planks
fill ~-45 ~10 ~16 ~-12 ~10 ~16 spruce_planks
fill ~12 ~10 ~16 ~45 ~10 ~16 spruce_planks
fill ~-44 ~10 ~17 ~-11 ~10 ~17 spruce_planks
fill ~11 ~10 ~17 ~44 ~10 ~17 spruce_planks
fill ~-44 ~10 ~18 ~-9 ~10 ~18 spruce_planks
fill ~9 ~10 ~18 ~44 ~10 ~18 spruce_planks
fill ~-44 ~10 ~19 ~-7 ~10 ~19 spruce_planks
fill ~7 ~10 ~19 ~44 ~10 ~19 spruce_planks
fill ~-43 ~10 ~20 ~43 ~10 ~20 spruce_planks
fill ~-43 ~10 ~21 ~43 ~10 ~21 spruce_planks
fill ~-42 ~10 ~22 ~42 ~10 ~22 spruce_planks
fill ~-42 ~10 ~23 ~42 ~10 ~23 spruce_planks
fill ~-41 ~10 ~24 ~41 ~10 ~24 spruce_planks
fill ~-40 ~10 ~25 ~40 ~10 ~25 spruce_planks
fill ~-40 ~10 ~26 ~40 ~10 ~26 spruce_planks
fill ~-39 ~10 ~27 ~39 ~10 ~27 spruce_planks
fill ~-38 ~10 ~28 ~38 ~10 ~28 spruce_planks
fill ~-38 ~10 ~29 ~38 ~10 ~29 spruce_planks
fill ~-37 ~10 ~30 ~37 ~10 ~30 spruce_planks
fill ~-36 ~10 ~31 ~36 ~10 ~31 spruce_planks
fill ~-35 ~10 ~32 ~35 ~10 ~32 spruce_planks
fill ~-34 ~10 ~33 ~34 ~10 ~33 spruce_planks
fill ~-33 ~10 ~34 ~33 ~10 ~34 spruce_planks
fill ~-32 ~10 ~35 ~32 ~10 ~35 spruce_planks
fill ~-31 ~10 ~36 ~31 ~10 ~36 spruce_planks
fill ~-30 ~10 ~37 ~30 ~10 ~37 spruce_planks
fill ~-29 ~10 ~38 ~29 ~10 ~38 spruce_planks
fill ~-27 ~10 ~39 ~27 ~10 ~39 spruce_planks
fill ~-26 ~10 ~40 ~26 ~10 ~40 spruce_planks
fill ~-24 ~10 ~41 ~24 ~10 ~41 spruce_planks
fill ~-23 ~10 ~42 ~23 ~10 ~42 spruce_planks
fill ~-21 ~10 ~43 ~21 ~10 ~43 spruce_planks
fill ~-19 ~10 ~44 ~19 ~10 ~44 spruce_planks
fill ~-16 ~10 ~45 ~16 ~10 ~45 spruce_planks
fill ~-13 ~10 ~46 ~13 ~10 ~46 spruce_planks
fill ~-9 ~10 ~47 ~9 ~10 ~47 spruce_planks
setblock ~-40 ~10 ~-20 ochre_froglight
setblock ~-40 ~10 ~-15 ochre_froglight
setblock ~-40 ~10 ~-10 ochre_froglight
setblock ~-40 ~10 ~-5 ochre_froglight
setblock ~-40 ~10 ~0 ochre_froglight
setblock ~-40 ~10 ~5 ochre_froglight
setblock ~-40 ~10 ~10 ochre_froglight
setblock ~-40 ~10 ~15 ochre_froglight
setblock ~-40 ~10 ~20 ochre_froglight
setblock ~-35 ~10 ~-25 ochre_froglight
setblock ~-35 ~10 ~-20 ochre_froglight
setblock ~-35 ~10 ~-15 ochre_froglight
setblock ~-35 ~10 ~-10 ochre_froglight
setblock ~-35 ~10 ~-5 ochre_froglight
setblock ~-35 ~10 ~0 ochre_froglight
setblock ~-35 ~10 ~5 ochre_froglight
setblock ~-35 ~10 ~10 ochre_froglight
setblock ~-35 ~10 ~15 ochre_froglight
setblock ~-35 ~10 ~20 ochre_froglight
setblock ~-35 ~10 ~25 ochre_froglight
setblock ~-30 ~10 ~-30 ochre_froglight
setblock ~-30 ~10 ~-25 ochre_froglight
setblock ~-30 ~10 ~-20 ochre_froglight
setblock ~-30 ~10 ~-15 ochre_froglight
setblock ~-30 ~10 ~-10 ochre_froglight
setblock ~-30 ~10 ~-5 ochre_froglight
setblock ~-30 ~10 ~0 ochre_froglight
setblock ~-30 ~10 ~5 ochre_froglight
setblock ~-30 ~10 ~10 ochre_froglight
setblock ~-30 ~10 ~15 ochre_froglight
setblock ~-30 ~10 ~20 ochre_froglight
setblock ~-30 ~10 ~25 ochre_froglight
setblock ~-30 ~10 ~30 ochre_froglight
setblock ~-25 ~10 ~-35 ochre_froglight
setblock ~-25 ~10 ~-30 ochre_froglight
setblock ~-25 ~10 ~-25 ochre_froglight
setblock ~-25 ~10 ~-20 ochre_froglight
setblock ~-25 ~10 ~-15 ochre_froglight
setblock ~-25 ~10 ~-10 ochre_froglight
setblock ~-25 ~10 ~-5 ochre_froglight
setblock ~-25 ~10 ~0 ochre_froglight
setblock ~-25 ~10 ~5 ochre_froglight
setblock ~-25 ~10 ~10 ochre_froglight
setblock ~-25 ~10 ~15 ochre_froglight
setblock ~-25 ~10 ~20 ochre_froglight
setblock ~-25 ~10 ~25 ochre_froglight
setblock ~-25 ~10 ~30 ochre_froglight
setblock ~-25 ~10 ~35 ochre_froglight
setblock ~-20 ~10 ~-40 ochre_froglight
setblock ~-20 ~10 ~-35 ochre_froglight
setblock ~-20 ~10 ~-30 ochre_froglight
setblock ~-20 ~10 ~-25 ochre_froglight
setblock ~-20 ~10 ~-20 ochre_froglight
setblock ~-20 ~10 ~-15 ochre_froglight
setblock ~-20 ~10 ~-10 ochre_froglight
setblock ~-20 ~10 ~10 ochre_froglight
setblock ~-20 ~10 ~15 ochre_froglight
setblock ~-20 ~10 ~20 ochre_froglight
setblock ~-20 ~10 ~25 ochre_froglight
setblock ~-20 ~10 ~30 ochre_froglight
setblock ~-20 ~10 ~35 ochre_froglight
setblock ~-20 ~10 ~40 ochre_froglight
setblock ~-15 ~10 ~-40 ochre_froglight
setblock ~-15 ~10 ~-35 ochre_froglight
setblock ~-15 ~10 ~-30 ochre_froglight
setblock ~-15 ~10 ~-25 ochre_froglight
setblock ~-15 ~10 ~-20 ochre_froglight
setblock ~-15 ~10 ~20 ochre_froglight
setblock ~-15 ~10 ~25 ochre_froglight
setblock ~-15 ~10 ~30 ochre_froglight
setblock ~-15 ~10 ~35 ochre_froglight
setblock ~-15 ~10 ~40 ochre_froglight
setblock ~-10 ~10 ~-40 ochre_froglight
setblock ~-10 ~10 ~-35 ochre_froglight
setblock ~-10 ~10 ~-30 ochre_froglight
setblock ~-10 ~10 ~-25 ochre_froglight
setblock ~-10 ~10 ~-20 ochre_froglight
setblock ~-10 ~10 ~20 ochre_froglight
setblock ~-10 ~10 ~25 ochre_froglight
setblock ~-10 ~10 ~30 ochre_froglight
setblock ~-10 ~10 ~35 ochre_froglight
setblock ~-10 ~10 ~40 ochre_froglight
setblock ~-5 ~10 ~-40 ochre_froglight
setblock ~-5 ~10 ~-35 ochre_froglight
setblock ~-5 ~10 ~-30 ochre_froglight
setblock ~-5 ~10 ~-25 ochre_froglight
setblock ~-5 ~10 ~25 ochre_froglight
setblock ~-5 ~10 ~30 ochre_froglight
setblock ~-5 ~10 ~35 ochre_froglight
setblock ~-5 ~10 ~40 ochre_froglight
setblock ~0 ~10 ~-40 ochre_froglight
setblock ~0 ~10 ~-35 ochre_froglight
setblock ~0 ~10 ~-30 ochre_froglight
setblock ~0 ~10 ~-25 ochre_froglight
setblock ~0 ~10 ~25 ochre_froglight
setblock ~0 ~10 ~30 ochre_froglight
setblock ~0 ~10 ~35 ochre_froglight
setblock ~0 ~10 ~40 ochre_froglight
setblock ~5 ~10 ~-40 ochre_froglight
setblock ~5 ~10 ~-35 ochre_froglight
setblock ~5 ~10 ~-30 ochre_froglight
setblock ~5 ~10 ~-25 ochre_froglight
setblock ~5 ~10 ~25 ochre_froglight
setblock ~5 ~10 ~30 ochre_froglight
setblock ~5 ~10 ~35 ochre_froglight
setblock ~5 ~10 ~40 ochre_froglight
setblock ~10 ~10 ~-40 ochre_froglight
setblock ~10 ~10 ~-35 ochre_froglight
setblock ~10 ~10 ~-30 ochre_froglight
setblock ~10 ~10 ~-25 ochre_froglight
setblock ~10 ~10 ~-20 ochre_froglight
setblock ~10 ~10 ~20 ochre_froglight
setblock ~10 ~10 ~25 ochre_froglight
setblock ~10 ~10 ~30 ochre_froglight
setblock ~10 ~10 ~35 ochre_froglight
setblock ~10 ~10 ~40 ochre_froglight
setblock ~15 ~10 ~-40 ochre_froglight
setblock ~15 ~10 ~-35 ochre_froglight
setblock ~15 ~10 ~-30 ochre_froglight
setblock ~15 ~10 ~-25 ochre_froglight
setblock ~15 ~10 ~-20 ochre_froglight
setblock ~15 ~10 ~20 ochre_froglight
setblock ~15 ~10 ~25 ochre_froglight
setblock ~15 ~10 ~30 ochre_froglight
setblock ~15 ~10 ~35 ochre_froglight
setblock ~15 ~10 ~40 ochre_froglight
setblock ~20 ~10 ~-40 ochre_froglight
setblock ~20 ~10 ~-35 ochre_froglight
setblock ~20 ~10 ~-30 ochre_froglight
setblock ~20 ~10 ~-25 ochre_froglight
setblock ~20 ~10 ~-20 ochre_froglight
setblock ~20 ~10 ~-15 ochre_froglight
setblock ~20 ~10 ~-10 ochre_froglight
setblock ~20 ~10 ~10 ochre_froglight
setblock ~20 ~10 ~15 ochre_froglight
setblock ~20 ~10 ~20 ochre_froglight
setblock ~20 ~10 ~25 ochre_froglight
setblock ~20 ~10 ~30 ochre_froglight
setblock ~20 ~10 ~35 ochre_froglight
setblock ~20 ~10 ~40 ochre_froglight
setblock ~25 ~10 ~-35 ochre_froglight
setblock ~25 ~10 ~-30 ochre_froglight
setblock ~25 ~10 ~-25 ochre_froglight
setblock ~25 ~10 ~-20 ochre_froglight
setblock ~25 ~10 ~-15 ochre_froglight
setblock ~25 ~10 ~-10 ochre_froglight
setblock ~25 ~10 ~-5 ochre_froglight
setblock ~25 ~10 ~0 ochre_froglight
setblock ~25 ~10 ~5 ochre_froglight
setblock ~25 ~10 ~10 ochre_froglight
setblock ~25 ~10 ~15 ochre_froglight
setblock ~25 ~10 ~20 ochre_froglight
setblock ~25 ~10 ~25 ochre_froglight
setblock ~25 ~10 ~30 ochre_froglight
setblock ~25 ~10 ~35 ochre_froglight
setblock ~30 ~10 ~-30 ochre_froglight
setblock ~30 ~10 ~-25 ochre_froglight
setblock ~30 ~10 ~-20 ochre_froglight
setblock ~30 ~10 ~-15 ochre_froglight
setblock ~30 ~10 ~-10 ochre_froglight
setblock ~30 ~10 ~-5 ochre_froglight
setblock ~30 ~10 ~0 ochre_froglight
setblock ~30 ~10 ~5 ochre_froglight
setblock ~30 ~10 ~10 ochre_froglight
setblock ~30 ~10 ~15 ochre_froglight
setblock ~30 ~10 ~20 ochre_froglight
setblock ~30 ~10 ~25 ochre_froglight
setblock ~30 ~10 ~30 ochre_froglight
setblock ~35 ~10 ~-25 ochre_froglight
setblock ~35 ~10 ~-20 ochre_froglight
setblock ~35 ~10 ~-15 ochre_froglight
setblock ~35 ~10 ~-10 ochre_froglight
setblock ~35 ~10 ~-5 ochre_froglight
setblock ~35 ~10 ~0 ochre_froglight
setblock ~35 ~10 ~5 ochre_froglight
setblock ~35 ~10 ~10 ochre_froglight
setblock ~35 ~10 ~15 ochre_froglight
setblock ~35 ~10 ~20 ochre_froglight
setblock ~35 ~10 ~25 ochre_froglight
setblock ~40 ~10 ~-20 ochre_froglight
setblock ~40 ~10 ~-15 ochre_froglight
setblock ~40 ~10 ~-10 ochre_froglight
setblock ~40 ~10 ~-5 ochre_froglight
setblock ~40 ~10 ~0 ochre_froglight
setblock ~40 ~10 ~5 ochre_froglight
setblock ~40 ~10 ~10 ochre_froglight
setblock ~40 ~10 ~15 ochre_froglight
setblock ~40 ~10 ~20 ochre_froglight
fill ~-9 ~11 ~-45 ~9 ~11 ~-45 blue_carpet
fill ~-13 ~11 ~-44 ~13 ~11 ~-44 blue_carpet
fill ~-16 ~11 ~-43 ~16 ~11 ~-43 blue_carpet
fill ~-18 ~11 ~-42 ~18 ~11 ~-42 blue_carpet
fill ~-20 ~11 ~-41 ~20 ~11 ~-41 blue_carpet
fill ~-22 ~11 ~-40 ~22 ~11 ~-40 blue_carpet
fill ~-24 ~11 ~-39 ~24 ~11 ~-39 blue_carpet
fill ~-25 ~11 ~-38 ~25 ~11 ~-38 blue_carpet
fill ~-27 ~11 ~-37 ~27 ~11 ~-37 blue_carpet
fill ~-28 ~11 ~-36 ~28 ~11 ~-36 blue_carpet
fill ~-29 ~11 ~-35 ~29 ~11 ~-35 blue_carpet
fill ~-30 ~11 ~-34 ~30 ~11 ~-34 blue_carpet
fill ~-32 ~11 ~-33 ~32 ~11 ~-33 blue_carpet
fill ~-33 ~11 ~-32 ~33 ~11 ~-32 blue_carpet
fill ~-33 ~11 ~-31 ~33 ~11 ~-31 blue_carpet
fill ~-34 ~11 ~-30 ~34 ~11 ~-30 blue_carpet
fill ~-35 ~11 ~-29 ~35 ~11 ~-29 blue_carpet
fill ~-36 ~11 ~-28 ~36 ~11 ~-28 blue_carpet
fill ~-37 ~11 ~-27 ~37 ~11 ~-27 blue_carpet
fill ~-37 ~11 ~-26 ~37 ~11 ~-26 blue_carpet
fill ~-38 ~11 ~-25 ~38 ~11 ~-25 blue_carpet
fill ~-39 ~11 ~-24 ~39 ~11 ~-24 blue_carpet
fill ~-39 ~11 ~-23 ~39 ~11 ~-23 blue_carpet
fill ~-40 ~11 ~-22 ~40 ~11 ~-22 blue_carpet
fill ~-40 ~11 ~-21 ~40 ~11 ~-21 blue_carpet
fill ~-41 ~11 ~-20 ~-7 ~11 ~-20 blue_carpet
fill ~7 ~11 ~-20 ~41 ~11 ~-20 blue_carpet
fill ~-41 ~11 ~-19 ~-9 ~11 ~-19 blue_carpet
fill ~9 ~11 ~-19 ~41 ~11 ~-19 blue_carpet
fill ~-42 ~11 ~-18 ~-11 ~11 ~-18 blue_carpet
fill ~11 ~11 ~-18 ~42 ~11 ~-18 blue_carpet
fill ~-42 ~11 ~-17 ~-13 ~11 ~-17 blue_carpet
fill ~13 ~11 ~-17 ~42 ~11 ~-17 blue_carpet
fill ~-43 ~11 ~-16 ~-14 ~11 ~-16 blue_carpet
fill ~14 ~11 ~-16 ~43 ~11 ~-16 blue_carpet
fill ~-43 ~11 ~-15 ~-15 ~11 ~-15 blue_carpet
fill ~15 ~11 ~-15 ~43 ~11 ~-15 blue_carpet
fill ~-43 ~11 ~-14 ~-16 ~11 ~-14 blue_carpet
fill ~16 ~11 ~-14 ~43 ~11 ~-14 blue_carpet
fill ~-44 ~11 ~-13 ~-17 ~11 ~-13 blue_carpet
fill ~17 ~11 ~-13 ~44 ~11 ~-13 blue_carpet
fill ~-44 ~11 ~-12 ~-18 ~11 ~-12 blue_carpet
fill ~18 ~11 ~-12 ~44 ~11 ~-12 blue_carpet
fill ~-44 ~11 ~-11 ~-18 ~11 ~-11 blue_carpet
fill ~18 ~11 ~-11 ~44 ~11 ~-11 blue_carpet
fill ~-44 ~11 ~-10 ~-19 ~11 ~-10 blue_carpet
fill ~19 ~11 ~-10 ~44 ~11 ~-10 blue_carpet
fill ~-45 ~11 ~-9 ~-19 ~11 ~-9 blue_carpet
fill ~19 ~11 ~-9 ~45 ~11 ~-9 blue_carpet
fill ~-45 ~11 ~-8 ~-20 ~11 ~-8 blue_carpet
fill ~20 ~11 ~-8 ~45 ~11 ~-8 blue_carpet
fill ~-45 ~11 ~-7 ~-20 ~11 ~-7 blue_carpet
fill ~20 ~11 ~-7 ~45 ~11 ~-7 blue_carpet
fill ~-45 ~11 ~-6 ~-21 ~11 ~-6 blue_carpet
fill ~21 ~11 ~-6 ~45 ~11 ~-6 blue_carpet
fill ~-45 ~11 ~-5 ~-21 ~11 ~-5 blue_carpet
fill ~21 ~11 ~-5 ~45 ~11 ~-5 blue_carpet
fill ~-45 ~11 ~-4 ~-21 ~11 ~-4 blue_carpet
fill ~21 ~11 ~-4 ~45 ~11 ~-4 blue_carpet
fill ~-45 ~11 ~-3 ~-21 ~11 ~-3 blue_carpet
fill ~21 ~11 ~-3 ~45 ~11 ~-3 blue_carpet
fill ~-45 ~11 ~-2 ~-21 ~11 ~-2 blue_carpet
fill ~21 ~11 ~-2 ~45 ~11 ~-2 blue_carpet
fill ~-45 ~11 ~-1 ~-21 ~11 ~-1 blue_carpet
fill ~21 ~11 ~-1 ~45 ~11 ~-1 blue_carpet
fill ~-45 ~11 ~0 ~-21 ~11 ~0 blue_carpet
fill ~21 ~11 ~0 ~45 ~11 ~0 blue_carpet
fill ~-45 ~11 ~1 ~-21 ~11 ~1 blue_carpet
fill ~21 ~11 ~1 ~45 ~11 ~1 blue_carpet
fill ~-45 ~11 ~2 ~-21 ~11 ~2 blue_carpet
fill ~21 ~11 ~2 ~45 ~11 ~2 blue_carpet
fill ~-45 ~11 ~3 ~-21 ~11 ~3 blue_carpet
fill ~21 ~11 ~3 ~45 ~11 ~3 blue_carpet
fill ~-45 ~11 ~4 ~-21 ~11 ~4 blue_carpet
fill ~21 ~11 ~4 ~45 ~11 ~4 blue_carpet
fill ~-45 ~11 ~5 ~-21 ~11 ~5 blue_carpet
fill ~21 ~11 ~5 ~45 ~11 ~5 blue_carpet
fill ~-45 ~11 ~6 ~-21 ~11 ~6 blue_carpet
fill ~21 ~11 ~6 ~45 ~11 ~6 blue_carpet
fill ~-45 ~11 ~7 ~-20 ~11 ~7 blue_carpet
fill ~20 ~11 ~7 ~45 ~11 ~7 blue_carpet
fill ~-45 ~11 ~8 ~-20 ~11 ~8 blue_carpet
fill ~20 ~11 ~8 ~45 ~11 ~8 blue_carpet
fill ~-45 ~11 ~9 ~-19 ~11 ~9 blue_carpet
fill ~19 ~11 ~9 ~45 ~11 ~9 blue_carpet
fill ~-44 ~11 ~10 ~-19 ~11 ~10 blue_carpet
fill ~19 ~11 ~10 ~44 ~11 ~10 blue_carpet
fill ~-44 ~11 ~11 ~-18 ~11 ~11 blue_carpet
fill ~18 ~11 ~11 ~44 ~11 ~11 blue_carpet
fill ~-44 ~11 ~12 ~-18 ~11 ~12 blue_carpet
fill ~18 ~11 ~12 ~44 ~11 ~12 blue_carpet
fill ~-44 ~11 ~13 ~-17 ~11 ~13 blue_carpet
fill ~17 ~11 ~13 ~44 ~11 ~13 blue_carpet
fill ~-43 ~11 ~14 ~-16 ~11 ~14 blue_carpet
fill ~16 ~11 ~14 ~43 ~11 ~14 blue_carpet
fill ~-43 ~11 ~15 ~-15 ~11 ~15 blue_carpet
fill ~15 ~11 ~15 ~43 ~11 ~15 blue_carpet
fill ~-43 ~11 ~16 ~-14 ~11 ~16 blue_carpet
fill ~14 ~11 ~16 ~43 ~11 ~16 blue_carpet
fill ~-42 ~11 ~17 ~-13 ~11 ~17 blue_carpet
fill ~13 ~11 ~17 ~42 ~11 ~17 blue_carpet
fill ~-42 ~11 ~18 ~-11 ~11 ~18 blue_carpet
fill ~11 ~11 ~18 ~42 ~11 ~18 blue_carpet
fill ~-41 ~11 ~19 ~-9 ~11 ~19 blue_carpet
fill ~9 ~11 ~19 ~41 ~11 ~19 blue_carpet
fill ~-41 ~11 ~20 ~-7 ~11 ~20 blue_carpet
fill ~7 ~11 ~20 ~41 ~11 ~20 blue_carpet
fill ~-40 ~11 ~21 ~40 ~11 ~21 blue_carpet
fill ~-40 ~11 ~22 ~40 ~11 ~22 blue_carpet
fill ~-39 ~11 ~23 ~39 ~11 ~23 blue_carpet
fill ~-39 ~11 ~24 ~39 ~11 ~24 blue_carpet
fill ~-38 ~11 ~25 ~38 ~11 ~25 blue_carpet
fill ~-37 ~11 ~26 ~37 ~11 ~26 blue_carpet
fill ~-37 ~11 ~27 ~37 ~11 ~27 blue_carpet
fill ~-36 ~11 ~28 ~36 ~11 ~28 blue_carpet
fill ~-35 ~11 ~29 ~35 ~11 ~29 blue_carpet
fill ~-34 ~11 ~30 ~34 ~11 ~30 blue_carpet
fill ~-33 ~11 ~31 ~33 ~11 ~31 blue_carpet
fill ~-33 ~11 ~32 ~33 ~11 ~32 blue_carpet
fill ~-32 ~11 ~33 ~32 ~11 ~33 blue_carpet
fill ~-30 ~11 ~34 ~30 ~11 ~34 blue_carpet
fill ~-29 ~11 ~35 ~29 ~11 ~35 blue_carpet
fill ~-28 ~11 ~36 ~28 ~11 ~36 blue_carpet
fill ~-27 ~11 ~37 ~27 ~11 ~37 blue_carpet
fill ~-25 ~11 ~38 ~25 ~11 ~38 blue_carpet
fill ~-24 ~11 ~39 ~24 ~11 ~39 blue_carpet
fill ~-22 ~11 ~40 ~22 ~11 ~40 blue_carpet
fill ~-20 ~11 ~41 ~20 ~11 ~41 blue_carpet
fill ~-18 ~11 ~42 ~18 ~11 ~42 blue_carpet
fill ~-16 ~11 ~43 ~16 ~11 ~43 blue_carpet
fill ~-13 ~11 ~44 ~13 ~11 ~44 blue_carpet
fill ~-9 ~11 ~45 ~9 ~11 ~45 blue_carpet
fill ~-6 ~11 ~-23 ~6 ~11 ~-23 cyan_carpet
fill ~-9 ~11 ~-22 ~-7 ~11 ~-22 cyan_carpet
fill ~7 ~11 ~-22 ~9 ~11 ~-22 cyan_carpet
fill ~-11 ~11 ~-21 ~-10 ~11 ~-21 cyan_carpet
fill ~10 ~11 ~-21 ~11 ~11 ~-21 cyan_carpet
fill ~-13 ~11 ~-20 ~-12 ~11 ~-20 cyan_carpet
fill ~12 ~11 ~-20 ~13 ~11 ~-20 cyan_carpet
fill ~-14 ~11 ~-19 ~-13 ~11 ~-19 cyan_carpet
fill ~13 ~11 ~-19 ~14 ~11 ~-19 cyan_carpet
fill ~-15 ~11 ~-18 ~-15 ~11 ~-18 cyan_carpet
fill ~15 ~11 ~-18 ~15 ~11 ~-18 cyan_carpet
fill ~-16 ~11 ~-17 ~-16 ~11 ~-17 cyan_carpet
fill ~16 ~11 ~-17 ~16 ~11 ~-17 cyan_carpet
fill ~-17 ~11 ~-16 ~-17 ~11 ~-16 cyan_carpet
fill ~17 ~11 ~-16 ~17 ~11 ~-16 cyan_carpet
fill ~-18 ~11 ~-15 ~-18 ~11 ~-15 cyan_carpet
fill ~18 ~11 ~-15 ~18 ~11 ~-15 cyan_carpet
fill ~-19 ~11 ~-14 ~-19 ~11 ~-14 cyan_carpet
fill ~19 ~11 ~-14 ~19 ~11 ~-14 cyan_carpet
fill ~-20 ~11 ~-13 ~-19 ~11 ~-13 cyan_carpet
fill ~19 ~11 ~-13 ~20 ~11 ~-13 cyan_carpet
fill ~-20 ~11 ~-12 ~-20 ~11 ~-12 cyan_carpet
fill ~20 ~11 ~-12 ~20 ~11 ~-12 cyan_carpet
fill ~-21 ~11 ~-11 ~-21 ~11 ~-11 cyan_carpet
fill ~21 ~11 ~-11 ~21 ~11 ~-11 cyan_carpet
fill ~-21 ~11 ~-10 ~-21 ~11 ~-10 cyan_carpet
fill ~21 ~11 ~-10 ~21 ~11 ~-10 cyan_carpet
fill ~-22 ~11 ~-9 ~-22 ~11 ~-9 cyan_carpet
fill ~22 ~11 ~-9 ~22 ~11 ~-9 cyan_carpet
fill ~-22 ~11 ~-8 ~-22 ~11 ~-8 cyan_carpet
fill ~22 ~11 ~-8 ~22 ~11 ~-8 cyan_carpet
fill ~-22 ~11 ~-7 ~-22 ~11 ~-7 cyan_carpet
fill ~22 ~11 ~-7 ~22 ~11 ~-7 cyan_carpet
fill ~-23 ~11 ~-6 ~-23 ~11 ~-6 cyan_carpet
fill ~23 ~11 ~-6 ~23 ~11 ~-6 cyan_carpet
fill ~-23 ~11 ~-5 ~-23 ~11 ~-5 cyan_carpet
fill ~23 ~11 ~-5 ~23 ~11 ~-5 cyan_carpet
fill ~-23 ~11 ~-4 ~-23 ~11 ~-4 cyan_carpet
fill ~23 ~11 ~-4 ~23 ~11 ~-4 cyan_carpet
fill ~-23 ~11 ~-3 ~-23 ~11 ~-3 cyan_carpet
fill ~23 ~11 ~-3 ~23 ~11 ~-3 cyan_carpet
fill ~-23 ~11 ~-2 ~-23 ~11 ~-2 cyan_carpet
fill ~23 ~11 ~-2 ~23 ~11 ~-2 cyan_carpet
fill ~-23 ~11 ~-1 ~-23 ~11 ~-1 cyan_carpet
fill ~23 ~11 ~-1 ~23 ~11 ~-1 cyan_carpet
fill ~-23 ~11 ~0 ~-23 ~11 ~0 cyan_carpet
fill ~23 ~11 ~0 ~23 ~11 ~0 cyan_carpet
fill ~-23 ~11 ~1 ~-23 ~11 ~1 cyan_carpet
fill ~23 ~11 ~1 ~23 ~11 ~1 cyan_carpet
fill ~-23 ~11 ~2 ~-23 ~11 ~2 cyan_carpet
fill ~23 ~11 ~2 ~23 ~11 ~2 cyan_carpet
fill ~-23 ~11 ~3 ~-23 ~11 ~3 cyan_carpet
fill ~23 ~11 ~3 ~23 ~11 ~3 cyan_carpet
fill ~-23 ~11 ~4 ~-23 ~11 ~4 cyan_carpet
fill ~23 ~11 ~4 ~23 ~11 ~4 cyan_carpet
fill ~-23 ~11 ~5 ~-23 ~11 ~5 cyan_carpet
fill ~23 ~11 ~5 ~23 ~11 ~5 cyan_carpet
fill ~-23 ~11 ~6 ~-23 ~11 ~6 cyan_carpet
fill ~23 ~11 ~6 ~23 ~11 ~6 cyan_carpet
fill ~-22 ~11 ~7 ~-22 ~11 ~7 cyan_carpet
fill ~22 ~11 ~7 ~22 ~11 ~7 cyan_carpet
fill ~-22 ~11 ~8 ~-22 ~11 ~8 cyan_carpet
fill ~22 ~11 ~8 ~22 ~11 ~8 cyan_carpet
fill ~-22 ~11 ~9 ~-22 ~11 ~9 cyan_carpet
fill ~22 ~11 ~9 ~22 ~11 ~9 cyan_carpet
fill ~-21 ~11 ~10 ~-21 ~11 ~10 cyan_carpet
fill ~21 ~11 ~10 ~21 ~11 ~10 cyan_carpet
fill ~-21 ~11 ~11 ~-21 ~11 ~11 cyan_carpet
fill ~21 ~11 ~11 ~21 ~11 ~11 cyan_carpet
fill ~-20 ~11 ~12 ~-20 ~11 ~12 cyan_carpet
fill ~20 ~11 ~12 ~20 ~11 ~12 cyan_carpet
fill ~-20 ~11 ~13 ~-19 ~11 ~13 cyan_carpet
fill ~19 ~11 ~13 ~20 ~11 ~13 cyan_carpet
fill ~-19 ~11 ~14 ~-19 ~11 ~14 cyan_carpet
fill ~19 ~11 ~14 ~19 ~11 ~14 cyan_carpet
fill ~-18 ~11 ~15 ~-18 ~11 ~15 cyan_carpet
fill ~18 ~11 ~15 ~18 ~11 ~15 cyan_carpet
fill ~-17 ~11 ~16 ~-17 ~11 ~16 cyan_carpet
fill ~17 ~11 ~16 ~17 ~11 ~16 cyan_carpet
fill ~-16 ~11 ~17 ~-16 ~11 ~17 cyan_carpet
fill ~16 ~11 ~17 ~16 ~11 ~17 cyan_carpet
fill ~-15 ~11 ~18 ~-15 ~11 ~18 cyan_carpet
fill ~15 ~11 ~18 ~15 ~11 ~18 cyan_carpet
fill ~-14 ~11 ~19 ~-13 ~11 ~19 cyan_carpet
fill ~13 ~11 ~19 ~14 ~11 ~19 cyan_carpet
fill ~-13 ~11 ~20 ~-12 ~11 ~20 cyan_carpet
fill ~12 ~11 ~20 ~13 ~11 ~20 cyan_carpet
fill ~-11 ~11 ~21 ~-10 ~11 ~21 cyan_carpet
fill ~10 ~11 ~21 ~11 ~11 ~21 cyan_carpet
fill ~-9 ~11 ~22 ~-7 ~11 ~22 cyan_carpet
fill ~7 ~11 ~22 ~9 ~11 ~22 cyan_carpet
fill ~-6 ~11 ~23 ~6 ~11 ~23 cyan_carpet
fill ~-2 ~9 ~-21 ~2 ~10 ~-21 smooth_quartz
fill ~-6 ~9 ~-20 ~6 ~10 ~-20 smooth_quartz
fill ~-9 ~9 ~-19 ~-6 ~10 ~-19 smooth_quartz
fill ~6 ~9 ~-19 ~9 ~10 ~-19 smooth_quartz
fill ~-11 ~9 ~-18 ~-9 ~10 ~-18 smooth_quartz
fill ~9 ~9 ~-18 ~11 ~10 ~-18 smooth_quartz
fill ~-12 ~9 ~-17 ~-11 ~10 ~-17 smooth_quartz
fill ~11 ~9 ~-17 ~12 ~10 ~-17 smooth_quartz
fill ~-13 ~9 ~-16 ~-12 ~10 ~-16 smooth_quartz
fill ~12 ~9 ~-16 ~13 ~10 ~-16 smooth_quartz
fill ~-14 ~9 ~-15 ~-13 ~10 ~-15 smooth_quartz
fill ~13 ~9 ~-15 ~14 ~10 ~-15 smooth_quartz
fill ~-15 ~9 ~-14 ~-15 ~10 ~-14 smooth_quartz
fill ~15 ~9 ~-14 ~15 ~10 ~-14 smooth_quartz
fill ~-16 ~9 ~-13 ~-15 ~10 ~-13 smooth_quartz
fill ~15 ~9 ~-13 ~16 ~10 ~-13 smooth_quartz
fill ~-17 ~9 ~-12 ~-16 ~10 ~-12 smooth_quartz
fill ~16 ~9 ~-12 ~17 ~10 ~-12 smooth_quartz
fill ~-18 ~9 ~-11 ~-17 ~10 ~-11 smooth_quartz
fill ~17 ~9 ~-11 ~18 ~10 ~-11 smooth_quartz
fill ~-18 ~9 ~-10 ~-18 ~10 ~-10 smooth_quartz
fill ~18 ~9 ~-10 ~18 ~10 ~-10 smooth_quartz
fill ~-19 ~9 ~-9 ~-18 ~10 ~-9 smooth_quartz
fill ~18 ~9 ~-9 ~19 ~10 ~-9 smooth_quartz
fill ~-19 ~9 ~-8 ~-19 ~10 ~-8 smooth_quartz
fill ~19 ~9 ~-8 ~19 ~10 ~-8 smooth_quartz
fill ~-19 ~9 ~-7 ~-19 ~10 ~-7 smooth_quartz
fill ~19 ~9 ~-7 ~19 ~10 ~-7 smooth_quartz
fill ~-20 ~9 ~-6 ~-19 ~10 ~-6 smooth_quartz
fill ~19 ~9 ~-6 ~20 ~10 ~-6 smooth_quartz
fill ~-20 ~9 ~-5 ~-20 ~10 ~-5 smooth_quartz
fill ~20 ~9 ~-5 ~20 ~10 ~-5 smooth_quartz
fill ~-20 ~9 ~-4 ~-20 ~10 ~-4 smooth_quartz
fill ~20 ~9 ~-4 ~20 ~10 ~-4 smooth_quartz
fill ~-20 ~9 ~-3 ~-20 ~10 ~-3 smooth_quartz
fill ~20 ~9 ~-3 ~20 ~10 ~-3 smooth_quartz
fill ~-21 ~9 ~-2 ~-20 ~10 ~-2 smooth_quartz
fill ~20 ~9 ~-2 ~21 ~10 ~-2 smooth_quartz
fill ~-21 ~9 ~-1 ~-20 ~10 ~-1 smooth_quartz
fill ~20 ~9 ~-1 ~21 ~10 ~-1 smooth_quartz
fill ~-21 ~9 ~0 ~-20 ~10 ~0 smooth_quartz
fill ~20 ~9 ~0 ~21 ~10 ~0 smooth_quartz
fill ~-21 ~9 ~1 ~-20 ~10 ~1 smooth_quartz
fill ~20 ~9 ~1 ~21 ~10 ~1 smooth_quartz
fill ~-21 ~9 ~2 ~-20 ~10 ~2 smooth_quartz
fill ~20 ~9 ~2 ~21 ~10 ~2 smooth_quartz
fill ~-20 ~9 ~3 ~-20 ~10 ~3 smooth_quartz
fill ~20 ~9 ~3 ~20 ~10 ~3 smooth_quartz
fill ~-20 ~9 ~4 ~-20 ~10 ~4 smooth_quartz
fill ~20 ~9 ~4 ~20 ~10 ~4 smooth_quartz
fill ~-20 ~9 ~5 ~-20 ~10 ~5 smooth_quartz
fill ~20 ~9 ~5 ~20 ~10 ~5 smooth_quartz
fill ~-20 ~9 ~6 ~-19 ~10 ~6 smooth_quartz
fill ~19 ~9 ~6 ~20 ~10 ~6 smooth_quartz
fill ~-19 ~9 ~7 ~-19 ~10 ~7 smooth_quartz
fill ~19 ~9 ~7 ~19 ~10 ~7 smooth_quartz
fill ~-19 ~9 ~8 ~-19 ~10 ~8 smooth_quartz
fill ~19 ~9 ~8 ~19 ~10 ~8 smooth_quartz
fill ~-19 ~9 ~9 ~-18 ~10 ~9 smooth_quartz
fill ~18 ~9 ~9 ~19 ~10 ~9 smooth_quartz
fill ~-18 ~9 ~10 ~-18 ~10 ~10 smooth_quartz
fill ~18 ~9 ~10 ~18 ~10 ~10 smooth_quartz
fill ~-18 ~9 ~11 ~-17 ~10 ~11 smooth_quartz
fill ~17 ~9 ~11 ~18 ~10 ~11 smooth_quartz
fill ~-17 ~9 ~12 ~-16 ~10 ~12 smooth_quartz
fill ~16 ~9 ~12 ~17 ~10 ~12 smooth_quartz
fill ~-16 ~9 ~13 ~-15 ~10 ~13 smooth_quartz
fill ~15 ~9 ~13 ~16 ~10 ~13 smooth_quartz
fill ~-15 ~9 ~14 ~-15 ~10 ~14 smooth_quartz
fill ~15 ~9 ~14 ~15 ~10 ~14 smooth_quartz
fill ~-14 ~9 ~15 ~-13 ~10 ~15 smooth_quartz
fill ~13 ~9 ~15 ~14 ~10 ~15 smooth_quartz
fill ~-13 ~9 ~16 ~-12 ~10 ~16 smooth_quartz
fill ~12 ~9 ~16 ~13 ~10 ~16 smooth_quartz
fill ~-12 ~9 ~17 ~-11 ~10 ~17 smooth_quartz
fill ~11 ~9 ~17 ~12 ~10 ~17 smooth_quartz
fill ~-11 ~9 ~18 ~-9 ~10 ~18 smooth_quartz
fill ~9 ~9 ~18 ~11 ~10 ~18 smooth_quartz
fill ~-9 ~9 ~19 ~-6 ~10 ~19 smooth_quartz
fill ~6 ~9 ~19 ~9 ~10 ~19 smooth_quartz
fill ~-6 ~9 ~20 ~6 ~10 ~20 smooth_quartz
fill ~-2 ~9 ~21 ~2 ~10 ~21 smooth_quartz
fill ~-2 ~9 ~-22 ~2 ~9 ~-22 ochre_froglight
fill ~-6 ~9 ~-21 ~-3 ~9 ~-21 ochre_froglight
fill ~3 ~9 ~-21 ~6 ~9 ~-21 ochre_froglight
fill ~-9 ~9 ~-20 ~-7 ~9 ~-20 ochre_froglight
fill ~7 ~9 ~-20 ~9 ~9 ~-20 ochre_froglight
fill ~-11 ~9 ~-19 ~-10 ~9 ~-19 ochre_froglight
fill ~10 ~9 ~-19 ~11 ~9 ~-19 ochre_froglight
fill ~-12 ~9 ~-18 ~-12 ~9 ~-18 ochre_froglight
fill ~12 ~9 ~-18 ~12 ~9 ~-18 ochre_froglight
fill ~-14 ~9 ~-17 ~-13 ~9 ~-17 ochre_froglight
fill ~13 ~9 ~-17 ~14 ~9 ~-17 ochre_froglight
fill ~-15 ~9 ~-16 ~-14 ~9 ~-16 ochre_froglight
fill ~14 ~9 ~-16 ~15 ~9 ~-16 ochre_froglight
fill ~-16 ~9 ~-15 ~-15 ~9 ~-15 ochre_froglight
fill ~15 ~9 ~-15 ~16 ~9 ~-15 ochre_froglight
fill ~-17 ~9 ~-14 ~-16 ~9 ~-14 ochre_froglight
fill ~16 ~9 ~-14 ~17 ~9 ~-14 ochre_froglight
fill ~-17 ~9 ~-13 ~-17 ~9 ~-13 ochre_froglight
fill ~17 ~9 ~-13 ~17 ~9 ~-13 ochre_froglight
fill ~-18 ~9 ~-12 ~-18 ~9 ~-12 ochre_froglight
fill ~18 ~9 ~-12 ~18 ~9 ~-12 ochre_froglight
fill ~-19 ~9 ~-11 ~-19 ~9 ~-11 ochre_froglight
fill ~19 ~9 ~-11 ~19 ~9 ~-11 ochre_froglight
fill ~-19 ~9 ~-10 ~-19 ~9 ~-10 ochre_froglight
fill ~19 ~9 ~-10 ~19 ~9 ~-10 ochre_froglight
fill ~-20 ~9 ~-9 ~-20 ~9 ~-9 ochre_froglight
fill ~20 ~9 ~-9 ~20 ~9 ~-9 ochre_froglight
fill ~-20 ~9 ~-8 ~-20 ~9 ~-8 ochre_froglight
fill ~20 ~9 ~-8 ~20 ~9 ~-8 ochre_froglight
fill ~-20 ~9 ~-7 ~-20 ~9 ~-7 ochre_froglight
fill ~20 ~9 ~-7 ~20 ~9 ~-7 ochre_froglight
fill ~-21 ~9 ~-6 ~-21 ~9 ~-6 ochre_froglight
fill ~21 ~9 ~-6 ~21 ~9 ~-6 ochre_froglight
fill ~-21 ~9 ~-5 ~-21 ~9 ~-5 ochre_froglight
fill ~21 ~9 ~-5 ~21 ~9 ~-5 ochre_froglight
fill ~-21 ~9 ~-4 ~-21 ~9 ~-4 ochre_froglight
fill ~21 ~9 ~-4 ~21 ~9 ~-4 ochre_froglight
fill ~-21 ~9 ~-3 ~-21 ~9 ~-3 ochre_froglight
fill ~21 ~9 ~-3 ~21 ~9 ~-3 ochre_froglight
fill ~-22 ~9 ~-2 ~-22 ~9 ~-2 ochre_froglight
fill ~22 ~9 ~-2 ~22 ~9 ~-2 ochre_froglight
fill ~-22 ~9 ~-1 ~-22 ~9 ~-1 ochre_froglight
fill ~22 ~9 ~-1 ~22 ~9 ~-1 ochre_froglight
fill ~-22 ~9 ~0 ~-22 ~9 ~0 ochre_froglight
fill ~22 ~9 ~0 ~22 ~9 ~0 ochre_froglight
fill ~-22 ~9 ~1 ~-22 ~9 ~1 ochre_froglight
fill ~22 ~9 ~1 ~22 ~9 ~1 ochre_froglight
fill ~-22 ~9 ~2 ~-22 ~9 ~2 ochre_froglight
fill ~22 ~9 ~2 ~22 ~9 ~2 ochre_froglight
fill ~-21 ~9 ~3 ~-21 ~9 ~3 ochre_froglight
fill ~21 ~9 ~3 ~21 ~9 ~3 ochre_froglight
fill ~-21 ~9 ~4 ~-21 ~9 ~4 ochre_froglight
fill ~21 ~9 ~4 ~21 ~9 ~4 ochre_froglight
fill ~-21 ~9 ~5 ~-21 ~9 ~5 ochre_froglight
fill ~21 ~9 ~5 ~21 ~9 ~5 ochre_froglight
fill ~-21 ~9 ~6 ~-21 ~9 ~6 ochre_froglight
fill ~21 ~9 ~6 ~21 ~9 ~6 ochre_froglight
fill ~-20 ~9 ~7 ~-20 ~9 ~7 ochre_froglight
fill ~20 ~9 ~7 ~20 ~9 ~7 ochre_froglight
fill ~-20 ~9 ~8 ~-20 ~9 ~8 ochre_froglight
fill ~20 ~9 ~8 ~20 ~9 ~8 ochre_froglight
fill ~-20 ~9 ~9 ~-20 ~9 ~9 ochre_froglight
fill ~20 ~9 ~9 ~20 ~9 ~9 ochre_froglight
fill ~-19 ~9 ~10 ~-19 ~9 ~10 ochre_froglight
fill ~19 ~9 ~10 ~19 ~9 ~10 ochre_froglight
fill ~-19 ~9 ~11 ~-19 ~9 ~11 ochre_froglight
fill ~19 ~9 ~11 ~19 ~9 ~11 ochre_froglight
fill ~-18 ~9 ~12 ~-18 ~9 ~12 ochre_froglight
fill ~18 ~9 ~12 ~18 ~9 ~12 ochre_froglight
fill ~-17 ~9 ~13 ~-17 ~9 ~13 ochre_froglight
fill ~17 ~9 ~13 ~17 ~9 ~13 ochre_froglight
fill ~-17 ~9 ~14 ~-16 ~9 ~14 ochre_froglight
fill ~16 ~9 ~14 ~17 ~9 ~14 ochre_froglight
fill ~-16 ~9 ~15 ~-15 ~9 ~15 ochre_froglight
fill ~15 ~9 ~15 ~16 ~9 ~15 ochre_froglight
fill ~-15 ~9 ~16 ~-14 ~9 ~16 ochre_froglight
fill ~14 ~9 ~16 ~15 ~9 ~16 ochre_froglight
fill ~-14 ~9 ~17 ~-13 ~9 ~17 ochre_froglight
fill ~13 ~9 ~17 ~14 ~9 ~17 ochre_froglight
fill ~-12 ~9 ~18 ~-12 ~9 ~18 ochre_froglight
fill ~12 ~9 ~18 ~12 ~9 ~18 ochre_froglight
fill ~-11 ~9 ~19 ~-10 ~9 ~19 ochre_froglight
fill ~10 ~9 ~19 ~11 ~9 ~19 ochre_froglight
fill ~-9 ~9 ~20 ~-7 ~9 ~20 ochre_froglight
fill ~7 ~9 ~20 ~9 ~9 ~20 ochre_froglight
fill ~-6 ~9 ~21 ~-3 ~9 ~21 ochre_froglight
fill ~3 ~9 ~21 ~6 ~9 ~21 ochre_froglight
fill ~-2 ~9 ~22 ~2 ~9 ~22 ochre_froglight
setblock ~-14 ~10 ~-15 smooth_quartz
setblock ~-14 ~11 ~-15 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-14 ~12 ~-15 spruce_slab
setblock ~-19 ~10 ~7 smooth_quartz
setblock ~-19 ~11 ~7 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-19 ~12 ~7 spruce_slab
setblock ~19 ~10 ~-9 smooth_quartz
setblock ~19 ~11 ~-9 glass_pane[north=false,south=true,west=true,east=false]
setblock ~19 ~12 ~-9 spruce_slab
setblock ~-7 ~10 ~-19 smooth_quartz
setblock ~-7 ~11 ~-19 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-7 ~12 ~-19 spruce_slab
setblock ~17 ~10 ~12 smooth_quartz
setblock ~17 ~11 ~12 glass_pane[north=true,south=false,west=true,east=false]
setblock ~17 ~12 ~12 spruce_slab
setblock ~19 ~10 ~9 smooth_quartz
setblock ~19 ~11 ~9 glass_pane[north=true,south=false,west=true,east=false]
setblock ~19 ~12 ~9 spruce_slab
setblock ~-18 ~10 ~-10 smooth_quartz
setblock ~-18 ~11 ~-10 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-18 ~12 ~-10 spruce_slab
setblock ~-17 ~10 ~-11 smooth_quartz
setblock ~-17 ~11 ~-11 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-17 ~12 ~-11 spruce_slab
setblock ~-16 ~10 ~-13 smooth_quartz
setblock ~-16 ~11 ~-13 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-16 ~12 ~-13 spruce_slab
setblock ~-6 ~10 ~19 smooth_quartz
setblock ~-6 ~11 ~19 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-6 ~12 ~19 spruce_slab
setblock ~-15 ~10 ~-14 smooth_quartz
setblock ~-15 ~11 ~-14 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-15 ~12 ~-14 spruce_slab
setblock ~-14 ~10 ~15 smooth_quartz
setblock ~-14 ~11 ~15 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-14 ~12 ~15 spruce_slab
setblock ~14 ~10 ~-15 smooth_quartz
setblock ~14 ~11 ~-15 glass_pane[north=false,south=true,west=true,east=false]
setblock ~14 ~12 ~-15 spruce_slab
setblock ~-8 ~10 ~19 smooth_quartz
setblock ~-8 ~11 ~19 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-8 ~12 ~19 spruce_slab
setblock ~15 ~10 ~14 smooth_quartz
setblock ~15 ~11 ~14 glass_pane[north=true,south=false,west=true,east=false]
setblock ~15 ~12 ~14 spruce_slab
setblock ~16 ~10 ~13 smooth_quartz
setblock ~16 ~11 ~13 glass_pane[north=true,south=false,west=true,east=false]
setblock ~16 ~12 ~13 spruce_slab
setblock ~18 ~10 ~10 smooth_quartz
setblock ~18 ~11 ~10 glass_pane[north=true,south=true,west=false,east=false]
setblock ~18 ~12 ~10 spruce_slab
setblock ~-19 ~10 ~-9 smooth_quartz
setblock ~-19 ~11 ~-9 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-19 ~12 ~-9 spruce_slab
setblock ~6 ~10 ~20 smooth_quartz
setblock ~6 ~11 ~20 glass_pane[north=true,south=false,west=true,east=false]
setblock ~6 ~12 ~20 spruce_slab
setblock ~7 ~10 ~19 smooth_quartz
setblock ~7 ~11 ~19 glass_pane[north=false,south=false,west=true,east=true]
setblock ~7 ~12 ~19 spruce_slab
setblock ~-13 ~10 ~16 smooth_quartz
setblock ~-13 ~11 ~16 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-13 ~12 ~16 spruce_slab
setblock ~0 ~10 ~-20 smooth_quartz
setblock ~0 ~11 ~-20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~0 ~12 ~-20 spruce_slab
setblock ~-19 ~10 ~9 smooth_quartz
setblock ~-19 ~11 ~9 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-19 ~12 ~9 spruce_slab
setblock ~19 ~10 ~-7 smooth_quartz
setblock ~19 ~11 ~-7 glass_pane[north=true,south=true,west=false,east=false]
setblock ~19 ~12 ~-7 spruce_slab
setblock ~14 ~10 ~15 smooth_quartz
setblock ~14 ~11 ~15 glass_pane[north=true,south=false,west=true,east=false]
setblock ~14 ~12 ~15 spruce_slab
setblock ~-5 ~10 ~20 smooth_quartz
setblock ~-5 ~11 ~20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-5 ~12 ~20 spruce_slab
setblock ~9 ~10 ~19 smooth_quartz
setblock ~9 ~11 ~19 glass_pane[north=true,south=false,west=true,east=false]
setblock ~9 ~12 ~19 spruce_slab
setblock ~-20 ~10 ~1 smooth_quartz
setblock ~-20 ~11 ~1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-20 ~12 ~1 spruce_slab
setblock ~-19 ~10 ~-7 smooth_quartz
setblock ~-19 ~11 ~-7 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-19 ~12 ~-7 spruce_slab
setblock ~5 ~10 ~-20 smooth_quartz
setblock ~5 ~11 ~-20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~5 ~12 ~-20 spruce_slab
setblock ~17 ~10 ~-11 smooth_quartz
setblock ~17 ~11 ~-11 glass_pane[north=true,south=false,west=false,east=true]
setblock ~17 ~12 ~-11 spruce_slab
setblock ~-12 ~10 ~17 smooth_quartz
setblock ~-12 ~11 ~17 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-12 ~12 ~17 spruce_slab
setblock ~1 ~10 ~-20 smooth_quartz
setblock ~1 ~11 ~-20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~1 ~12 ~-20 spruce_slab
setblock ~11 ~10 ~-18 smooth_quartz
setblock ~11 ~11 ~-18 glass_pane[north=false,south=true,west=true,east=false]
setblock ~11 ~12 ~-18 spruce_slab
setblock ~-20 ~10 ~-6 smooth_quartz
setblock ~-20 ~11 ~-6 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-20 ~12 ~-6 spruce_slab
setblock ~-20 ~10 ~3 smooth_quartz
setblock ~-20 ~11 ~3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-20 ~12 ~3 spruce_slab
setblock ~-13 ~10 ~-16 smooth_quartz
setblock ~-13 ~11 ~-16 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-13 ~12 ~-16 spruce_slab
setblock ~12 ~10 ~-17 smooth_quartz
setblock ~12 ~11 ~-17 glass_pane[north=false,south=true,west=true,east=false]
setblock ~12 ~12 ~-17 spruce_slab
setblock ~3 ~10 ~-20 smooth_quartz
setblock ~3 ~11 ~-20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~3 ~12 ~-20 spruce_slab
setblock ~-9 ~10 ~18 smooth_quartz
setblock ~-9 ~11 ~18 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-9 ~12 ~18 spruce_slab
setblock ~-16 ~10 ~12 smooth_quartz
setblock ~-16 ~11 ~12 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-16 ~12 ~12 spruce_slab
setblock ~-9 ~10 ~-19 smooth_quartz
setblock ~-9 ~11 ~-19 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-9 ~12 ~-19 spruce_slab
setblock ~19 ~10 ~6 smooth_quartz
setblock ~19 ~11 ~6 glass_pane[north=false,south=true,west=false,east=true]
setblock ~19 ~12 ~6 spruce_slab
setblock ~6 ~10 ~-19 smooth_quartz
setblock ~6 ~11 ~-19 glass_pane[north=true,south=false,west=false,east=true]
setblock ~6 ~12 ~-19 spruce_slab
setblock ~-20 ~10 ~-4 smooth_quartz
setblock ~-20 ~11 ~-4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-20 ~12 ~-4 spruce_slab
setblock ~-4 ~10 ~-20 smooth_quartz
setblock ~-4 ~11 ~-20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-4 ~12 ~-20 spruce_slab
setblock ~-20 ~10 ~5 smooth_quartz
setblock ~-20 ~11 ~5 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-20 ~12 ~5 spruce_slab
setblock ~18 ~10 ~-11 smooth_quartz
setblock ~18 ~11 ~-11 glass_pane[north=false,south=true,west=true,east=false]
setblock ~18 ~12 ~-11 spruce_slab
setblock ~-11 ~10 ~-17 smooth_quartz
setblock ~-11 ~11 ~-17 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-11 ~12 ~-17 spruce_slab
setblock ~-10 ~10 ~-18 smooth_quartz
setblock ~-10 ~11 ~-18 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-10 ~12 ~-18 spruce_slab
setblock ~2 ~10 ~20 smooth_quartz
setblock ~2 ~11 ~20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~2 ~12 ~20 spruce_slab
setblock ~20 ~10 ~1 smooth_quartz
setblock ~20 ~11 ~1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~20 ~12 ~1 spruce_slab
setblock ~8 ~10 ~-19 smooth_quartz
setblock ~8 ~11 ~-19 glass_pane[north=false,south=false,west=true,east=true]
setblock ~8 ~12 ~-19 spruce_slab
setblock ~-15 ~10 ~13 smooth_quartz
setblock ~-15 ~11 ~13 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-15 ~12 ~13 spruce_slab
setblock ~17 ~10 ~11 smooth_quartz
setblock ~17 ~11 ~11 glass_pane[north=false,south=true,west=false,east=true]
setblock ~17 ~12 ~11 spruce_slab
setblock ~-17 ~10 ~-12 smooth_quartz
setblock ~-17 ~11 ~-12 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-17 ~12 ~-12 spruce_slab
setblock ~15 ~10 ~-14 smooth_quartz
setblock ~15 ~11 ~-14 glass_pane[north=false,south=true,west=true,east=false]
setblock ~15 ~12 ~-14 spruce_slab
setblock ~4 ~10 ~20 smooth_quartz
setblock ~4 ~11 ~20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~4 ~12 ~20 spruce_slab
setblock ~-20 ~10 ~-1 smooth_quartz
setblock ~-20 ~11 ~-1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-20 ~12 ~-1 spruce_slab
setblock ~-14 ~10 ~14 smooth_quartz
setblock ~-14 ~11 ~14 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-14 ~12 ~14 spruce_slab
setblock ~-20 ~10 ~-2 smooth_quartz
setblock ~-20 ~11 ~-2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-20 ~12 ~-2 spruce_slab
setblock ~18 ~10 ~-9 smooth_quartz
setblock ~18 ~11 ~-9 glass_pane[north=true,south=false,west=false,east=true]
setblock ~18 ~12 ~-9 spruce_slab
setblock ~13 ~10 ~16 smooth_quartz
setblock ~13 ~11 ~16 glass_pane[north=true,south=false,west=true,east=false]
setblock ~13 ~12 ~16 spruce_slab
setblock ~15 ~10 ~13 smooth_quartz
setblock ~15 ~11 ~13 glass_pane[north=false,south=true,west=false,east=true]
setblock ~15 ~12 ~13 spruce_slab
setblock ~16 ~10 ~12 smooth_quartz
setblock ~16 ~11 ~12 glass_pane[north=false,south=true,west=false,east=true]
setblock ~16 ~12 ~12 spruce_slab
setblock ~18 ~10 ~9 smooth_quartz
setblock ~18 ~11 ~9 glass_pane[north=false,south=true,west=false,east=true]
setblock ~18 ~12 ~9 spruce_slab
setblock ~-18 ~10 ~10 smooth_quartz
setblock ~-18 ~11 ~10 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-18 ~12 ~10 spruce_slab
setblock ~20 ~10 ~-6 smooth_quartz
setblock ~20 ~11 ~-6 glass_pane[north=false,south=true,west=true,east=false]
setblock ~20 ~12 ~-6 spruce_slab
setblock ~-7 ~10 ~19 smooth_quartz
setblock ~-7 ~11 ~19 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-7 ~12 ~19 spruce_slab
setblock ~20 ~10 ~3 smooth_quartz
setblock ~20 ~11 ~3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~20 ~12 ~3 spruce_slab
setblock ~-3 ~10 ~-20 smooth_quartz
setblock ~-3 ~11 ~-20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-3 ~12 ~-20 spruce_slab
setblock ~9 ~10 ~-18 smooth_quartz
setblock ~9 ~11 ~-18 glass_pane[north=true,south=false,west=false,east=true]
setblock ~9 ~12 ~-18 spruce_slab
setblock ~19 ~10 ~-8 smooth_quartz
setblock ~19 ~11 ~-8 glass_pane[north=true,south=true,west=false,east=false]
setblock ~19 ~12 ~-8 spruce_slab
setblock ~12 ~10 ~17 smooth_quartz
setblock ~12 ~11 ~17 glass_pane[north=true,south=false,west=true,east=false]
setblock ~12 ~12 ~17 spruce_slab
setblock ~14 ~10 ~14 smooth_quartz
setblock ~14 ~11 ~14 glass_pane[north=false,south=true,west=false,east=true]
setblock ~14 ~12 ~14 spruce_slab
setblock ~-20 ~10 ~0 smooth_quartz
setblock ~-20 ~11 ~0 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-20 ~12 ~0 spruce_slab
setblock ~16 ~10 ~-13 smooth_quartz
setblock ~16 ~11 ~-13 glass_pane[north=false,south=true,west=true,east=false]
setblock ~16 ~12 ~-13 spruce_slab
setblock ~11 ~10 ~18 smooth_quartz
setblock ~11 ~11 ~18 glass_pane[north=true,south=false,west=true,east=false]
setblock ~11 ~12 ~18 spruce_slab
setblock ~18 ~10 ~11 smooth_quartz
setblock ~18 ~11 ~11 glass_pane[north=true,south=false,west=true,east=false]
setblock ~18 ~12 ~11 spruce_slab
setblock ~-17 ~10 ~11 smooth_quartz
setblock ~-17 ~11 ~11 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-17 ~12 ~11 spruce_slab
setblock ~20 ~10 ~-4 smooth_quartz
setblock ~20 ~11 ~-4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~20 ~12 ~-4 spruce_slab
setblock ~20 ~10 ~5 smooth_quartz
setblock ~20 ~11 ~5 glass_pane[north=true,south=true,west=false,east=false]
setblock ~20 ~12 ~5 spruce_slab
setblock ~17 ~10 ~-12 smooth_quartz
setblock ~17 ~11 ~-12 glass_pane[north=false,south=true,west=true,east=false]
setblock ~17 ~12 ~-12 spruce_slab
setblock ~-1 ~10 ~20 smooth_quartz
setblock ~-1 ~11 ~20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-1 ~12 ~20 spruce_slab
setblock ~-2 ~10 ~20 smooth_quartz
setblock ~-2 ~11 ~20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-2 ~12 ~20 spruce_slab
setblock ~-11 ~10 ~17 smooth_quartz
setblock ~-11 ~11 ~17 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-11 ~12 ~17 spruce_slab
setblock ~13 ~10 ~-16 smooth_quartz
setblock ~13 ~11 ~-16 glass_pane[north=false,south=true,west=true,east=false]
setblock ~13 ~12 ~-16 spruce_slab
setblock ~-20 ~10 ~2 smooth_quartz
setblock ~-20 ~11 ~2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-20 ~12 ~2 spruce_slab
setblock ~0 ~10 ~20 smooth_quartz
setblock ~0 ~11 ~20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~0 ~12 ~20 spruce_slab
setblock ~20 ~10 ~-2 smooth_quartz
setblock ~20 ~11 ~-2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~20 ~12 ~-2 spruce_slab
setblock ~20 ~10 ~-1 smooth_quartz
setblock ~20 ~11 ~-1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~20 ~12 ~-1 spruce_slab
setblock ~11 ~10 ~-17 smooth_quartz
setblock ~11 ~11 ~-17 glass_pane[north=true,south=false,west=false,east=true]
setblock ~11 ~12 ~-17 spruce_slab
setblock ~-19 ~10 ~6 smooth_quartz
setblock ~-19 ~11 ~6 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-19 ~12 ~6 spruce_slab
setblock ~-10 ~10 ~18 smooth_quartz
setblock ~-10 ~11 ~18 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-10 ~12 ~18 spruce_slab
setblock ~6 ~10 ~-20 smooth_quartz
setblock ~6 ~11 ~-20 glass_pane[north=false,south=true,west=true,east=false]
setblock ~6 ~12 ~-20 spruce_slab
setblock ~-20 ~10 ~-5 smooth_quartz
setblock ~-20 ~11 ~-5 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-20 ~12 ~-5 spruce_slab
setblock ~19 ~10 ~8 smooth_quartz
setblock ~19 ~11 ~8 glass_pane[north=true,south=true,west=false,east=false]
setblock ~19 ~12 ~8 spruce_slab
setblock ~-20 ~10 ~4 smooth_quartz
setblock ~-20 ~11 ~4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-20 ~12 ~4 spruce_slab
setblock ~-18 ~10 ~-11 smooth_quartz
setblock ~-18 ~11 ~-11 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-18 ~12 ~-11 spruce_slab
setblock ~-13 ~10 ~-15 smooth_quartz
setblock ~-13 ~11 ~-15 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-13 ~12 ~-15 spruce_slab
setblock ~-12 ~10 ~-16 smooth_quartz
setblock ~-12 ~11 ~-16 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-12 ~12 ~-16 spruce_slab
setblock ~1 ~10 ~20 smooth_quartz
setblock ~1 ~11 ~20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~1 ~12 ~20 spruce_slab
setblock ~-9 ~10 ~19 smooth_quartz
setblock ~-9 ~11 ~19 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-9 ~12 ~19 spruce_slab
setblock ~20 ~10 ~0 smooth_quartz
setblock ~20 ~11 ~0 glass_pane[north=true,south=true,west=false,east=false]
setblock ~20 ~12 ~0 spruce_slab
setblock ~-6 ~10 ~-19 smooth_quartz
setblock ~-6 ~11 ~-19 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-6 ~12 ~-19 spruce_slab
setblock ~-5 ~10 ~-20 smooth_quartz
setblock ~-5 ~11 ~-20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-5 ~12 ~-20 spruce_slab
setblock ~-14 ~10 ~-14 smooth_quartz
setblock ~-14 ~11 ~-14 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-14 ~12 ~-14 spruce_slab
setblock ~6 ~10 ~19 smooth_quartz
setblock ~6 ~11 ~19 glass_pane[north=false,south=true,west=false,east=true]
setblock ~6 ~12 ~19 spruce_slab
setblock ~-13 ~10 ~15 smooth_quartz
setblock ~-13 ~11 ~15 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-13 ~12 ~15 spruce_slab
setblock ~-8 ~10 ~-19 smooth_quartz
setblock ~-8 ~11 ~-19 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-8 ~12 ~-19 spruce_slab
setblock ~-19 ~10 ~8 smooth_quartz
setblock ~-19 ~11 ~8 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-19 ~12 ~8 spruce_slab
setblock ~-20 ~10 ~-3 smooth_quartz
setblock ~-20 ~11 ~-3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-20 ~12 ~-3 spruce_slab
setblock ~7 ~10 ~-19 smooth_quartz
setblock ~7 ~11 ~-19 glass_pane[north=false,south=false,west=true,east=true]
setblock ~7 ~12 ~-19 spruce_slab
setblock ~-18 ~10 ~-9 smooth_quartz
setblock ~-18 ~11 ~-9 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-18 ~12 ~-9 spruce_slab
setblock ~-16 ~10 ~-12 smooth_quartz
setblock ~-16 ~11 ~-12 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-16 ~12 ~-12 spruce_slab
setblock ~18 ~10 ~-10 smooth_quartz
setblock ~18 ~11 ~-10 glass_pane[north=true,south=true,west=false,east=false]
setblock ~18 ~12 ~-10 spruce_slab
setblock ~-15 ~10 ~-13 smooth_quartz
setblock ~-15 ~11 ~-13 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-15 ~12 ~-13 spruce_slab
setblock ~5 ~10 ~20 smooth_quartz
setblock ~5 ~11 ~20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~5 ~12 ~20 spruce_slab
setblock ~8 ~10 ~19 smooth_quartz
setblock ~8 ~11 ~19 glass_pane[north=false,south=false,west=true,east=true]
setblock ~8 ~12 ~19 spruce_slab
setblock ~-6 ~10 ~20 smooth_quartz
setblock ~-6 ~11 ~20 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-6 ~12 ~20 spruce_slab
setblock ~9 ~10 ~18 smooth_quartz
setblock ~9 ~11 ~18 glass_pane[north=false,south=true,west=false,east=true]
setblock ~9 ~12 ~18 spruce_slab
setblock ~-18 ~10 ~9 smooth_quartz
setblock ~-18 ~11 ~9 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-18 ~12 ~9 spruce_slab
setblock ~14 ~10 ~-14 smooth_quartz
setblock ~14 ~11 ~-14 glass_pane[north=true,south=false,west=false,east=true]
setblock ~14 ~12 ~-14 spruce_slab
setblock ~20 ~10 ~2 smooth_quartz
setblock ~20 ~11 ~2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~20 ~12 ~2 spruce_slab
setblock ~-15 ~10 ~14 smooth_quartz
setblock ~-15 ~11 ~14 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-15 ~12 ~14 spruce_slab
setblock ~9 ~10 ~-19 smooth_quartz
setblock ~9 ~11 ~-19 glass_pane[north=false,south=true,west=true,east=false]
setblock ~9 ~12 ~-19 spruce_slab
setblock ~-19 ~10 ~-8 smooth_quartz
setblock ~-19 ~11 ~-8 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-19 ~12 ~-8 spruce_slab
setblock ~-4 ~10 ~20 smooth_quartz
setblock ~-4 ~11 ~20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-4 ~12 ~20 spruce_slab
setblock ~12 ~10 ~16 smooth_quartz
setblock ~12 ~11 ~16 glass_pane[north=false,south=true,west=false,east=true]
setblock ~12 ~12 ~16 spruce_slab
setblock ~-12 ~10 ~16 smooth_quartz
setblock ~-12 ~11 ~16 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-12 ~12 ~16 spruce_slab
setblock ~10 ~10 ~-18 smooth_quartz
setblock ~10 ~11 ~-18 glass_pane[north=false,south=false,west=true,east=true]
setblock ~10 ~12 ~-18 spruce_slab
setblock ~19 ~10 ~-6 smooth_quartz
setblock ~19 ~11 ~-6 glass_pane[north=true,south=false,west=false,east=true]
setblock ~19 ~12 ~-6 spruce_slab
setblock ~15 ~10 ~-13 smooth_quartz
setblock ~15 ~11 ~-13 glass_pane[north=true,south=false,west=false,east=true]
setblock ~15 ~12 ~-13 spruce_slab
setblock ~-2 ~10 ~-20 smooth_quartz
setblock ~-2 ~11 ~-20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-2 ~12 ~-20 spruce_slab
setblock ~-1 ~10 ~-20 smooth_quartz
setblock ~-1 ~11 ~-20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-1 ~12 ~-20 spruce_slab
setblock ~10 ~10 ~18 smooth_quartz
setblock ~10 ~11 ~18 glass_pane[north=false,south=false,west=true,east=true]
setblock ~10 ~12 ~18 spruce_slab
setblock ~11 ~10 ~17 smooth_quartz
setblock ~11 ~11 ~17 glass_pane[north=false,south=true,west=false,east=true]
setblock ~11 ~12 ~17 spruce_slab
setblock ~-18 ~10 ~11 smooth_quartz
setblock ~-18 ~11 ~11 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-18 ~12 ~11 spruce_slab
setblock ~20 ~10 ~-5 smooth_quartz
setblock ~20 ~11 ~-5 glass_pane[north=true,south=true,west=false,east=false]
setblock ~20 ~12 ~-5 spruce_slab
setblock ~20 ~10 ~4 smooth_quartz
setblock ~20 ~11 ~4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~20 ~12 ~4 spruce_slab
setblock ~-19 ~10 ~-6 smooth_quartz
setblock ~-19 ~11 ~-6 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-19 ~12 ~-6 spruce_slab
setblock ~2 ~10 ~-20 smooth_quartz
setblock ~2 ~11 ~-20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~2 ~12 ~-20 spruce_slab
setblock ~16 ~10 ~-12 smooth_quartz
setblock ~16 ~11 ~-12 glass_pane[north=true,south=false,west=false,east=true]
setblock ~16 ~12 ~-12 spruce_slab
setblock ~-3 ~10 ~20 smooth_quartz
setblock ~-3 ~11 ~20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-3 ~12 ~20 spruce_slab
setblock ~-11 ~10 ~-18 smooth_quartz
setblock ~-11 ~11 ~-18 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-11 ~12 ~-18 spruce_slab
setblock ~12 ~10 ~-16 smooth_quartz
setblock ~12 ~11 ~-16 glass_pane[north=true,south=false,west=false,east=true]
setblock ~12 ~12 ~-16 spruce_slab
setblock ~20 ~10 ~-3 smooth_quartz
setblock ~20 ~11 ~-3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~20 ~12 ~-3 spruce_slab
setblock ~-17 ~10 ~12 smooth_quartz
setblock ~-17 ~11 ~12 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-17 ~12 ~12 spruce_slab
setblock ~4 ~10 ~-20 smooth_quartz
setblock ~4 ~11 ~-20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~4 ~12 ~-20 spruce_slab
setblock ~20 ~10 ~6 smooth_quartz
setblock ~20 ~11 ~6 glass_pane[north=true,south=false,west=true,east=false]
setblock ~20 ~12 ~6 spruce_slab
setblock ~-16 ~10 ~13 smooth_quartz
setblock ~-16 ~11 ~13 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-16 ~12 ~13 spruce_slab
setblock ~-11 ~10 ~18 smooth_quartz
setblock ~-11 ~11 ~18 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-11 ~12 ~18 spruce_slab
setblock ~13 ~10 ~-15 smooth_quartz
setblock ~13 ~11 ~-15 glass_pane[north=true,south=false,west=false,east=true]
setblock ~13 ~12 ~-15 spruce_slab
setblock ~-9 ~10 ~-18 smooth_quartz
setblock ~-9 ~11 ~-18 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-9 ~12 ~-18 spruce_slab
setblock ~19 ~10 ~7 smooth_quartz
setblock ~19 ~11 ~7 glass_pane[north=true,south=true,west=false,east=false]
setblock ~19 ~12 ~7 spruce_slab
setblock ~3 ~10 ~20 smooth_quartz
setblock ~3 ~11 ~20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~3 ~12 ~20 spruce_slab
setblock ~-12 ~10 ~-17 smooth_quartz
setblock ~-12 ~11 ~-17 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-12 ~12 ~-17 spruce_slab
setblock ~-20 ~10 ~6 smooth_quartz
setblock ~-20 ~11 ~6 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-20 ~12 ~6 spruce_slab
setblock ~-6 ~10 ~-20 smooth_quartz
setblock ~-6 ~11 ~-20 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-6 ~12 ~-20 spruce_slab
setblock ~13 ~10 ~15 smooth_quartz
setblock ~13 ~11 ~15 glass_pane[north=false,south=true,west=false,east=true]
setblock ~13 ~12 ~15 spruce_slab
fill ~-9 ~18 ~-47 ~9 ~18 ~-47 spruce_planks
fill ~-13 ~18 ~-46 ~13 ~18 ~-46 spruce_planks
fill ~-16 ~18 ~-45 ~16 ~18 ~-45 spruce_planks
fill ~-19 ~18 ~-44 ~19 ~18 ~-44 spruce_planks
fill ~-21 ~18 ~-43 ~21 ~18 ~-43 spruce_planks
fill ~-23 ~18 ~-42 ~23 ~18 ~-42 spruce_planks
fill ~-24 ~18 ~-41 ~24 ~18 ~-41 spruce_planks
fill ~-26 ~18 ~-40 ~26 ~18 ~-40 spruce_planks
fill ~-27 ~18 ~-39 ~27 ~18 ~-39 spruce_planks
fill ~-29 ~18 ~-38 ~29 ~18 ~-38 spruce_planks
fill ~-30 ~18 ~-37 ~30 ~18 ~-37 spruce_planks
fill ~-31 ~18 ~-36 ~31 ~18 ~-36 spruce_planks
fill ~-32 ~18 ~-35 ~32 ~18 ~-35 spruce_planks
fill ~-33 ~18 ~-34 ~33 ~18 ~-34 spruce_planks
fill ~-34 ~18 ~-33 ~34 ~18 ~-33 spruce_planks
fill ~-35 ~18 ~-32 ~35 ~18 ~-32 spruce_planks
fill ~-36 ~18 ~-31 ~36 ~18 ~-31 spruce_planks
fill ~-37 ~18 ~-30 ~37 ~18 ~-30 spruce_planks
fill ~-38 ~18 ~-29 ~38 ~18 ~-29 spruce_planks
fill ~-38 ~18 ~-28 ~38 ~18 ~-28 spruce_planks
fill ~-39 ~18 ~-27 ~39 ~18 ~-27 spruce_planks
fill ~-40 ~18 ~-26 ~40 ~18 ~-26 spruce_planks
fill ~-40 ~18 ~-25 ~40 ~18 ~-25 spruce_planks
fill ~-41 ~18 ~-24 ~41 ~18 ~-24 spruce_planks
fill ~-42 ~18 ~-23 ~42 ~18 ~-23 spruce_planks
fill ~-42 ~18 ~-22 ~42 ~18 ~-22 spruce_planks
fill ~-43 ~18 ~-21 ~-7 ~18 ~-21 spruce_planks
fill ~7 ~18 ~-21 ~43 ~18 ~-21 spruce_planks
fill ~-43 ~18 ~-20 ~-10 ~18 ~-20 spruce_planks
fill ~10 ~18 ~-20 ~43 ~18 ~-20 spruce_planks
fill ~-44 ~18 ~-19 ~-12 ~18 ~-19 spruce_planks
fill ~12 ~18 ~-19 ~44 ~18 ~-19 spruce_planks
fill ~-44 ~18 ~-18 ~-13 ~18 ~-18 spruce_planks
fill ~13 ~18 ~-18 ~44 ~18 ~-18 spruce_planks
fill ~-44 ~18 ~-17 ~-14 ~18 ~-17 spruce_planks
fill ~14 ~18 ~-17 ~44 ~18 ~-17 spruce_planks
fill ~-45 ~18 ~-16 ~-16 ~18 ~-16 spruce_planks
fill ~16 ~18 ~-16 ~45 ~18 ~-16 spruce_planks
fill ~-45 ~18 ~-15 ~-17 ~18 ~-15 spruce_planks
fill ~17 ~18 ~-15 ~45 ~18 ~-15 spruce_planks
fill ~-45 ~18 ~-14 ~-17 ~18 ~-14 spruce_planks
fill ~17 ~18 ~-14 ~45 ~18 ~-14 spruce_planks
fill ~-46 ~18 ~-13 ~-18 ~18 ~-13 spruce_planks
fill ~18 ~18 ~-13 ~46 ~18 ~-13 spruce_planks
fill ~-46 ~18 ~-12 ~-19 ~18 ~-12 spruce_planks
fill ~19 ~18 ~-12 ~46 ~18 ~-12 spruce_planks
fill ~-46 ~18 ~-11 ~-20 ~18 ~-11 spruce_planks
fill ~20 ~18 ~-11 ~46 ~18 ~-11 spruce_planks
fill ~-46 ~18 ~-10 ~-20 ~18 ~-10 spruce_planks
fill ~20 ~18 ~-10 ~46 ~18 ~-10 spruce_planks
fill ~-47 ~18 ~-9 ~-21 ~18 ~-9 spruce_planks
fill ~21 ~18 ~-9 ~47 ~18 ~-9 spruce_planks
fill ~-47 ~18 ~-8 ~-21 ~18 ~-8 spruce_planks
fill ~21 ~18 ~-8 ~47 ~18 ~-8 spruce_planks
fill ~-47 ~18 ~-7 ~-21 ~18 ~-7 spruce_planks
fill ~21 ~18 ~-7 ~47 ~18 ~-7 spruce_planks
fill ~-47 ~18 ~-6 ~-22 ~18 ~-6 spruce_planks
fill ~22 ~18 ~-6 ~47 ~18 ~-6 spruce_planks
fill ~-47 ~18 ~-5 ~-22 ~18 ~-5 spruce_planks
fill ~22 ~18 ~-5 ~47 ~18 ~-5 spruce_planks
fill ~-47 ~18 ~-4 ~-22 ~18 ~-4 spruce_planks
fill ~22 ~18 ~-4 ~47 ~18 ~-4 spruce_planks
fill ~-47 ~18 ~-3 ~-22 ~18 ~-3 spruce_planks
fill ~22 ~18 ~-3 ~47 ~18 ~-3 spruce_planks
fill ~-47 ~18 ~-2 ~-22 ~18 ~-2 spruce_planks
fill ~22 ~18 ~-2 ~47 ~18 ~-2 spruce_planks
fill ~-47 ~18 ~-1 ~-22 ~18 ~-1 spruce_planks
fill ~22 ~18 ~-1 ~47 ~18 ~-1 spruce_planks
fill ~-47 ~18 ~0 ~-22 ~18 ~0 spruce_planks
fill ~22 ~18 ~0 ~47 ~18 ~0 spruce_planks
fill ~-47 ~18 ~1 ~-22 ~18 ~1 spruce_planks
fill ~22 ~18 ~1 ~47 ~18 ~1 spruce_planks
fill ~-47 ~18 ~2 ~-22 ~18 ~2 spruce_planks
fill ~22 ~18 ~2 ~47 ~18 ~2 spruce_planks
fill ~-47 ~18 ~3 ~-22 ~18 ~3 spruce_planks
fill ~22 ~18 ~3 ~47 ~18 ~3 spruce_planks
fill ~-47 ~18 ~4 ~-22 ~18 ~4 spruce_planks
fill ~22 ~18 ~4 ~47 ~18 ~4 spruce_planks
fill ~-47 ~18 ~5 ~-22 ~18 ~5 spruce_planks
fill ~22 ~18 ~5 ~47 ~18 ~5 spruce_planks
fill ~-47 ~18 ~6 ~-22 ~18 ~6 spruce_planks
fill ~22 ~18 ~6 ~47 ~18 ~6 spruce_planks
fill ~-47 ~18 ~7 ~-21 ~18 ~7 spruce_planks
fill ~21 ~18 ~7 ~47 ~18 ~7 spruce_planks
fill ~-47 ~18 ~8 ~-21 ~18 ~8 spruce_planks
fill ~21 ~18 ~8 ~47 ~18 ~8 spruce_planks
fill ~-47 ~18 ~9 ~-21 ~18 ~9 spruce_planks
fill ~21 ~18 ~9 ~47 ~18 ~9 spruce_planks
fill ~-46 ~18 ~10 ~-20 ~18 ~10 spruce_planks
fill ~20 ~18 ~10 ~46 ~18 ~10 spruce_planks
fill ~-46 ~18 ~11 ~-20 ~18 ~11 spruce_planks
fill ~20 ~18 ~11 ~46 ~18 ~11 spruce_planks
fill ~-46 ~18 ~12 ~-19 ~18 ~12 spruce_planks
fill ~19 ~18 ~12 ~46 ~18 ~12 spruce_planks
fill ~-46 ~18 ~13 ~-18 ~18 ~13 spruce_planks
fill ~18 ~18 ~13 ~46 ~18 ~13 spruce_planks
fill ~-45 ~18 ~14 ~-17 ~18 ~14 spruce_planks
fill ~17 ~18 ~14 ~45 ~18 ~14 spruce_planks
fill ~-45 ~18 ~15 ~-17 ~18 ~15 spruce_planks
fill ~17 ~18 ~15 ~45 ~18 ~15 spruce_planks
fill ~-45 ~18 ~16 ~-16 ~18 ~16 spruce_planks
fill ~16 ~18 ~16 ~45 ~18 ~16 spruce_planks
fill ~-44 ~18 ~17 ~-14 ~18 ~17 spruce_planks
fill ~14 ~18 ~17 ~44 ~18 ~17 spruce_planks
fill ~-44 ~18 ~18 ~-13 ~18 ~18 spruce_planks
fill ~13 ~18 ~18 ~44 ~18 ~18 spruce_planks
fill ~-44 ~18 ~19 ~-12 ~18 ~19 spruce_planks
fill ~12 ~18 ~19 ~44 ~18 ~19 spruce_planks
fill ~-43 ~18 ~20 ~-10 ~18 ~20 spruce_planks
fill ~10 ~18 ~20 ~43 ~18 ~20 spruce_planks
fill ~-43 ~18 ~21 ~-7 ~18 ~21 spruce_planks
fill ~7 ~18 ~21 ~43 ~18 ~21 spruce_planks
fill ~-42 ~18 ~22 ~42 ~18 ~22 spruce_planks
fill ~-42 ~18 ~23 ~42 ~18 ~23 spruce_planks
fill ~-41 ~18 ~24 ~41 ~18 ~24 spruce_planks
fill ~-40 ~18 ~25 ~40 ~18 ~25 spruce_planks
fill ~-40 ~18 ~26 ~40 ~18 ~26 spruce_planks
fill ~-39 ~18 ~27 ~39 ~18 ~27 spruce_planks
fill ~-38 ~18 ~28 ~38 ~18 ~28 spruce_planks
fill ~-38 ~18 ~29 ~38 ~18 ~29 spruce_planks
fill ~-37 ~18 ~30 ~37 ~18 ~30 spruce_planks
fill ~-36 ~18 ~31 ~36 ~18 ~31 spruce_planks
fill ~-35 ~18 ~32 ~35 ~18 ~32 spruce_planks
fill ~-34 ~18 ~33 ~34 ~18 ~33 spruce_planks
fill ~-33 ~18 ~34 ~33 ~18 ~34 spruce_planks
fill ~-32 ~18 ~35 ~32 ~18 ~35 spruce_planks
fill ~-31 ~18 ~36 ~31 ~18 ~36 spruce_planks
fill ~-30 ~18 ~37 ~30 ~18 ~37 spruce_planks
fill ~-29 ~18 ~38 ~29 ~18 ~38 spruce_planks
fill ~-27 ~18 ~39 ~27 ~18 ~39 spruce_planks
fill ~-26 ~18 ~40 ~26 ~18 ~40 spruce_planks
fill ~-24 ~18 ~41 ~24 ~18 ~41 spruce_planks
fill ~-23 ~18 ~42 ~23 ~18 ~42 spruce_planks
fill ~-21 ~18 ~43 ~21 ~18 ~43 spruce_planks
fill ~-19 ~18 ~44 ~19 ~18 ~44 spruce_planks
fill ~-16 ~18 ~45 ~16 ~18 ~45 spruce_planks
fill ~-13 ~18 ~46 ~13 ~18 ~46 spruce_planks
fill ~-9 ~18 ~47 ~9 ~18 ~47 spruce_planks
setblock ~-40 ~18 ~-20 ochre_froglight
setblock ~-40 ~18 ~-15 ochre_froglight
setblock ~-40 ~18 ~-10 ochre_froglight
setblock ~-40 ~18 ~-5 ochre_froglight
setblock ~-40 ~18 ~0 ochre_froglight
setblock ~-40 ~18 ~5 ochre_froglight
setblock ~-40 ~18 ~10 ochre_froglight
setblock ~-40 ~18 ~15 ochre_froglight
setblock ~-40 ~18 ~20 ochre_froglight
setblock ~-35 ~18 ~-25 ochre_froglight
setblock ~-35 ~18 ~-20 ochre_froglight
setblock ~-35 ~18 ~-15 ochre_froglight
setblock ~-35 ~18 ~-10 ochre_froglight
setblock ~-35 ~18 ~-5 ochre_froglight
setblock ~-35 ~18 ~0 ochre_froglight
setblock ~-35 ~18 ~5 ochre_froglight
setblock ~-35 ~18 ~10 ochre_froglight
setblock ~-35 ~18 ~15 ochre_froglight
setblock ~-35 ~18 ~20 ochre_froglight
setblock ~-35 ~18 ~25 ochre_froglight
setblock ~-30 ~18 ~-30 ochre_froglight
setblock ~-30 ~18 ~-25 ochre_froglight
setblock ~-30 ~18 ~-20 ochre_froglight
setblock ~-30 ~18 ~-15 ochre_froglight
setblock ~-30 ~18 ~-10 ochre_froglight
setblock ~-30 ~18 ~-5 ochre_froglight
setblock ~-30 ~18 ~0 ochre_froglight
setblock ~-30 ~18 ~5 ochre_froglight
setblock ~-30 ~18 ~10 ochre_froglight
setblock ~-30 ~18 ~15 ochre_froglight
setblock ~-30 ~18 ~20 ochre_froglight
setblock ~-30 ~18 ~25 ochre_froglight
setblock ~-30 ~18 ~30 ochre_froglight
setblock ~-25 ~18 ~-35 ochre_froglight
setblock ~-25 ~18 ~-30 ochre_froglight
setblock ~-25 ~18 ~-25 ochre_froglight
setblock ~-25 ~18 ~-20 ochre_froglight
setblock ~-25 ~18 ~-15 ochre_froglight
setblock ~-25 ~18 ~-10 ochre_froglight
setblock ~-25 ~18 ~-5 ochre_froglight
setblock ~-25 ~18 ~0 ochre_froglight
setblock ~-25 ~18 ~5 ochre_froglight
setblock ~-25 ~18 ~10 ochre_froglight
setblock ~-25 ~18 ~15 ochre_froglight
setblock ~-25 ~18 ~20 ochre_froglight
setblock ~-25 ~18 ~25 ochre_froglight
setblock ~-25 ~18 ~30 ochre_froglight
setblock ~-25 ~18 ~35 ochre_froglight
setblock ~-20 ~18 ~-40 ochre_froglight
setblock ~-20 ~18 ~-35 ochre_froglight
setblock ~-20 ~18 ~-30 ochre_froglight
setblock ~-20 ~18 ~-25 ochre_froglight
setblock ~-20 ~18 ~-20 ochre_froglight
setblock ~-20 ~18 ~-15 ochre_froglight
setblock ~-20 ~18 ~15 ochre_froglight
setblock ~-20 ~18 ~20 ochre_froglight
setblock ~-20 ~18 ~25 ochre_froglight
setblock ~-20 ~18 ~30 ochre_froglight
setblock ~-20 ~18 ~35 ochre_froglight
setblock ~-20 ~18 ~40 ochre_froglight
setblock ~-15 ~18 ~-40 ochre_froglight
setblock ~-15 ~18 ~-35 ochre_froglight
setblock ~-15 ~18 ~-30 ochre_froglight
setblock ~-15 ~18 ~-25 ochre_froglight
setblock ~-15 ~18 ~-20 ochre_froglight
setblock ~-15 ~18 ~20 ochre_froglight
setblock ~-15 ~18 ~25 ochre_froglight
setblock ~-15 ~18 ~30 ochre_froglight
setblock ~-15 ~18 ~35 ochre_froglight
setblock ~-15 ~18 ~40 ochre_froglight
setblock ~-10 ~18 ~-40 ochre_froglight
setblock ~-10 ~18 ~-35 ochre_froglight
setblock ~-10 ~18 ~-30 ochre_froglight
setblock ~-10 ~18 ~-25 ochre_froglight
setblock ~-10 ~18 ~25 ochre_froglight
setblock ~-10 ~18 ~30 ochre_froglight
setblock ~-10 ~18 ~35 ochre_froglight
setblock ~-10 ~18 ~40 ochre_froglight
setblock ~-5 ~18 ~-40 ochre_froglight
setblock ~-5 ~18 ~-35 ochre_froglight
setblock ~-5 ~18 ~-30 ochre_froglight
setblock ~-5 ~18 ~-25 ochre_froglight
setblock ~-5 ~18 ~25 ochre_froglight
setblock ~-5 ~18 ~30 ochre_froglight
setblock ~-5 ~18 ~35 ochre_froglight
setblock ~-5 ~18 ~40 ochre_froglight
setblock ~0 ~18 ~-40 ochre_froglight
setblock ~0 ~18 ~-35 ochre_froglight
setblock ~0 ~18 ~-30 ochre_froglight
setblock ~0 ~18 ~-25 ochre_froglight
setblock ~0 ~18 ~25 ochre_froglight
setblock ~0 ~18 ~30 ochre_froglight
setblock ~0 ~18 ~35 ochre_froglight
setblock ~0 ~18 ~40 ochre_froglight
setblock ~5 ~18 ~-40 ochre_froglight
setblock ~5 ~18 ~-35 ochre_froglight
setblock ~5 ~18 ~-30 ochre_froglight
setblock ~5 ~18 ~-25 ochre_froglight
setblock ~5 ~18 ~25 ochre_froglight
setblock ~5 ~18 ~30 ochre_froglight
setblock ~5 ~18 ~35 ochre_froglight
setblock ~5 ~18 ~40 ochre_froglight
setblock ~10 ~18 ~-40 ochre_froglight
setblock ~10 ~18 ~-35 ochre_froglight
setblock ~10 ~18 ~-30 ochre_froglight
setblock ~10 ~18 ~-25 ochre_froglight
setblock ~10 ~18 ~25 ochre_froglight
setblock ~10 ~18 ~30 ochre_froglight
setblock ~10 ~18 ~35 ochre_froglight
setblock ~10 ~18 ~40 ochre_froglight
setblock ~15 ~18 ~-40 ochre_froglight
setblock ~15 ~18 ~-35 ochre_froglight
setblock ~15 ~18 ~-30 ochre_froglight
setblock ~15 ~18 ~-25 ochre_froglight
setblock ~15 ~18 ~-20 ochre_froglight
setblock ~15 ~18 ~20 ochre_froglight
setblock ~15 ~18 ~25 ochre_froglight
setblock ~15 ~18 ~30 ochre_froglight
setblock ~15 ~18 ~35 ochre_froglight
setblock ~15 ~18 ~40 ochre_froglight
setblock ~20 ~18 ~-40 ochre_froglight
setblock ~20 ~18 ~-35 ochre_froglight
setblock ~20 ~18 ~-30 ochre_froglight
setblock ~20 ~18 ~-25 ochre_froglight
setblock ~20 ~18 ~-20 ochre_froglight
setblock ~20 ~18 ~-15 ochre_froglight
setblock ~20 ~18 ~15 ochre_froglight
setblock ~20 ~18 ~20 ochre_froglight
setblock ~20 ~18 ~25 ochre_froglight
setblock ~20 ~18 ~30 ochre_froglight
setblock ~20 ~18 ~35 ochre_froglight
setblock ~20 ~18 ~40 ochre_froglight
setblock ~25 ~18 ~-35 ochre_froglight
setblock ~25 ~18 ~-30 ochre_froglight
setblock ~25 ~18 ~-25 ochre_froglight
setblock ~25 ~18 ~-20 ochre_froglight
setblock ~25 ~18 ~-15 ochre_froglight
setblock ~25 ~18 ~-10 ochre_froglight
setblock ~25 ~18 ~-5 ochre_froglight
setblock ~25 ~18 ~0 ochre_froglight
setblock ~25 ~18 ~5 ochre_froglight
setblock ~25 ~18 ~10 ochre_froglight
setblock ~25 ~18 ~15 ochre_froglight
setblock ~25 ~18 ~20 ochre_froglight
setblock ~25 ~18 ~25 ochre_froglight
setblock ~25 ~18 ~30 ochre_froglight
setblock ~25 ~18 ~35 ochre_froglight
setblock ~30 ~18 ~-30 ochre_froglight
setblock ~30 ~18 ~-25 ochre_froglight
setblock ~30 ~18 ~-20 ochre_froglight
setblock ~30 ~18 ~-15 ochre_froglight
setblock ~30 ~18 ~-10 ochre_froglight
setblock ~30 ~18 ~-5 ochre_froglight
setblock ~30 ~18 ~0 ochre_froglight
setblock ~30 ~18 ~5 ochre_froglight
setblock ~30 ~18 ~10 ochre_froglight
setblock ~30 ~18 ~15 ochre_froglight
setblock ~30 ~18 ~20 ochre_froglight
setblock ~30 ~18 ~25 ochre_froglight
setblock ~30 ~18 ~30 ochre_froglight
setblock ~35 ~18 ~-25 ochre_froglight
setblock ~35 ~18 ~-20 ochre_froglight
setblock ~35 ~18 ~-15 ochre_froglight
setblock ~35 ~18 ~-10 ochre_froglight
setblock ~35 ~18 ~-5 ochre_froglight
setblock ~35 ~18 ~0 ochre_froglight
setblock ~35 ~18 ~5 ochre_froglight
setblock ~35 ~18 ~10 ochre_froglight
setblock ~35 ~18 ~15 ochre_froglight
setblock ~35 ~18 ~20 ochre_froglight
setblock ~35 ~18 ~25 ochre_froglight
setblock ~40 ~18 ~-20 ochre_froglight
setblock ~40 ~18 ~-15 ochre_froglight
setblock ~40 ~18 ~-10 ochre_froglight
setblock ~40 ~18 ~-5 ochre_froglight
setblock ~40 ~18 ~0 ochre_froglight
setblock ~40 ~18 ~5 ochre_froglight
setblock ~40 ~18 ~10 ochre_froglight
setblock ~40 ~18 ~15 ochre_froglight
setblock ~40 ~18 ~20 ochre_froglight
fill ~-9 ~19 ~-45 ~9 ~19 ~-45 blue_carpet
fill ~-13 ~19 ~-44 ~13 ~19 ~-44 blue_carpet
fill ~-16 ~19 ~-43 ~16 ~19 ~-43 blue_carpet
fill ~-18 ~19 ~-42 ~18 ~19 ~-42 blue_carpet
fill ~-20 ~19 ~-41 ~20 ~19 ~-41 blue_carpet
fill ~-22 ~19 ~-40 ~22 ~19 ~-40 blue_carpet
fill ~-24 ~19 ~-39 ~24 ~19 ~-39 blue_carpet
fill ~-25 ~19 ~-38 ~25 ~19 ~-38 blue_carpet
fill ~-27 ~19 ~-37 ~27 ~19 ~-37 blue_carpet
fill ~-28 ~19 ~-36 ~28 ~19 ~-36 blue_carpet
fill ~-29 ~19 ~-35 ~29 ~19 ~-35 blue_carpet
fill ~-30 ~19 ~-34 ~30 ~19 ~-34 blue_carpet
fill ~-32 ~19 ~-33 ~32 ~19 ~-33 blue_carpet
fill ~-33 ~19 ~-32 ~33 ~19 ~-32 blue_carpet
fill ~-33 ~19 ~-31 ~33 ~19 ~-31 blue_carpet
fill ~-34 ~19 ~-30 ~34 ~19 ~-30 blue_carpet
fill ~-35 ~19 ~-29 ~35 ~19 ~-29 blue_carpet
fill ~-36 ~19 ~-28 ~36 ~19 ~-28 blue_carpet
fill ~-37 ~19 ~-27 ~37 ~19 ~-27 blue_carpet
fill ~-37 ~19 ~-26 ~37 ~19 ~-26 blue_carpet
fill ~-38 ~19 ~-25 ~38 ~19 ~-25 blue_carpet
fill ~-39 ~19 ~-24 ~39 ~19 ~-24 blue_carpet
fill ~-39 ~19 ~-23 ~39 ~19 ~-23 blue_carpet
fill ~-40 ~19 ~-22 ~-7 ~19 ~-22 blue_carpet
fill ~7 ~19 ~-22 ~40 ~19 ~-22 blue_carpet
fill ~-40 ~19 ~-21 ~-10 ~19 ~-21 blue_carpet
fill ~10 ~19 ~-21 ~40 ~19 ~-21 blue_carpet
fill ~-41 ~19 ~-20 ~-12 ~19 ~-20 blue_carpet
fill ~12 ~19 ~-20 ~41 ~19 ~-20 blue_carpet
fill ~-41 ~19 ~-19 ~-13 ~19 ~-19 blue_carpet
fill ~13 ~19 ~-19 ~41 ~19 ~-19 blue_carpet
fill ~-42 ~19 ~-18 ~-15 ~19 ~-18 blue_carpet
fill ~15 ~19 ~-18 ~42 ~19 ~-18 blue_carpet
fill ~-42 ~19 ~-17 ~-16 ~19 ~-17 blue_carpet
fill ~16 ~19 ~-17 ~42 ~19 ~-17 blue_carpet
fill ~-43 ~19 ~-16 ~-17 ~19 ~-16 blue_carpet
fill ~17 ~19 ~-16 ~43 ~19 ~-16 blue_carpet
fill ~-43 ~19 ~-15 ~-18 ~19 ~-15 blue_carpet
fill ~18 ~19 ~-15 ~43 ~19 ~-15 blue_carpet
fill ~-43 ~19 ~-14 ~-19 ~19 ~-14 blue_carpet
fill ~19 ~19 ~-14 ~43 ~19 ~-14 blue_carpet
fill ~-44 ~19 ~-13 ~-19 ~19 ~-13 blue_carpet
fill ~19 ~19 ~-13 ~44 ~19 ~-13 blue_carpet
fill ~-44 ~19 ~-12 ~-20 ~19 ~-12 blue_carpet
fill ~20 ~19 ~-12 ~44 ~19 ~-12 blue_carpet
fill ~-44 ~19 ~-11 ~-21 ~19 ~-11 blue_carpet
fill ~21 ~19 ~-11 ~44 ~19 ~-11 blue_carpet
fill ~-44 ~19 ~-10 ~-21 ~19 ~-10 blue_carpet
fill ~21 ~19 ~-10 ~44 ~19 ~-10 blue_carpet
fill ~-45 ~19 ~-9 ~-22 ~19 ~-9 blue_carpet
fill ~22 ~19 ~-9 ~45 ~19 ~-9 blue_carpet
fill ~-45 ~19 ~-8 ~-22 ~19 ~-8 blue_carpet
fill ~22 ~19 ~-8 ~45 ~19 ~-8 blue_carpet
fill ~-45 ~19 ~-7 ~-22 ~19 ~-7 blue_carpet
fill ~22 ~19 ~-7 ~45 ~19 ~-7 blue_carpet
fill ~-45 ~19 ~-6 ~-23 ~19 ~-6 blue_carpet
fill ~23 ~19 ~-6 ~45 ~19 ~-6 blue_carpet
fill ~-45 ~19 ~-5 ~-23 ~19 ~-5 blue_carpet
fill ~23 ~19 ~-5 ~45 ~19 ~-5 blue_carpet
fill ~-45 ~19 ~-4 ~-23 ~19 ~-4 blue_carpet
fill ~23 ~19 ~-4 ~45 ~19 ~-4 blue_carpet
fill ~-45 ~19 ~-3 ~-23 ~19 ~-3 blue_carpet
fill ~23 ~19 ~-3 ~45 ~19 ~-3 blue_carpet
fill ~-45 ~19 ~-2 ~-23 ~19 ~-2 blue_carpet
fill ~23 ~19 ~-2 ~45 ~19 ~-2 blue_carpet
fill ~-45 ~19 ~-1 ~-23 ~19 ~-1 blue_carpet
fill ~23 ~19 ~-1 ~45 ~19 ~-1 blue_carpet
fill ~-45 ~19 ~0 ~-23 ~19 ~0 blue_carpet
fill ~23 ~19 ~0 ~45 ~19 ~0 blue_carpet
fill ~-45 ~19 ~1 ~-23 ~19 ~1 blue_carpet
fill ~23 ~19 ~1 ~45 ~19 ~1 blue_carpet
fill ~-45 ~19 ~2 ~-23 ~19 ~2 blue_carpet
fill ~23 ~19 ~2 ~45 ~19 ~2 blue_carpet
fill ~-45 ~19 ~3 ~-23 ~19 ~3 blue_carpet
fill ~23 ~19 ~3 ~45 ~19 ~3 blue_carpet
fill ~-45 ~19 ~4 ~-23 ~19 ~4 blue_carpet
fill ~23 ~19 ~4 ~45 ~19 ~4 blue_carpet
fill ~-45 ~19 ~5 ~-23 ~19 ~5 blue_carpet
fill ~23 ~19 ~5 ~45 ~19 ~5 blue_carpet
fill ~-45 ~19 ~6 ~-23 ~19 ~6 blue_carpet
fill ~23 ~19 ~6 ~45 ~19 ~6 blue_carpet
fill ~-45 ~19 ~7 ~-22 ~19 ~7 blue_carpet
fill ~22 ~19 ~7 ~45 ~19 ~7 blue_carpet
fill ~-45 ~19 ~8 ~-22 ~19 ~8 blue_carpet
fill ~22 ~19 ~8 ~45 ~19 ~8 blue_carpet
fill ~-45 ~19 ~9 ~-22 ~19 ~9 blue_carpet
fill ~22 ~19 ~9 ~45 ~19 ~9 blue_carpet
fill ~-44 ~19 ~10 ~-21 ~19 ~10 blue_carpet
fill ~21 ~19 ~10 ~44 ~19 ~10 blue_carpet
fill ~-44 ~19 ~11 ~-21 ~19 ~11 blue_carpet
fill ~21 ~19 ~11 ~44 ~19 ~11 blue_carpet
fill ~-44 ~19 ~12 ~-20 ~19 ~12 blue_carpet
fill ~20 ~19 ~12 ~44 ~19 ~12 blue_carpet
fill ~-44 ~19 ~13 ~-19 ~19 ~13 blue_carpet
fill ~19 ~19 ~13 ~44 ~19 ~13 blue_carpet
fill ~-43 ~19 ~14 ~-19 ~19 ~14 blue_carpet
fill ~19 ~19 ~14 ~43 ~19 ~14 blue_carpet
fill ~-43 ~19 ~15 ~-18 ~19 ~15 blue_carpet
fill ~18 ~19 ~15 ~43 ~19 ~15 blue_carpet
fill ~-43 ~19 ~16 ~-17 ~19 ~16 blue_carpet
fill ~17 ~19 ~16 ~43 ~19 ~16 blue_carpet
fill ~-42 ~19 ~17 ~-16 ~19 ~17 blue_carpet
fill ~16 ~19 ~17 ~42 ~19 ~17 blue_carpet
fill ~-42 ~19 ~18 ~-15 ~19 ~18 blue_carpet
fill ~15 ~19 ~18 ~42 ~19 ~18 blue_carpet
fill ~-41 ~19 ~19 ~-13 ~19 ~19 blue_carpet
fill ~13 ~19 ~19 ~41 ~19 ~19 blue_carpet
fill ~-41 ~19 ~20 ~-12 ~19 ~20 blue_carpet
fill ~12 ~19 ~20 ~41 ~19 ~20 blue_carpet
fill ~-40 ~19 ~21 ~-10 ~19 ~21 blue_carpet
fill ~10 ~19 ~21 ~40 ~19 ~21 blue_carpet
fill ~-40 ~19 ~22 ~-7 ~19 ~22 blue_carpet
fill ~7 ~19 ~22 ~40 ~19 ~22 blue_carpet
fill ~-39 ~19 ~23 ~39 ~19 ~23 blue_carpet
fill ~-39 ~19 ~24 ~39 ~19 ~24 blue_carpet
fill ~-38 ~19 ~25 ~38 ~19 ~25 blue_carpet
fill ~-37 ~19 ~26 ~37 ~19 ~26 blue_carpet
fill ~-37 ~19 ~27 ~37 ~19 ~27 blue_carpet
fill ~-36 ~19 ~28 ~36 ~19 ~28 blue_carpet
fill ~-35 ~19 ~29 ~35 ~19 ~29 blue_carpet
fill ~-34 ~19 ~30 ~34 ~19 ~30 blue_carpet
fill ~-33 ~19 ~31 ~33 ~19 ~31 blue_carpet
fill ~-33 ~19 ~32 ~33 ~19 ~32 blue_carpet
fill ~-32 ~19 ~33 ~32 ~19 ~33 blue_carpet
fill ~-30 ~19 ~34 ~30 ~19 ~34 blue_carpet
fill ~-29 ~19 ~35 ~29 ~19 ~35 blue_carpet
fill ~-28 ~19 ~36 ~28 ~19 ~36 blue_carpet
fill ~-27 ~19 ~37 ~27 ~19 ~37 blue_carpet
fill ~-25 ~19 ~38 ~25 ~19 ~38 blue_carpet
fill ~-24 ~19 ~39 ~24 ~19 ~39 blue_carpet
fill ~-22 ~19 ~40 ~22 ~19 ~40 blue_carpet
fill ~-20 ~19 ~41 ~20 ~19 ~41 blue_carpet
fill ~-18 ~19 ~42 ~18 ~19 ~42 blue_carpet
fill ~-16 ~19 ~43 ~16 ~19 ~43 blue_carpet
fill ~-13 ~19 ~44 ~13 ~19 ~44 blue_carpet
fill ~-9 ~19 ~45 ~9 ~19 ~45 blue_carpet
fill ~-6 ~19 ~-25 ~6 ~19 ~-25 cyan_carpet
fill ~-9 ~19 ~-24 ~-7 ~19 ~-24 cyan_carpet
fill ~7 ~19 ~-24 ~9 ~19 ~-24 cyan_carpet
fill ~-11 ~19 ~-23 ~-10 ~19 ~-23 cyan_carpet
fill ~10 ~19 ~-23 ~11 ~19 ~-23 cyan_carpet
fill ~-13 ~19 ~-22 ~-12 ~19 ~-22 cyan_carpet
fill ~12 ~19 ~-22 ~13 ~19 ~-22 cyan_carpet
fill ~-15 ~19 ~-21 ~-14 ~19 ~-21 cyan_carpet
fill ~14 ~19 ~-21 ~15 ~19 ~-21 cyan_carpet
fill ~-16 ~19 ~-20 ~-15 ~19 ~-20 cyan_carpet
fill ~15 ~19 ~-20 ~16 ~19 ~-20 cyan_carpet
fill ~-17 ~19 ~-19 ~-17 ~19 ~-19 cyan_carpet
fill ~17 ~19 ~-19 ~17 ~19 ~-19 cyan_carpet
fill ~-18 ~19 ~-18 ~-18 ~19 ~-18 cyan_carpet
fill ~18 ~19 ~-18 ~18 ~19 ~-18 cyan_carpet
fill ~-19 ~19 ~-17 ~-19 ~19 ~-17 cyan_carpet
fill ~19 ~19 ~-17 ~19 ~19 ~-17 cyan_carpet
fill ~-20 ~19 ~-16 ~-20 ~19 ~-16 cyan_carpet
fill ~20 ~19 ~-16 ~20 ~19 ~-16 cyan_carpet
fill ~-21 ~19 ~-15 ~-20 ~19 ~-15 cyan_carpet
fill ~20 ~19 ~-15 ~21 ~19 ~-15 cyan_carpet
fill ~-21 ~19 ~-14 ~-21 ~19 ~-14 cyan_carpet
fill ~21 ~19 ~-14 ~21 ~19 ~-14 cyan_carpet
fill ~-22 ~19 ~-13 ~-22 ~19 ~-13 cyan_carpet
fill ~22 ~19 ~-13 ~22 ~19 ~-13 cyan_carpet
fill ~-22 ~19 ~-12 ~-22 ~19 ~-12 cyan_carpet
fill ~22 ~19 ~-12 ~22 ~19 ~-12 cyan_carpet
fill ~-23 ~19 ~-11 ~-23 ~19 ~-11 cyan_carpet
fill ~23 ~19 ~-11 ~23 ~19 ~-11 cyan_carpet
fill ~-23 ~19 ~-10 ~-23 ~19 ~-10 cyan_carpet
fill ~23 ~19 ~-10 ~23 ~19 ~-10 cyan_carpet
fill ~-24 ~19 ~-9 ~-24 ~19 ~-9 cyan_carpet
fill ~24 ~19 ~-9 ~24 ~19 ~-9 cyan_carpet
fill ~-24 ~19 ~-8 ~-24 ~19 ~-8 cyan_carpet
fill ~24 ~19 ~-8 ~24 ~19 ~-8 cyan_carpet
fill ~-24 ~19 ~-7 ~-24 ~19 ~-7 cyan_carpet
fill ~24 ~19 ~-7 ~24 ~19 ~-7 cyan_carpet
fill ~-25 ~19 ~-6 ~-25 ~19 ~-6 cyan_carpet
fill ~25 ~19 ~-6 ~25 ~19 ~-6 cyan_carpet
fill ~-25 ~19 ~-5 ~-25 ~19 ~-5 cyan_carpet
fill ~25 ~19 ~-5 ~25 ~19 ~-5 cyan_carpet
fill ~-25 ~19 ~-4 ~-25 ~19 ~-4 cyan_carpet
fill ~25 ~19 ~-4 ~25 ~19 ~-4 cyan_carpet
fill ~-25 ~19 ~-3 ~-25 ~19 ~-3 cyan_carpet
fill ~25 ~19 ~-3 ~25 ~19 ~-3 cyan_carpet
fill ~-25 ~19 ~-2 ~-25 ~19 ~-2 cyan_carpet
fill ~25 ~19 ~-2 ~25 ~19 ~-2 cyan_carpet
fill ~-25 ~19 ~-1 ~-25 ~19 ~-1 cyan_carpet
fill ~25 ~19 ~-1 ~25 ~19 ~-1 cyan_carpet
fill ~-25 ~19 ~0 ~-25 ~19 ~0 cyan_carpet
fill ~25 ~19 ~0 ~25 ~19 ~0 cyan_carpet
fill ~-25 ~19 ~1 ~-25 ~19 ~1 cyan_carpet
fill ~25 ~19 ~1 ~25 ~19 ~1 cyan_carpet
fill ~-25 ~19 ~2 ~-25 ~19 ~2 cyan_carpet
fill ~25 ~19 ~2 ~25 ~19 ~2 cyan_carpet
fill ~-25 ~19 ~3 ~-25 ~19 ~3 cyan_carpet
fill ~25 ~19 ~3 ~25 ~19 ~3 cyan_carpet
fill ~-25 ~19 ~4 ~-25 ~19 ~4 cyan_carpet
fill ~25 ~19 ~4 ~25 ~19 ~4 cyan_carpet
fill ~-25 ~19 ~5 ~-25 ~19 ~5 cyan_carpet
fill ~25 ~19 ~5 ~25 ~19 ~5 cyan_carpet
fill ~-25 ~19 ~6 ~-25 ~19 ~6 cyan_carpet
fill ~25 ~19 ~6 ~25 ~19 ~6 cyan_carpet
fill ~-24 ~19 ~7 ~-24 ~19 ~7 cyan_carpet
fill ~24 ~19 ~7 ~24 ~19 ~7 cyan_carpet
fill ~-24 ~19 ~8 ~-24 ~19 ~8 cyan_carpet
fill ~24 ~19 ~8 ~24 ~19 ~8 cyan_carpet
fill ~-24 ~19 ~9 ~-24 ~19 ~9 cyan_carpet
fill ~24 ~19 ~9 ~24 ~19 ~9 cyan_carpet
fill ~-23 ~19 ~10 ~-23 ~19 ~10 cyan_carpet
fill ~23 ~19 ~10 ~23 ~19 ~10 cyan_carpet
fill ~-23 ~19 ~11 ~-23 ~19 ~11 cyan_carpet
fill ~23 ~19 ~11 ~23 ~19 ~11 cyan_carpet
fill ~-22 ~19 ~12 ~-22 ~19 ~12 cyan_carpet
fill ~22 ~19 ~12 ~22 ~19 ~12 cyan_carpet
fill ~-22 ~19 ~13 ~-22 ~19 ~13 cyan_carpet
fill ~22 ~19 ~13 ~22 ~19 ~13 cyan_carpet
fill ~-21 ~19 ~14 ~-21 ~19 ~14 cyan_carpet
fill ~21 ~19 ~14 ~21 ~19 ~14 cyan_carpet
fill ~-21 ~19 ~15 ~-20 ~19 ~15 cyan_carpet
fill ~20 ~19 ~15 ~21 ~19 ~15 cyan_carpet
fill ~-20 ~19 ~16 ~-20 ~19 ~16 cyan_carpet
fill ~20 ~19 ~16 ~20 ~19 ~16 cyan_carpet
fill ~-19 ~19 ~17 ~-19 ~19 ~17 cyan_carpet
fill ~19 ~19 ~17 ~19 ~19 ~17 cyan_carpet
fill ~-18 ~19 ~18 ~-18 ~19 ~18 cyan_carpet
fill ~18 ~19 ~18 ~18 ~19 ~18 cyan_carpet
fill ~-17 ~19 ~19 ~-17 ~19 ~19 cyan_carpet
fill ~17 ~19 ~19 ~17 ~19 ~19 cyan_carpet
fill ~-16 ~19 ~20 ~-15 ~19 ~20 cyan_carpet
fill ~15 ~19 ~20 ~16 ~19 ~20 cyan_carpet
fill ~-15 ~19 ~21 ~-14 ~19 ~21 cyan_carpet
fill ~14 ~19 ~21 ~15 ~19 ~21 cyan_carpet
fill ~-13 ~19 ~22 ~-12 ~19 ~22 cyan_carpet
fill ~12 ~19 ~22 ~13 ~19 ~22 cyan_carpet
fill ~-11 ~19 ~23 ~-10 ~19 ~23 cyan_carpet
fill ~10 ~19 ~23 ~11 ~19 ~23 cyan_carpet
fill ~-9 ~19 ~24 ~-7 ~19 ~24 cyan_carpet
fill ~7 ~19 ~24 ~9 ~19 ~24 cyan_carpet
fill ~-6 ~19 ~25 ~6 ~19 ~25 cyan_carpet
fill ~-2 ~17 ~-23 ~2 ~18 ~-23 smooth_quartz
fill ~-7 ~17 ~-22 ~7 ~18 ~-22 smooth_quartz
fill ~-9 ~17 ~-21 ~-6 ~18 ~-21 smooth_quartz
fill ~6 ~17 ~-21 ~9 ~18 ~-21 smooth_quartz
fill ~-11 ~17 ~-20 ~-9 ~18 ~-20 smooth_quartz
fill ~9 ~17 ~-20 ~11 ~18 ~-20 smooth_quartz
fill ~-13 ~17 ~-19 ~-11 ~18 ~-19 smooth_quartz
fill ~11 ~17 ~-19 ~13 ~18 ~-19 smooth_quartz
fill ~-14 ~17 ~-18 ~-13 ~18 ~-18 smooth_quartz
fill ~13 ~17 ~-18 ~14 ~18 ~-18 smooth_quartz
fill ~-15 ~17 ~-17 ~-14 ~18 ~-17 smooth_quartz
fill ~14 ~17 ~-17 ~15 ~18 ~-17 smooth_quartz
fill ~-16 ~17 ~-16 ~-15 ~18 ~-16 smooth_quartz
fill ~15 ~17 ~-16 ~16 ~18 ~-16 smooth_quartz
fill ~-17 ~17 ~-15 ~-16 ~18 ~-15 smooth_quartz
fill ~16 ~17 ~-15 ~17 ~18 ~-15 smooth_quartz
fill ~-18 ~17 ~-14 ~-17 ~18 ~-14 smooth_quartz
fill ~17 ~17 ~-14 ~18 ~18 ~-14 smooth_quartz
fill ~-19 ~17 ~-13 ~-18 ~18 ~-13 smooth_quartz
fill ~18 ~17 ~-13 ~19 ~18 ~-13 smooth_quartz
fill ~-19 ~17 ~-12 ~-19 ~18 ~-12 smooth_quartz
fill ~19 ~17 ~-12 ~19 ~18 ~-12 smooth_quartz
fill ~-20 ~17 ~-11 ~-19 ~18 ~-11 smooth_quartz
fill ~19 ~17 ~-11 ~20 ~18 ~-11 smooth_quartz
fill ~-20 ~17 ~-10 ~-20 ~18 ~-10 smooth_quartz
fill ~20 ~17 ~-10 ~20 ~18 ~-10 smooth_quartz
fill ~-21 ~17 ~-9 ~-20 ~18 ~-9 smooth_quartz
fill ~20 ~17 ~-9 ~21 ~18 ~-9 smooth_quartz
fill ~-21 ~17 ~-8 ~-21 ~18 ~-8 smooth_quartz
fill ~21 ~17 ~-8 ~21 ~18 ~-8 smooth_quartz
fill ~-22 ~17 ~-7 ~-21 ~18 ~-7 smooth_quartz
fill ~21 ~17 ~-7 ~22 ~18 ~-7 smooth_quartz
fill ~-22 ~17 ~-6 ~-21 ~18 ~-6 smooth_quartz
fill ~21 ~17 ~-6 ~22 ~18 ~-6 smooth_quartz
fill ~-22 ~17 ~-5 ~-22 ~18 ~-5 smooth_quartz
fill ~22 ~17 ~-5 ~22 ~18 ~-5 smooth_quartz
fill ~-22 ~17 ~-4 ~-22 ~18 ~-4 smooth_quartz
fill ~22 ~17 ~-4 ~22 ~18 ~-4 smooth_quartz
fill ~-22 ~17 ~-3 ~-22 ~18 ~-3 smooth_quartz
fill ~22 ~17 ~-3 ~22 ~18 ~-3 smooth_quartz
fill ~-23 ~17 ~-2 ~-22 ~18 ~-2 smooth_quartz
fill ~22 ~17 ~-2 ~23 ~18 ~-2 smooth_quartz
fill ~-23 ~17 ~-1 ~-22 ~18 ~-1 smooth_quartz
fill ~22 ~17 ~-1 ~23 ~18 ~-1 smooth_quartz
fill ~-23 ~17 ~0 ~-22 ~18 ~0 smooth_quartz
fill ~22 ~17 ~0 ~23 ~18 ~0 smooth_quartz
fill ~-23 ~17 ~1 ~-22 ~18 ~1 smooth_quartz
fill ~22 ~17 ~1 ~23 ~18 ~1 smooth_quartz
fill ~-23 ~17 ~2 ~-22 ~18 ~2 smooth_quartz
fill ~22 ~17 ~2 ~23 ~18 ~2 smooth_quartz
fill ~-22 ~17 ~3 ~-22 ~18 ~3 smooth_quartz
fill ~22 ~17 ~3 ~22 ~18 ~3 smooth_quartz
fill ~-22 ~17 ~4 ~-22 ~18 ~4 smooth_quartz
fill ~22 ~17 ~4 ~22 ~18 ~4 smooth_quartz
fill ~-22 ~17 ~5 ~-22 ~18 ~5 smooth_quartz
fill ~22 ~17 ~5 ~22 ~18 ~5 smooth_quartz
fill ~-22 ~17 ~6 ~-21 ~18 ~6 smooth_quartz
fill ~21 ~17 ~6 ~22 ~18 ~6 smooth_quartz
fill ~-22 ~17 ~7 ~-21 ~18 ~7 smooth_quartz
fill ~21 ~17 ~7 ~22 ~18 ~7 smooth_quartz
fill ~-21 ~17 ~8 ~-21 ~18 ~8 smooth_quartz
fill ~21 ~17 ~8 ~21 ~18 ~8 smooth_quartz
fill ~-21 ~17 ~9 ~-20 ~18 ~9 smooth_quartz
fill ~20 ~17 ~9 ~21 ~18 ~9 smooth_quartz
fill ~-20 ~17 ~10 ~-20 ~18 ~10 smooth_quartz
fill ~20 ~17 ~10 ~20 ~18 ~10 smooth_quartz
fill ~-20 ~17 ~11 ~-19 ~18 ~11 smooth_quartz
fill ~19 ~17 ~11 ~20 ~18 ~11 smooth_quartz
fill ~-19 ~17 ~12 ~-19 ~18 ~12 smooth_quartz
fill ~19 ~17 ~12 ~19 ~18 ~12 smooth_quartz
fill ~-19 ~17 ~13 ~-18 ~18 ~13 smooth_quartz
fill ~18 ~17 ~13 ~19 ~18 ~13 smooth_quartz
fill ~-18 ~17 ~14 ~-17 ~18 ~14 smooth_quartz
fill ~17 ~17 ~14 ~18 ~18 ~14 smooth_quartz
fill ~-17 ~17 ~15 ~-16 ~18 ~15 smooth_quartz
fill ~16 ~17 ~15 ~17 ~18 ~15 smooth_quartz
fill ~-16 ~17 ~16 ~-15 ~18 ~16 smooth_quartz
fill ~15 ~17 ~16 ~16 ~18 ~16 smooth_quartz
fill ~-15 ~17 ~17 ~-14 ~18 ~17 smooth_quartz
fill ~14 ~17 ~17 ~15 ~18 ~17 smooth_quartz
fill ~-14 ~17 ~18 ~-13 ~18 ~18 smooth_quartz
fill ~13 ~17 ~18 ~14 ~18 ~18 smooth_quartz
fill ~-13 ~17 ~19 ~-11 ~18 ~19 smooth_quartz
fill ~11 ~17 ~19 ~13 ~18 ~19 smooth_quartz
fill ~-11 ~17 ~20 ~-9 ~18 ~20 smooth_quartz
fill ~9 ~17 ~20 ~11 ~18 ~20 smooth_quartz
fill ~-9 ~17 ~21 ~-6 ~18 ~21 smooth_quartz
fill ~6 ~17 ~21 ~9 ~18 ~21 smooth_quartz
fill ~-7 ~17 ~22 ~7 ~18 ~22 smooth_quartz
fill ~-2 ~17 ~23 ~2 ~18 ~23 smooth_quartz
fill ~-2 ~17 ~-24 ~2 ~17 ~-24 ochre_froglight
fill ~-7 ~17 ~-23 ~-3 ~17 ~-23 ochre_froglight
fill ~3 ~17 ~-23 ~7 ~17 ~-23 ochre_froglight
fill ~-9 ~17 ~-22 ~-8 ~17 ~-22 ochre_froglight
fill ~8 ~17 ~-22 ~9 ~17 ~-22 ochre_froglight
fill ~-11 ~17 ~-21 ~-10 ~17 ~-21 ochre_froglight
fill ~10 ~17 ~-21 ~11 ~17 ~-21 ochre_froglight
fill ~-13 ~17 ~-20 ~-12 ~17 ~-20 ochre_froglight
fill ~12 ~17 ~-20 ~13 ~17 ~-20 ochre_froglight
fill ~-14 ~17 ~-19 ~-14 ~17 ~-19 ochre_froglight
fill ~14 ~17 ~-19 ~14 ~17 ~-19 ochre_froglight
fill ~-16 ~17 ~-18 ~-15 ~17 ~-18 ochre_froglight
fill ~15 ~17 ~-18 ~16 ~17 ~-18 ochre_froglight
fill ~-17 ~17 ~-17 ~-16 ~17 ~-17 ochre_froglight
fill ~16 ~17 ~-17 ~17 ~17 ~-17 ochre_froglight
fill ~-18 ~17 ~-16 ~-17 ~17 ~-16 ochre_froglight
fill ~17 ~17 ~-16 ~18 ~17 ~-16 ochre_froglight
fill ~-18 ~17 ~-15 ~-18 ~17 ~-15 ochre_froglight
fill ~18 ~17 ~-15 ~18 ~17 ~-15 ochre_froglight
fill ~-19 ~17 ~-14 ~-19 ~17 ~-14 ochre_froglight
fill ~19 ~17 ~-14 ~19 ~17 ~-14 ochre_froglight
fill ~-20 ~17 ~-13 ~-20 ~17 ~-13 ochre_froglight
fill ~20 ~17 ~-13 ~20 ~17 ~-13 ochre_froglight
fill ~-20 ~17 ~-12 ~-20 ~17 ~-12 ochre_froglight
fill ~20 ~17 ~-12 ~20 ~17 ~-12 ochre_froglight
fill ~-21 ~17 ~-11 ~-21 ~17 ~-11 ochre_froglight
fill ~21 ~17 ~-11 ~21 ~17 ~-11 ochre_froglight
fill ~-21 ~17 ~-10 ~-21 ~17 ~-10 ochre_froglight
fill ~21 ~17 ~-10 ~21 ~17 ~-10 ochre_froglight
fill ~-22 ~17 ~-9 ~-22 ~17 ~-9 ochre_froglight
fill ~22 ~17 ~-9 ~22 ~17 ~-9 ochre_froglight
fill ~-22 ~17 ~-8 ~-22 ~17 ~-8 ochre_froglight
fill ~22 ~17 ~-8 ~22 ~17 ~-8 ochre_froglight
fill ~-23 ~17 ~-7 ~-23 ~17 ~-7 ochre_froglight
fill ~23 ~17 ~-7 ~23 ~17 ~-7 ochre_froglight
fill ~-23 ~17 ~-6 ~-23 ~17 ~-6 ochre_froglight
fill ~23 ~17 ~-6 ~23 ~17 ~-6 ochre_froglight
fill ~-23 ~17 ~-5 ~-23 ~17 ~-5 ochre_froglight
fill ~23 ~17 ~-5 ~23 ~17 ~-5 ochre_froglight
fill ~-23 ~17 ~-4 ~-23 ~17 ~-4 ochre_froglight
fill ~23 ~17 ~-4 ~23 ~17 ~-4 ochre_froglight
fill ~-23 ~17 ~-3 ~-23 ~17 ~-3 ochre_froglight
fill ~23 ~17 ~-3 ~23 ~17 ~-3 ochre_froglight
fill ~-24 ~17 ~-2 ~-24 ~17 ~-2 ochre_froglight
fill ~24 ~17 ~-2 ~24 ~17 ~-2 ochre_froglight
fill ~-24 ~17 ~-1 ~-24 ~17 ~-1 ochre_froglight
fill ~24 ~17 ~-1 ~24 ~17 ~-1 ochre_froglight
fill ~-24 ~17 ~0 ~-24 ~17 ~0 ochre_froglight
fill ~24 ~17 ~0 ~24 ~17 ~0 ochre_froglight
fill ~-24 ~17 ~1 ~-24 ~17 ~1 ochre_froglight
fill ~24 ~17 ~1 ~24 ~17 ~1 ochre_froglight
fill ~-24 ~17 ~2 ~-24 ~17 ~2 ochre_froglight
fill ~24 ~17 ~2 ~24 ~17 ~2 ochre_froglight
fill ~-23 ~17 ~3 ~-23 ~17 ~3 ochre_froglight
fill ~23 ~17 ~3 ~23 ~17 ~3 ochre_froglight
fill ~-23 ~17 ~4 ~-23 ~17 ~4 ochre_froglight
fill ~23 ~17 ~4 ~23 ~17 ~4 ochre_froglight
fill ~-23 ~17 ~5 ~-23 ~17 ~5 ochre_froglight
fill ~23 ~17 ~5 ~23 ~17 ~5 ochre_froglight
fill ~-23 ~17 ~6 ~-23 ~17 ~6 ochre_froglight
fill ~23 ~17 ~6 ~23 ~17 ~6 ochre_froglight
fill ~-23 ~17 ~7 ~-23 ~17 ~7 ochre_froglight
fill ~23 ~17 ~7 ~23 ~17 ~7 ochre_froglight
fill ~-22 ~17 ~8 ~-22 ~17 ~8 ochre_froglight
fill ~22 ~17 ~8 ~22 ~17 ~8 ochre_froglight
fill ~-22 ~17 ~9 ~-22 ~17 ~9 ochre_froglight
fill ~22 ~17 ~9 ~22 ~17 ~9 ochre_froglight
fill ~-21 ~17 ~10 ~-21 ~17 ~10 ochre_froglight
fill ~21 ~17 ~10 ~21 ~17 ~10 ochre_froglight
fill ~-21 ~17 ~11 ~-21 ~17 ~11 ochre_froglight
fill ~21 ~17 ~11 ~21 ~17 ~11 ochre_froglight
fill ~-20 ~17 ~12 ~-20 ~17 ~12 ochre_froglight
fill ~20 ~17 ~12 ~20 ~17 ~12 ochre_froglight
fill ~-20 ~17 ~13 ~-20 ~17 ~13 ochre_froglight
fill ~20 ~17 ~13 ~20 ~17 ~13 ochre_froglight
fill ~-19 ~17 ~14 ~-19 ~17 ~14 ochre_froglight
fill ~19 ~17 ~14 ~19 ~17 ~14 ochre_froglight
fill ~-18 ~17 ~15 ~-18 ~17 ~15 ochre_froglight
fill ~18 ~17 ~15 ~18 ~17 ~15 ochre_froglight
fill ~-18 ~17 ~16 ~-17 ~17 ~16 ochre_froglight
fill ~17 ~17 ~16 ~18 ~17 ~16 ochre_froglight
fill ~-17 ~17 ~17 ~-16 ~17 ~17 ochre_froglight
fill ~16 ~17 ~17 ~17 ~17 ~17 ochre_froglight
fill ~-16 ~17 ~18 ~-15 ~17 ~18 ochre_froglight
fill ~15 ~17 ~18 ~16 ~17 ~18 ochre_froglight
fill ~-14 ~17 ~19 ~-14 ~17 ~19 ochre_froglight
fill ~14 ~17 ~19 ~14 ~17 ~19 ochre_froglight
fill ~-13 ~17 ~20 ~-12 ~17 ~20 ochre_froglight
fill ~12 ~17 ~20 ~13 ~17 ~20 ochre_froglight
fill ~-11 ~17 ~21 ~-10 ~17 ~21 ochre_froglight
fill ~10 ~17 ~21 ~11 ~17 ~21 ochre_froglight
fill ~-9 ~17 ~22 ~-8 ~17 ~22 ochre_froglight
fill ~8 ~17 ~22 ~9 ~17 ~22 ochre_froglight
fill ~-7 ~17 ~23 ~-3 ~17 ~23 ochre_froglight
fill ~3 ~17 ~23 ~7 ~17 ~23 ochre_froglight
fill ~-2 ~17 ~24 ~2 ~17 ~24 ochre_froglight
setblock ~-16 ~18 ~15 smooth_quartz
setblock ~-16 ~19 ~15 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-16 ~20 ~15 spruce_slab
setblock ~3 ~18 ~22 smooth_quartz
setblock ~3 ~19 ~22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~3 ~20 ~22 spruce_slab
setblock ~21 ~18 ~-9 smooth_quartz
setblock ~21 ~19 ~-9 glass_pane[north=false,south=true,west=true,east=false]
setblock ~21 ~20 ~-9 spruce_slab
setblock ~-3 ~18 ~-22 smooth_quartz
setblock ~-3 ~19 ~-22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-3 ~20 ~-22 spruce_slab
setblock ~21 ~18 ~9 smooth_quartz
setblock ~21 ~19 ~9 glass_pane[north=true,south=false,west=true,east=false]
setblock ~21 ~20 ~9 spruce_slab
setblock ~1 ~18 ~-22 smooth_quartz
setblock ~1 ~19 ~-22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~1 ~20 ~-22 spruce_slab
setblock ~11 ~18 ~-20 smooth_quartz
setblock ~11 ~19 ~-20 glass_pane[north=false,south=true,west=true,east=false]
setblock ~11 ~20 ~-20 spruce_slab
setblock ~16 ~18 ~-15 smooth_quartz
setblock ~16 ~19 ~-15 glass_pane[north=true,south=false,west=false,east=true]
setblock ~16 ~20 ~-15 spruce_slab
setblock ~17 ~18 ~14 smooth_quartz
setblock ~17 ~19 ~14 glass_pane[north=false,south=true,west=false,east=true]
setblock ~17 ~20 ~14 spruce_slab
setblock ~19 ~18 ~11 smooth_quartz
setblock ~19 ~19 ~11 glass_pane[north=false,south=true,west=false,east=true]
setblock ~19 ~20 ~11 spruce_slab
setblock ~-22 ~18 ~4 smooth_quartz
setblock ~-22 ~19 ~4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-22 ~20 ~4 spruce_slab
setblock ~-14 ~18 ~17 smooth_quartz
setblock ~-14 ~19 ~17 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-14 ~20 ~17 spruce_slab
setblock ~-13 ~18 ~-18 smooth_quartz
setblock ~-13 ~19 ~-18 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-13 ~20 ~-18 spruce_slab
setblock ~12 ~18 ~-19 smooth_quartz
setblock ~12 ~19 ~-19 glass_pane[north=false,south=false,west=true,east=true]
setblock ~12 ~20 ~-19 spruce_slab
setblock ~3 ~18 ~-22 smooth_quartz
setblock ~3 ~19 ~-22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~3 ~20 ~-22 spruce_slab
setblock ~-20 ~18 ~10 smooth_quartz
setblock ~-20 ~19 ~10 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-20 ~20 ~10 spruce_slab
setblock ~21 ~18 ~-7 smooth_quartz
setblock ~21 ~19 ~-7 glass_pane[north=true,south=false,west=false,east=true]
setblock ~21 ~20 ~-7 spruce_slab
setblock ~-8 ~18 ~21 smooth_quartz
setblock ~-8 ~19 ~21 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-8 ~20 ~21 spruce_slab
setblock ~10 ~18 ~20 smooth_quartz
setblock ~10 ~19 ~20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~10 ~20 ~20 spruce_slab
setblock ~13 ~18 ~19 smooth_quartz
setblock ~13 ~19 ~19 glass_pane[north=true,south=false,west=true,east=false]
setblock ~13 ~20 ~19 spruce_slab
setblock ~15 ~18 ~16 smooth_quartz
setblock ~15 ~19 ~16 glass_pane[north=false,south=true,west=false,east=true]
setblock ~15 ~20 ~16 spruce_slab
setblock ~-18 ~18 ~13 smooth_quartz
setblock ~-18 ~19 ~13 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-18 ~20 ~13 spruce_slab
setblock ~16 ~18 ~15 smooth_quartz
setblock ~16 ~19 ~15 glass_pane[north=false,south=true,west=false,east=true]
setblock ~16 ~20 ~15 spruce_slab
setblock ~-7 ~18 ~22 smooth_quartz
setblock ~-7 ~19 ~22 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-7 ~20 ~22 spruce_slab
setblock ~7 ~18 ~21 smooth_quartz
setblock ~7 ~19 ~21 glass_pane[north=false,south=true,west=false,east=true]
setblock ~7 ~20 ~21 spruce_slab
setblock ~22 ~18 ~3 smooth_quartz
setblock ~22 ~19 ~3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~22 ~20 ~3 spruce_slab
setblock ~-13 ~18 ~18 smooth_quartz
setblock ~-13 ~19 ~18 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-13 ~20 ~18 spruce_slab
setblock ~-19 ~18 ~11 smooth_quartz
setblock ~-19 ~19 ~11 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-19 ~20 ~11 spruce_slab
setblock ~-9 ~18 ~-21 smooth_quartz
setblock ~-9 ~19 ~-21 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-9 ~20 ~-21 spruce_slab
setblock ~14 ~18 ~17 smooth_quartz
setblock ~14 ~19 ~17 glass_pane[north=false,south=true,west=false,east=true]
setblock ~14 ~20 ~17 spruce_slab
setblock ~-22 ~18 ~-3 smooth_quartz
setblock ~-22 ~19 ~-3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-22 ~20 ~-3 spruce_slab
setblock ~-22 ~18 ~6 smooth_quartz
setblock ~-22 ~19 ~6 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-22 ~20 ~6 spruce_slab
setblock ~-5 ~18 ~22 smooth_quartz
setblock ~-5 ~19 ~22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-5 ~20 ~22 spruce_slab
setblock ~9 ~18 ~21 smooth_quartz
setblock ~9 ~19 ~21 glass_pane[north=true,south=false,west=true,east=false]
setblock ~9 ~20 ~21 spruce_slab
setblock ~18 ~18 ~-13 smooth_quartz
setblock ~18 ~19 ~-13 glass_pane[north=true,south=false,west=false,east=true]
setblock ~18 ~20 ~-13 spruce_slab
setblock ~-11 ~18 ~-19 smooth_quartz
setblock ~-11 ~19 ~-19 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-11 ~20 ~-19 spruce_slab
setblock ~-10 ~18 ~-20 smooth_quartz
setblock ~-10 ~19 ~-20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-10 ~20 ~-20 spruce_slab
setblock ~18 ~18 ~14 smooth_quartz
setblock ~18 ~19 ~14 glass_pane[north=true,south=false,west=true,east=false]
setblock ~18 ~20 ~14 spruce_slab
setblock ~8 ~18 ~-21 smooth_quartz
setblock ~8 ~19 ~-21 glass_pane[north=false,south=false,west=true,east=true]
setblock ~8 ~20 ~-21 spruce_slab
setblock ~22 ~18 ~-4 smooth_quartz
setblock ~22 ~19 ~-4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~22 ~20 ~-4 spruce_slab
setblock ~-21 ~18 ~7 smooth_quartz
setblock ~-21 ~19 ~7 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-21 ~20 ~7 spruce_slab
setblock ~22 ~18 ~5 smooth_quartz
setblock ~22 ~19 ~5 glass_pane[north=true,south=true,west=false,east=false]
setblock ~22 ~20 ~5 spruce_slab
setblock ~19 ~18 ~-12 smooth_quartz
setblock ~19 ~19 ~-12 glass_pane[north=true,south=true,west=false,east=false]
setblock ~19 ~20 ~-12 spruce_slab
setblock ~-12 ~18 ~19 smooth_quartz
setblock ~-12 ~19 ~19 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-12 ~20 ~19 spruce_slab
setblock ~-7 ~18 ~-22 smooth_quartz
setblock ~-7 ~19 ~-22 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-7 ~20 ~-22 spruce_slab
setblock ~-11 ~18 ~20 smooth_quartz
setblock ~-11 ~19 ~20 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-11 ~20 ~20 spruce_slab
setblock ~-17 ~18 ~-14 smooth_quartz
setblock ~-17 ~19 ~-14 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-17 ~20 ~-14 spruce_slab
setblock ~-15 ~18 ~-17 smooth_quartz
setblock ~-15 ~19 ~-17 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-15 ~20 ~-17 spruce_slab
setblock ~15 ~18 ~-16 smooth_quartz
setblock ~15 ~19 ~-16 glass_pane[north=true,south=false,west=false,east=true]
setblock ~15 ~20 ~-16 spruce_slab
setblock ~-5 ~18 ~-22 smooth_quartz
setblock ~-5 ~19 ~-22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-5 ~20 ~-22 spruce_slab
setblock ~-21 ~18 ~-9 smooth_quartz
setblock ~-21 ~19 ~-9 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-21 ~20 ~-9 spruce_slab
setblock ~-19 ~18 ~-12 smooth_quartz
setblock ~-19 ~19 ~-12 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-19 ~20 ~-12 spruce_slab
setblock ~-9 ~18 ~20 smooth_quartz
setblock ~-9 ~19 ~20 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-9 ~20 ~20 spruce_slab
setblock ~22 ~18 ~-2 smooth_quartz
setblock ~22 ~19 ~-2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~22 ~20 ~-2 spruce_slab
setblock ~22 ~18 ~-1 smooth_quartz
setblock ~22 ~19 ~-1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~22 ~20 ~-1 spruce_slab
setblock ~9 ~18 ~-20 smooth_quartz
setblock ~9 ~19 ~-20 glass_pane[north=true,south=false,west=false,east=true]
setblock ~9 ~20 ~-20 spruce_slab
setblock ~-21 ~18 ~9 smooth_quartz
setblock ~-21 ~19 ~9 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-21 ~20 ~9 spruce_slab
setblock ~20 ~18 ~10 smooth_quartz
setblock ~20 ~19 ~10 glass_pane[north=true,south=true,west=false,east=false]
setblock ~20 ~20 ~10 spruce_slab
setblock ~22 ~18 ~7 smooth_quartz
setblock ~22 ~19 ~7 glass_pane[north=true,south=false,west=true,east=false]
setblock ~22 ~20 ~7 spruce_slab
setblock ~-20 ~18 ~-11 smooth_quartz
setblock ~-20 ~19 ~-11 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-20 ~20 ~-11 spruce_slab
setblock ~-22 ~18 ~1 smooth_quartz
setblock ~-22 ~19 ~1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-22 ~20 ~1 spruce_slab
setblock ~-21 ~18 ~-7 smooth_quartz
setblock ~-21 ~19 ~-7 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-21 ~20 ~-7 spruce_slab
setblock ~2 ~18 ~22 smooth_quartz
setblock ~2 ~19 ~22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~2 ~20 ~22 spruce_slab
setblock ~-16 ~18 ~16 smooth_quartz
setblock ~-16 ~19 ~16 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-16 ~20 ~16 spruce_slab
setblock ~22 ~18 ~0 smooth_quartz
setblock ~22 ~19 ~0 glass_pane[north=true,south=true,west=false,east=false]
setblock ~22 ~20 ~0 spruce_slab
setblock ~10 ~18 ~-20 smooth_quartz
setblock ~10 ~19 ~-20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~10 ~20 ~-20 spruce_slab
setblock ~17 ~18 ~-14 smooth_quartz
setblock ~17 ~19 ~-14 glass_pane[north=true,south=false,west=false,east=true]
setblock ~17 ~20 ~-14 spruce_slab
setblock ~6 ~18 ~22 smooth_quartz
setblock ~6 ~19 ~22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~6 ~20 ~22 spruce_slab
setblock ~13 ~18 ~-18 smooth_quartz
setblock ~13 ~19 ~-18 glass_pane[north=true,south=false,west=false,east=true]
setblock ~13 ~20 ~-18 spruce_slab
setblock ~-22 ~18 ~-6 smooth_quartz
setblock ~-22 ~19 ~-6 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-22 ~20 ~-6 spruce_slab
setblock ~-20 ~18 ~-9 smooth_quartz
setblock ~-20 ~19 ~-9 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-20 ~20 ~-9 spruce_slab
setblock ~4 ~18 ~22 smooth_quartz
setblock ~4 ~19 ~22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~4 ~20 ~22 spruce_slab
setblock ~1 ~18 ~22 smooth_quartz
setblock ~1 ~19 ~22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~1 ~20 ~22 spruce_slab
setblock ~-22 ~18 ~3 smooth_quartz
setblock ~-22 ~19 ~3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-22 ~20 ~3 spruce_slab
setblock ~-13 ~18 ~-19 smooth_quartz
setblock ~-13 ~19 ~-19 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-13 ~20 ~-19 spruce_slab
setblock ~19 ~18 ~13 smooth_quartz
setblock ~19 ~19 ~13 glass_pane[north=true,south=false,west=true,east=false]
setblock ~19 ~20 ~13 spruce_slab
setblock ~-20 ~18 ~9 smooth_quartz
setblock ~-20 ~19 ~9 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-20 ~20 ~9 spruce_slab
setblock ~13 ~18 ~18 smooth_quartz
setblock ~13 ~19 ~18 glass_pane[north=false,south=true,west=false,east=true]
setblock ~13 ~20 ~18 spruce_slab
setblock ~22 ~18 ~-7 smooth_quartz
setblock ~22 ~19 ~-7 glass_pane[north=false,south=true,west=true,east=false]
setblock ~22 ~20 ~-7 spruce_slab
setblock ~-7 ~18 ~21 smooth_quartz
setblock ~-7 ~19 ~21 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-7 ~20 ~21 spruce_slab
setblock ~22 ~18 ~2 smooth_quartz
setblock ~22 ~19 ~2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~22 ~20 ~2 spruce_slab
setblock ~-15 ~18 ~17 smooth_quartz
setblock ~-15 ~19 ~17 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-15 ~20 ~17 spruce_slab
setblock ~-14 ~18 ~-18 smooth_quartz
setblock ~-14 ~19 ~-18 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-14 ~20 ~-18 spruce_slab
setblock ~11 ~18 ~-19 smooth_quartz
setblock ~11 ~19 ~-19 glass_pane[north=true,south=false,west=false,east=true]
setblock ~11 ~20 ~-19 spruce_slab
setblock ~2 ~18 ~-22 smooth_quartz
setblock ~2 ~19 ~-22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~2 ~20 ~-22 spruce_slab
setblock ~12 ~18 ~19 smooth_quartz
setblock ~12 ~19 ~19 glass_pane[north=false,south=false,west=true,east=true]
setblock ~12 ~20 ~19 spruce_slab
setblock ~-19 ~18 ~13 smooth_quartz
setblock ~-19 ~19 ~13 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-19 ~20 ~13 spruce_slab
setblock ~-22 ~18 ~-4 smooth_quartz
setblock ~-22 ~19 ~-4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-22 ~20 ~-4 spruce_slab
setblock ~6 ~18 ~-22 smooth_quartz
setblock ~6 ~19 ~-22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~6 ~20 ~-22 spruce_slab
setblock ~-22 ~18 ~5 smooth_quartz
setblock ~-22 ~19 ~5 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-22 ~20 ~5 spruce_slab
setblock ~-18 ~18 ~-13 smooth_quartz
setblock ~-18 ~19 ~-13 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-18 ~20 ~-13 spruce_slab
setblock ~-16 ~18 ~-16 smooth_quartz
setblock ~-16 ~19 ~-16 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-16 ~20 ~-16 spruce_slab
setblock ~18 ~18 ~-14 smooth_quartz
setblock ~18 ~19 ~-14 glass_pane[north=false,south=true,west=true,east=false]
setblock ~18 ~20 ~-14 spruce_slab
setblock ~-11 ~18 ~-20 smooth_quartz
setblock ~-11 ~19 ~-20 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-11 ~20 ~-20 spruce_slab
setblock ~20 ~18 ~-11 smooth_quartz
setblock ~20 ~19 ~-11 glass_pane[north=false,south=true,west=true,east=false]
setblock ~20 ~20 ~-11 spruce_slab
setblock ~11 ~18 ~20 smooth_quartz
setblock ~11 ~19 ~20 glass_pane[north=true,south=false,west=true,east=false]
setblock ~11 ~20 ~20 spruce_slab
setblock ~16 ~18 ~16 smooth_quartz
setblock ~16 ~19 ~16 glass_pane[north=true,south=false,west=true,east=false]
setblock ~16 ~20 ~16 spruce_slab
setblock ~-18 ~18 ~14 smooth_quartz
setblock ~-18 ~19 ~14 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-18 ~20 ~14 spruce_slab
setblock ~14 ~18 ~-18 smooth_quartz
setblock ~14 ~19 ~-18 glass_pane[north=false,south=true,west=true,east=false]
setblock ~14 ~20 ~-18 spruce_slab
setblock ~22 ~18 ~-5 smooth_quartz
setblock ~22 ~19 ~-5 glass_pane[north=true,south=true,west=false,east=false]
setblock ~22 ~20 ~-5 spruce_slab
setblock ~22 ~18 ~4 smooth_quartz
setblock ~22 ~19 ~4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~22 ~20 ~4 spruce_slab
setblock ~-8 ~18 ~-21 smooth_quartz
setblock ~-8 ~19 ~-21 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-8 ~20 ~-21 spruce_slab
setblock ~-1 ~18 ~22 smooth_quartz
setblock ~-1 ~19 ~22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-1 ~20 ~22 spruce_slab
setblock ~-2 ~18 ~22 smooth_quartz
setblock ~-2 ~19 ~22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-2 ~20 ~22 spruce_slab
setblock ~14 ~18 ~18 smooth_quartz
setblock ~14 ~19 ~18 glass_pane[north=true,south=false,west=true,east=false]
setblock ~14 ~20 ~18 spruce_slab
setblock ~-11 ~18 ~19 smooth_quartz
setblock ~-11 ~19 ~19 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-11 ~20 ~19 spruce_slab
setblock ~-22 ~18 ~-1 smooth_quartz
setblock ~-22 ~19 ~-1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-22 ~20 ~-1 spruce_slab
setblock ~-22 ~18 ~-2 smooth_quartz
setblock ~-22 ~19 ~-2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-22 ~20 ~-2 spruce_slab
setblock ~7 ~18 ~-21 smooth_quartz
setblock ~7 ~19 ~-21 glass_pane[north=true,south=false,west=false,east=true]
setblock ~7 ~20 ~-21 spruce_slab
setblock ~15 ~18 ~-17 smooth_quartz
setblock ~15 ~19 ~-17 glass_pane[north=false,south=true,west=true,east=false]
setblock ~15 ~20 ~-17 spruce_slab
setblock ~-22 ~18 ~7 smooth_quartz
setblock ~-22 ~19 ~7 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-22 ~20 ~7 spruce_slab
setblock ~20 ~18 ~-9 smooth_quartz
setblock ~20 ~19 ~-9 glass_pane[north=true,south=false,west=false,east=true]
setblock ~20 ~20 ~-9 spruce_slab
setblock ~0 ~18 ~22 smooth_quartz
setblock ~0 ~19 ~22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~0 ~20 ~22 spruce_slab
setblock ~-17 ~18 ~15 smooth_quartz
setblock ~-17 ~19 ~15 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-17 ~20 ~15 spruce_slab
setblock ~22 ~18 ~-3 smooth_quartz
setblock ~22 ~19 ~-3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~22 ~20 ~-3 spruce_slab
setblock ~9 ~18 ~-21 smooth_quartz
setblock ~9 ~19 ~-21 glass_pane[north=false,south=true,west=true,east=false]
setblock ~9 ~20 ~-21 spruce_slab
setblock ~20 ~18 ~9 smooth_quartz
setblock ~20 ~19 ~9 glass_pane[north=false,south=true,west=false,east=true]
setblock ~20 ~20 ~9 spruce_slab
setblock ~22 ~18 ~6 smooth_quartz
setblock ~22 ~19 ~6 glass_pane[north=true,south=true,west=false,east=false]
setblock ~22 ~20 ~6 spruce_slab
setblock ~21 ~18 ~8 smooth_quartz
setblock ~21 ~19 ~8 glass_pane[north=true,south=true,west=false,east=false]
setblock ~21 ~20 ~8 spruce_slab
setblock ~-10 ~18 ~20 smooth_quartz
setblock ~-10 ~19 ~20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-10 ~20 ~20 spruce_slab
setblock ~-22 ~18 ~0 smooth_quartz
setblock ~-22 ~19 ~0 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-22 ~20 ~0 spruce_slab
setblock ~16 ~18 ~-16 smooth_quartz
setblock ~16 ~19 ~-16 glass_pane[north=false,south=true,west=true,east=false]
setblock ~16 ~20 ~-16 spruce_slab
setblock ~-2 ~18 ~-22 smooth_quartz
setblock ~-2 ~19 ~-22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-2 ~20 ~-22 spruce_slab
setblock ~-1 ~18 ~-22 smooth_quartz
setblock ~-1 ~19 ~-22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-1 ~20 ~-22 spruce_slab
setblock ~21 ~18 ~-8 smooth_quartz
setblock ~21 ~19 ~-8 glass_pane[north=true,south=true,west=false,east=false]
setblock ~21 ~20 ~-8 spruce_slab
setblock ~-9 ~18 ~21 smooth_quartz
setblock ~-9 ~19 ~21 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-9 ~20 ~21 spruce_slab
setblock ~17 ~18 ~-15 smooth_quartz
setblock ~17 ~19 ~-15 glass_pane[north=false,south=true,west=true,east=false]
setblock ~17 ~20 ~-15 spruce_slab
setblock ~0 ~18 ~-22 smooth_quartz
setblock ~0 ~19 ~-22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~0 ~20 ~-22 spruce_slab
setblock ~20 ~18 ~11 smooth_quartz
setblock ~20 ~19 ~11 glass_pane[north=true,south=false,west=true,east=false]
setblock ~20 ~20 ~11 spruce_slab
setblock ~13 ~18 ~-19 smooth_quartz
setblock ~13 ~19 ~-19 glass_pane[north=false,south=true,west=true,east=false]
setblock ~13 ~20 ~-19 spruce_slab
setblock ~-22 ~18 ~-7 smooth_quartz
setblock ~-22 ~19 ~-7 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-22 ~20 ~-7 spruce_slab
setblock ~-20 ~18 ~-10 smooth_quartz
setblock ~-20 ~19 ~-10 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-20 ~20 ~-10 spruce_slab
setblock ~-22 ~18 ~2 smooth_quartz
setblock ~-22 ~19 ~2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-22 ~20 ~2 spruce_slab
setblock ~17 ~18 ~15 smooth_quartz
setblock ~17 ~19 ~15 glass_pane[north=true,south=false,west=true,east=false]
setblock ~17 ~20 ~15 spruce_slab
setblock ~19 ~18 ~12 smooth_quartz
setblock ~19 ~19 ~12 glass_pane[north=true,south=true,west=false,east=false]
setblock ~19 ~20 ~12 spruce_slab
setblock ~5 ~18 ~22 smooth_quartz
setblock ~5 ~19 ~22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~5 ~20 ~22 spruce_slab
setblock ~8 ~18 ~21 smooth_quartz
setblock ~8 ~19 ~21 glass_pane[north=false,south=false,west=true,east=true]
setblock ~8 ~20 ~21 spruce_slab
setblock ~-6 ~18 ~22 smooth_quartz
setblock ~-6 ~19 ~22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-6 ~20 ~22 spruce_slab
setblock ~9 ~18 ~20 smooth_quartz
setblock ~9 ~19 ~20 glass_pane[north=false,south=true,west=false,east=true]
setblock ~9 ~20 ~20 spruce_slab
setblock ~-14 ~18 ~18 smooth_quartz
setblock ~-14 ~19 ~18 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-14 ~20 ~18 spruce_slab
setblock ~-20 ~18 ~11 smooth_quartz
setblock ~-20 ~19 ~11 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-20 ~20 ~11 spruce_slab
setblock ~4 ~18 ~-22 smooth_quartz
setblock ~4 ~19 ~-22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~4 ~20 ~-22 spruce_slab
setblock ~22 ~18 ~1 smooth_quartz
setblock ~22 ~19 ~1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~22 ~20 ~1 spruce_slab
setblock ~-15 ~18 ~16 smooth_quartz
setblock ~-15 ~19 ~16 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-15 ~20 ~16 spruce_slab
setblock ~15 ~18 ~17 smooth_quartz
setblock ~15 ~19 ~17 glass_pane[north=true,south=false,west=true,east=false]
setblock ~15 ~20 ~17 spruce_slab
setblock ~18 ~18 ~13 smooth_quartz
setblock ~18 ~19 ~13 glass_pane[north=false,south=true,west=false,east=true]
setblock ~18 ~20 ~13 spruce_slab
setblock ~7 ~18 ~22 smooth_quartz
setblock ~7 ~19 ~22 glass_pane[north=true,south=false,west=true,east=false]
setblock ~7 ~20 ~22 spruce_slab
setblock ~-4 ~18 ~22 smooth_quartz
setblock ~-4 ~19 ~22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-4 ~20 ~22 spruce_slab
setblock ~-13 ~18 ~19 smooth_quartz
setblock ~-13 ~19 ~19 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-13 ~20 ~19 spruce_slab
setblock ~19 ~18 ~-13 smooth_quartz
setblock ~19 ~19 ~-13 glass_pane[north=false,south=true,west=true,east=false]
setblock ~19 ~20 ~-13 spruce_slab
setblock ~-19 ~18 ~12 smooth_quartz
setblock ~-19 ~19 ~12 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-19 ~20 ~12 spruce_slab
setblock ~-22 ~18 ~-5 smooth_quartz
setblock ~-22 ~19 ~-5 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-22 ~20 ~-5 spruce_slab
setblock ~-9 ~18 ~-20 smooth_quartz
setblock ~-9 ~19 ~-20 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-9 ~20 ~-20 spruce_slab
setblock ~-18 ~18 ~-14 smooth_quartz
setblock ~-18 ~19 ~-14 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-18 ~20 ~-14 spruce_slab
setblock ~-17 ~18 ~-15 smooth_quartz
setblock ~-17 ~19 ~-15 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-17 ~20 ~-15 spruce_slab
setblock ~-12 ~18 ~-19 smooth_quartz
setblock ~-12 ~19 ~-19 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-12 ~20 ~-19 spruce_slab
setblock ~11 ~18 ~19 smooth_quartz
setblock ~11 ~19 ~19 glass_pane[north=false,south=true,west=false,east=true]
setblock ~11 ~20 ~19 spruce_slab
setblock ~-6 ~18 ~-22 smooth_quartz
setblock ~-6 ~19 ~-22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-6 ~20 ~-22 spruce_slab
setblock ~5 ~18 ~-22 smooth_quartz
setblock ~5 ~19 ~-22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~5 ~20 ~-22 spruce_slab
setblock ~22 ~18 ~-6 smooth_quartz
setblock ~22 ~19 ~-6 glass_pane[north=true,south=true,west=false,east=false]
setblock ~22 ~20 ~-6 spruce_slab
setblock ~-19 ~18 ~-13 smooth_quartz
setblock ~-19 ~19 ~-13 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-19 ~20 ~-13 spruce_slab
setblock ~-14 ~18 ~-17 smooth_quartz
setblock ~-14 ~19 ~-17 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-14 ~20 ~-17 spruce_slab
setblock ~-21 ~18 ~8 smooth_quartz
setblock ~-21 ~19 ~8 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-21 ~20 ~8 spruce_slab
setblock ~19 ~18 ~-11 smooth_quartz
setblock ~19 ~19 ~-11 glass_pane[north=true,south=false,west=false,east=true]
setblock ~19 ~20 ~-11 spruce_slab
setblock ~-7 ~18 ~-21 smooth_quartz
setblock ~-7 ~19 ~-21 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-7 ~20 ~-21 spruce_slab
setblock ~-4 ~18 ~-22 smooth_quartz
setblock ~-4 ~19 ~-22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-4 ~20 ~-22 spruce_slab
setblock ~7 ~18 ~-22 smooth_quartz
setblock ~7 ~19 ~-22 glass_pane[north=false,south=true,west=true,east=false]
setblock ~7 ~20 ~-22 spruce_slab
setblock ~-16 ~18 ~-15 smooth_quartz
setblock ~-16 ~19 ~-15 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-16 ~20 ~-15 spruce_slab
setblock ~-15 ~18 ~-16 smooth_quartz
setblock ~-15 ~19 ~-16 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-15 ~20 ~-16 spruce_slab
setblock ~20 ~18 ~-10 smooth_quartz
setblock ~20 ~19 ~-10 glass_pane[north=true,south=true,west=false,east=false]
setblock ~20 ~20 ~-10 spruce_slab
setblock ~-3 ~18 ~22 smooth_quartz
setblock ~-3 ~19 ~22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-3 ~20 ~22 spruce_slab
setblock ~14 ~18 ~-17 smooth_quartz
setblock ~14 ~19 ~-17 glass_pane[north=true,south=false,west=false,east=true]
setblock ~14 ~20 ~-17 spruce_slab
setblock ~-17 ~18 ~14 smooth_quartz
setblock ~-17 ~19 ~14 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-17 ~20 ~14 spruce_slab
setblock ~-21 ~18 ~-8 smooth_quartz
setblock ~-21 ~19 ~-8 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-21 ~20 ~-8 spruce_slab
setblock ~-19 ~18 ~-11 smooth_quartz
setblock ~-19 ~19 ~-11 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-19 ~20 ~-11 spruce_slab
setblock ~21 ~18 ~7 smooth_quartz
setblock ~21 ~19 ~7 glass_pane[north=false,south=true,west=false,east=true]
setblock ~21 ~20 ~7 spruce_slab
fill ~-9 ~26 ~-47 ~9 ~26 ~-47 spruce_planks
fill ~-13 ~26 ~-46 ~13 ~26 ~-46 spruce_planks
fill ~-16 ~26 ~-45 ~16 ~26 ~-45 spruce_planks
fill ~-19 ~26 ~-44 ~19 ~26 ~-44 spruce_planks
fill ~-21 ~26 ~-43 ~21 ~26 ~-43 spruce_planks
fill ~-23 ~26 ~-42 ~23 ~26 ~-42 spruce_planks
fill ~-24 ~26 ~-41 ~24 ~26 ~-41 spruce_planks
fill ~-26 ~26 ~-40 ~26 ~26 ~-40 spruce_planks
fill ~-27 ~26 ~-39 ~27 ~26 ~-39 spruce_planks
fill ~-29 ~26 ~-38 ~29 ~26 ~-38 spruce_planks
fill ~-30 ~26 ~-37 ~30 ~26 ~-37 spruce_planks
fill ~-31 ~26 ~-36 ~31 ~26 ~-36 spruce_planks
fill ~-32 ~26 ~-35 ~32 ~26 ~-35 spruce_planks
fill ~-33 ~26 ~-34 ~33 ~26 ~-34 spruce_planks
fill ~-34 ~26 ~-33 ~34 ~26 ~-33 spruce_planks
fill ~-35 ~26 ~-32 ~35 ~26 ~-32 spruce_planks
fill ~-36 ~26 ~-31 ~36 ~26 ~-31 spruce_planks
fill ~-37 ~26 ~-30 ~37 ~26 ~-30 spruce_planks
fill ~-38 ~26 ~-29 ~38 ~26 ~-29 spruce_planks
fill ~-38 ~26 ~-28 ~38 ~26 ~-28 spruce_planks
fill ~-39 ~26 ~-27 ~39 ~26 ~-27 spruce_planks
fill ~-40 ~26 ~-26 ~40 ~26 ~-26 spruce_planks
fill ~-40 ~26 ~-25 ~40 ~26 ~-25 spruce_planks
fill ~-41 ~26 ~-24 ~41 ~26 ~-24 spruce_planks
fill ~-42 ~26 ~-23 ~-7 ~26 ~-23 spruce_planks
fill ~7 ~26 ~-23 ~42 ~26 ~-23 spruce_planks
fill ~-42 ~26 ~-22 ~-10 ~26 ~-22 spruce_planks
fill ~10 ~26 ~-22 ~42 ~26 ~-22 spruce_planks
fill ~-43 ~26 ~-21 ~-12 ~26 ~-21 spruce_planks
fill ~12 ~26 ~-21 ~43 ~26 ~-21 spruce_planks
fill ~-43 ~26 ~-20 ~-14 ~26 ~-20 spruce_planks
fill ~14 ~26 ~-20 ~43 ~26 ~-20 spruce_planks
fill ~-44 ~26 ~-19 ~-15 ~26 ~-19 spruce_planks
fill ~15 ~26 ~-19 ~44 ~26 ~-19 spruce_planks
fill ~-44 ~26 ~-18 ~-16 ~26 ~-18 spruce_planks
fill ~16 ~26 ~-18 ~44 ~26 ~-18 spruce_planks
fill ~-44 ~26 ~-17 ~-17 ~26 ~-17 spruce_planks
fill ~17 ~26 ~-17 ~44 ~26 ~-17 spruce_planks
fill ~-45 ~26 ~-16 ~-18 ~26 ~-16 spruce_planks
fill ~18 ~26 ~-16 ~45 ~26 ~-16 spruce_planks
fill ~-45 ~26 ~-15 ~-19 ~26 ~-15 spruce_planks
fill ~19 ~26 ~-15 ~45 ~26 ~-15 spruce_planks
fill ~-45 ~26 ~-14 ~-20 ~26 ~-14 spruce_planks
fill ~20 ~26 ~-14 ~45 ~26 ~-14 spruce_planks
fill ~-46 ~26 ~-13 ~-21 ~26 ~-13 spruce_planks
fill ~21 ~26 ~-13 ~46 ~26 ~-13 spruce_planks
fill ~-46 ~26 ~-12 ~-21 ~26 ~-12 spruce_planks
fill ~21 ~26 ~-12 ~46 ~26 ~-12 spruce_planks
fill ~-46 ~26 ~-11 ~-22 ~26 ~-11 spruce_planks
fill ~22 ~26 ~-11 ~46 ~26 ~-11 spruce_planks
fill ~-46 ~26 ~-10 ~-22 ~26 ~-10 spruce_planks
fill ~22 ~26 ~-10 ~46 ~26 ~-10 spruce_planks
fill ~-47 ~26 ~-9 ~-23 ~26 ~-9 spruce_planks
fill ~23 ~26 ~-9 ~47 ~26 ~-9 spruce_planks
fill ~-47 ~26 ~-8 ~-23 ~26 ~-8 spruce_planks
fill ~23 ~26 ~-8 ~47 ~26 ~-8 spruce_planks
fill ~-47 ~26 ~-7 ~-23 ~26 ~-7 spruce_planks
fill ~23 ~26 ~-7 ~47 ~26 ~-7 spruce_planks
fill ~-47 ~26 ~-6 ~-24 ~26 ~-6 spruce_planks
fill ~24 ~26 ~-6 ~47 ~26 ~-6 spruce_planks
fill ~-47 ~26 ~-5 ~-24 ~26 ~-5 spruce_planks
fill ~24 ~26 ~-5 ~47 ~26 ~-5 spruce_planks
fill ~-47 ~26 ~-4 ~-24 ~26 ~-4 spruce_planks
fill ~24 ~26 ~-4 ~47 ~26 ~-4 spruce_planks
fill ~-47 ~26 ~-3 ~-24 ~26 ~-3 spruce_planks
fill ~24 ~26 ~-3 ~47 ~26 ~-3 spruce_planks
fill ~-47 ~26 ~-2 ~-24 ~26 ~-2 spruce_planks
fill ~24 ~26 ~-2 ~47 ~26 ~-2 spruce_planks
fill ~-47 ~26 ~-1 ~-24 ~26 ~-1 spruce_planks
fill ~24 ~26 ~-1 ~47 ~26 ~-1 spruce_planks
fill ~-47 ~26 ~0 ~-24 ~26 ~0 spruce_planks
fill ~24 ~26 ~0 ~47 ~26 ~0 spruce_planks
fill ~-47 ~26 ~1 ~-24 ~26 ~1 spruce_planks
fill ~24 ~26 ~1 ~47 ~26 ~1 spruce_planks
fill ~-47 ~26 ~2 ~-24 ~26 ~2 spruce_planks
fill ~24 ~26 ~2 ~47 ~26 ~2 spruce_planks
fill ~-47 ~26 ~3 ~-24 ~26 ~3 spruce_planks
fill ~24 ~26 ~3 ~47 ~26 ~3 spruce_planks
fill ~-47 ~26 ~4 ~-24 ~26 ~4 spruce_planks
fill ~24 ~26 ~4 ~47 ~26 ~4 spruce_planks
fill ~-47 ~26 ~5 ~-24 ~26 ~5 spruce_planks
fill ~24 ~26 ~5 ~47 ~26 ~5 spruce_planks
fill ~-47 ~26 ~6 ~-24 ~26 ~6 spruce_planks
fill ~24 ~26 ~6 ~47 ~26 ~6 spruce_planks
fill ~-47 ~26 ~7 ~-23 ~26 ~7 spruce_planks
fill ~23 ~26 ~7 ~47 ~26 ~7 spruce_planks
fill ~-47 ~26 ~8 ~-23 ~26 ~8 spruce_planks
fill ~23 ~26 ~8 ~47 ~26 ~8 spruce_planks
fill ~-47 ~26 ~9 ~-23 ~26 ~9 spruce_planks
fill ~23 ~26 ~9 ~47 ~26 ~9 spruce_planks
fill ~-46 ~26 ~10 ~-22 ~26 ~10 spruce_planks
fill ~22 ~26 ~10 ~46 ~26 ~10 spruce_planks
fill ~-46 ~26 ~11 ~-22 ~26 ~11 spruce_planks
fill ~22 ~26 ~11 ~46 ~26 ~11 spruce_planks
fill ~-46 ~26 ~12 ~-21 ~26 ~12 spruce_planks
fill ~21 ~26 ~12 ~46 ~26 ~12 spruce_planks
fill ~-46 ~26 ~13 ~-21 ~26 ~13 spruce_planks
fill ~21 ~26 ~13 ~46 ~26 ~13 spruce_planks
fill ~-45 ~26 ~14 ~-20 ~26 ~14 spruce_planks
fill ~20 ~26 ~14 ~45 ~26 ~14 spruce_planks
fill ~-45 ~26 ~15 ~-19 ~26 ~15 spruce_planks
fill ~19 ~26 ~15 ~45 ~26 ~15 spruce_planks
fill ~-45 ~26 ~16 ~-18 ~26 ~16 spruce_planks
fill ~18 ~26 ~16 ~45 ~26 ~16 spruce_planks
fill ~-44 ~26 ~17 ~-17 ~26 ~17 spruce_planks
fill ~17 ~26 ~17 ~44 ~26 ~17 spruce_planks
fill ~-44 ~26 ~18 ~-16 ~26 ~18 spruce_planks
fill ~16 ~26 ~18 ~44 ~26 ~18 spruce_planks
fill ~-44 ~26 ~19 ~-15 ~26 ~19 spruce_planks
fill ~15 ~26 ~19 ~44 ~26 ~19 spruce_planks
fill ~-43 ~26 ~20 ~-14 ~26 ~20 spruce_planks
fill ~14 ~26 ~20 ~43 ~26 ~20 spruce_planks
fill ~-43 ~26 ~21 ~-12 ~26 ~21 spruce_planks
fill ~12 ~26 ~21 ~43 ~26 ~21 spruce_planks
fill ~-42 ~26 ~22 ~-10 ~26 ~22 spruce_planks
fill ~10 ~26 ~22 ~42 ~26 ~22 spruce_planks
fill ~-42 ~26 ~23 ~-7 ~26 ~23 spruce_planks
fill ~7 ~26 ~23 ~42 ~26 ~23 spruce_planks
fill ~-41 ~26 ~24 ~41 ~26 ~24 spruce_planks
fill ~-40 ~26 ~25 ~40 ~26 ~25 spruce_planks
fill ~-40 ~26 ~26 ~40 ~26 ~26 spruce_planks
fill ~-39 ~26 ~27 ~39 ~26 ~27 spruce_planks
fill ~-38 ~26 ~28 ~38 ~26 ~28 spruce_planks
fill ~-38 ~26 ~29 ~38 ~26 ~29 spruce_planks
fill ~-37 ~26 ~30 ~37 ~26 ~30 spruce_planks
fill ~-36 ~26 ~31 ~36 ~26 ~31 spruce_planks
fill ~-35 ~26 ~32 ~35 ~26 ~32 spruce_planks
fill ~-34 ~26 ~33 ~34 ~26 ~33 spruce_planks
fill ~-33 ~26 ~34 ~33 ~26 ~34 spruce_planks
fill ~-32 ~26 ~35 ~32 ~26 ~35 spruce_planks
fill ~-31 ~26 ~36 ~31 ~26 ~36 spruce_planks
fill ~-30 ~26 ~37 ~30 ~26 ~37 spruce_planks
fill ~-29 ~26 ~38 ~29 ~26 ~38 spruce_planks
fill ~-27 ~26 ~39 ~27 ~26 ~39 spruce_planks
fill ~-26 ~26 ~40 ~26 ~26 ~40 spruce_planks
fill ~-24 ~26 ~41 ~24 ~26 ~41 spruce_planks
fill ~-23 ~26 ~42 ~23 ~26 ~42 spruce_planks
fill ~-21 ~26 ~43 ~21 ~26 ~43 spruce_planks
fill ~-19 ~26 ~44 ~19 ~26 ~44 spruce_planks
fill ~-16 ~26 ~45 ~16 ~26 ~45 spruce_planks
fill ~-13 ~26 ~46 ~13 ~26 ~46 spruce_planks
fill ~-9 ~26 ~47 ~9 ~26 ~47 spruce_planks
setblock ~-40 ~26 ~-20 ochre_froglight
setblock ~-40 ~26 ~-15 ochre_froglight
setblock ~-40 ~26 ~-10 ochre_froglight
setblock ~-40 ~26 ~-5 ochre_froglight
setblock ~-40 ~26 ~0 ochre_froglight
setblock ~-40 ~26 ~5 ochre_froglight
setblock ~-40 ~26 ~10 ochre_froglight
setblock ~-40 ~26 ~15 ochre_froglight
setblock ~-40 ~26 ~20 ochre_froglight
setblock ~-35 ~26 ~-25 ochre_froglight
setblock ~-35 ~26 ~-20 ochre_froglight
setblock ~-35 ~26 ~-15 ochre_froglight
setblock ~-35 ~26 ~-10 ochre_froglight
setblock ~-35 ~26 ~-5 ochre_froglight
setblock ~-35 ~26 ~0 ochre_froglight
setblock ~-35 ~26 ~5 ochre_froglight
setblock ~-35 ~26 ~10 ochre_froglight
setblock ~-35 ~26 ~15 ochre_froglight
setblock ~-35 ~26 ~20 ochre_froglight
setblock ~-35 ~26 ~25 ochre_froglight
setblock ~-30 ~26 ~-30 ochre_froglight
setblock ~-30 ~26 ~-25 ochre_froglight
setblock ~-30 ~26 ~-20 ochre_froglight
setblock ~-30 ~26 ~-15 ochre_froglight
setblock ~-30 ~26 ~-10 ochre_froglight
setblock ~-30 ~26 ~-5 ochre_froglight
setblock ~-30 ~26 ~0 ochre_froglight
setblock ~-30 ~26 ~5 ochre_froglight
setblock ~-30 ~26 ~10 ochre_froglight
setblock ~-30 ~26 ~15 ochre_froglight
setblock ~-30 ~26 ~20 ochre_froglight
setblock ~-30 ~26 ~25 ochre_froglight
setblock ~-30 ~26 ~30 ochre_froglight
setblock ~-25 ~26 ~-35 ochre_froglight
setblock ~-25 ~26 ~-30 ochre_froglight
setblock ~-25 ~26 ~-25 ochre_froglight
setblock ~-25 ~26 ~-20 ochre_froglight
setblock ~-25 ~26 ~-15 ochre_froglight
setblock ~-25 ~26 ~-10 ochre_froglight
setblock ~-25 ~26 ~10 ochre_froglight
setblock ~-25 ~26 ~15 ochre_froglight
setblock ~-25 ~26 ~20 ochre_froglight
setblock ~-25 ~26 ~25 ochre_froglight
setblock ~-25 ~26 ~30 ochre_froglight
setblock ~-25 ~26 ~35 ochre_froglight
setblock ~-20 ~26 ~-40 ochre_froglight
setblock ~-20 ~26 ~-35 ochre_froglight
setblock ~-20 ~26 ~-30 ochre_froglight
setblock ~-20 ~26 ~-25 ochre_froglight
setblock ~-20 ~26 ~-20 ochre_froglight
setblock ~-20 ~26 ~20 ochre_froglight
setblock ~-20 ~26 ~25 ochre_froglight
setblock ~-20 ~26 ~30 ochre_froglight
setblock ~-20 ~26 ~35 ochre_froglight
setblock ~-20 ~26 ~40 ochre_froglight
setblock ~-15 ~26 ~-40 ochre_froglight
setblock ~-15 ~26 ~-35 ochre_froglight
setblock ~-15 ~26 ~-30 ochre_froglight
setblock ~-15 ~26 ~-25 ochre_froglight
setblock ~-15 ~26 ~25 ochre_froglight
setblock ~-15 ~26 ~30 ochre_froglight
setblock ~-15 ~26 ~35 ochre_froglight
setblock ~-15 ~26 ~40 ochre_froglight
setblock ~-10 ~26 ~-40 ochre_froglight
setblock ~-10 ~26 ~-35 ochre_froglight
setblock ~-10 ~26 ~-30 ochre_froglight
setblock ~-10 ~26 ~-25 ochre_froglight
setblock ~-10 ~26 ~25 ochre_froglight
setblock ~-10 ~26 ~30 ochre_froglight
setblock ~-10 ~26 ~35 ochre_froglight
setblock ~-10 ~26 ~40 ochre_froglight
setblock ~-5 ~26 ~-40 ochre_froglight
setblock ~-5 ~26 ~-35 ochre_froglight
setblock ~-5 ~26 ~-30 ochre_froglight
setblock ~-5 ~26 ~30 ochre_froglight
setblock ~-5 ~26 ~35 ochre_froglight
setblock ~-5 ~26 ~40 ochre_froglight
setblock ~0 ~26 ~-40 ochre_froglight
setblock ~0 ~26 ~-35 ochre_froglight
setblock ~0 ~26 ~-30 ochre_froglight
setblock ~0 ~26 ~30 ochre_froglight
setblock ~0 ~26 ~35 ochre_froglight
setblock ~0 ~26 ~40 ochre_froglight
setblock ~5 ~26 ~-40 ochre_froglight
setblock ~5 ~26 ~-35 ochre_froglight
setblock ~5 ~26 ~-30 ochre_froglight
setblock ~5 ~26 ~30 ochre_froglight
setblock ~5 ~26 ~35 ochre_froglight
setblock ~5 ~26 ~40 ochre_froglight
setblock ~10 ~26 ~-40 ochre_froglight
setblock ~10 ~26 ~-35 ochre_froglight
setblock ~10 ~26 ~-30 ochre_froglight
setblock ~10 ~26 ~-25 ochre_froglight
setblock ~10 ~26 ~25 ochre_froglight
setblock ~10 ~26 ~30 ochre_froglight
setblock ~10 ~26 ~35 ochre_froglight
setblock ~10 ~26 ~40 ochre_froglight
setblock ~15 ~26 ~-40 ochre_froglight
setblock ~15 ~26 ~-35 ochre_froglight
setblock ~15 ~26 ~-30 ochre_froglight
setblock ~15 ~26 ~-25 ochre_froglight
setblock ~15 ~26 ~25 ochre_froglight
setblock ~15 ~26 ~30 ochre_froglight
setblock ~15 ~26 ~35 ochre_froglight
setblock ~15 ~26 ~40 ochre_froglight
setblock ~20 ~26 ~-40 ochre_froglight
setblock ~20 ~26 ~-35 ochre_froglight
setblock ~20 ~26 ~-30 ochre_froglight
setblock ~20 ~26 ~-25 ochre_froglight
setblock ~20 ~26 ~-20 ochre_froglight
setblock ~20 ~26 ~20 ochre_froglight
setblock ~20 ~26 ~25 ochre_froglight
setblock ~20 ~26 ~30 ochre_froglight
setblock ~20 ~26 ~35 ochre_froglight
setblock ~20 ~26 ~40 ochre_froglight
setblock ~25 ~26 ~-35 ochre_froglight
setblock ~25 ~26 ~-30 ochre_froglight
setblock ~25 ~26 ~-25 ochre_froglight
setblock ~25 ~26 ~-20 ochre_froglight
setblock ~25 ~26 ~-15 ochre_froglight
setblock ~25 ~26 ~-10 ochre_froglight
setblock ~25 ~26 ~10 ochre_froglight
setblock ~25 ~26 ~15 ochre_froglight
setblock ~25 ~26 ~20 ochre_froglight
setblock ~25 ~26 ~25 ochre_froglight
setblock ~25 ~26 ~30 ochre_froglight
setblock ~25 ~26 ~35 ochre_froglight
setblock ~30 ~26 ~-30 ochre_froglight
setblock ~30 ~26 ~-25 ochre_froglight
setblock ~30 ~26 ~-20 ochre_froglight
setblock ~30 ~26 ~-15 ochre_froglight
setblock ~30 ~26 ~-10 ochre_froglight
setblock ~30 ~26 ~-5 ochre_froglight
setblock ~30 ~26 ~0 ochre_froglight
setblock ~30 ~26 ~5 ochre_froglight
setblock ~30 ~26 ~10 ochre_froglight
setblock ~30 ~26 ~15 ochre_froglight
setblock ~30 ~26 ~20 ochre_froglight
setblock ~30 ~26 ~25 ochre_froglight
setblock ~30 ~26 ~30 ochre_froglight
setblock ~35 ~26 ~-25 ochre_froglight
setblock ~35 ~26 ~-20 ochre_froglight
setblock ~35 ~26 ~-15 ochre_froglight
setblock ~35 ~26 ~-10 ochre_froglight
setblock ~35 ~26 ~-5 ochre_froglight
setblock ~35 ~26 ~0 ochre_froglight
setblock ~35 ~26 ~5 ochre_froglight
setblock ~35 ~26 ~10 ochre_froglight
setblock ~35 ~26 ~15 ochre_froglight
setblock ~35 ~26 ~20 ochre_froglight
setblock ~35 ~26 ~25 ochre_froglight
setblock ~40 ~26 ~-20 ochre_froglight
setblock ~40 ~26 ~-15 ochre_froglight
setblock ~40 ~26 ~-10 ochre_froglight
setblock ~40 ~26 ~-5 ochre_froglight
setblock ~40 ~26 ~0 ochre_froglight
setblock ~40 ~26 ~5 ochre_froglight
setblock ~40 ~26 ~10 ochre_froglight
setblock ~40 ~26 ~15 ochre_froglight
setblock ~40 ~26 ~20 ochre_froglight
fill ~-9 ~27 ~-45 ~9 ~27 ~-45 blue_carpet
fill ~-13 ~27 ~-44 ~13 ~27 ~-44 blue_carpet
fill ~-16 ~27 ~-43 ~16 ~27 ~-43 blue_carpet
fill ~-18 ~27 ~-42 ~18 ~27 ~-42 blue_carpet
fill ~-20 ~27 ~-41 ~20 ~27 ~-41 blue_carpet
fill ~-22 ~27 ~-40 ~22 ~27 ~-40 blue_carpet
fill ~-24 ~27 ~-39 ~24 ~27 ~-39 blue_carpet
fill ~-25 ~27 ~-38 ~25 ~27 ~-38 blue_carpet
fill ~-27 ~27 ~-37 ~27 ~27 ~-37 blue_carpet
fill ~-28 ~27 ~-36 ~28 ~27 ~-36 blue_carpet
fill ~-29 ~27 ~-35 ~29 ~27 ~-35 blue_carpet
fill ~-30 ~27 ~-34 ~30 ~27 ~-34 blue_carpet
fill ~-32 ~27 ~-33 ~32 ~27 ~-33 blue_carpet
fill ~-33 ~27 ~-32 ~33 ~27 ~-32 blue_carpet
fill ~-33 ~27 ~-31 ~33 ~27 ~-31 blue_carpet
fill ~-34 ~27 ~-30 ~34 ~27 ~-30 blue_carpet
fill ~-35 ~27 ~-29 ~35 ~27 ~-29 blue_carpet
fill ~-36 ~27 ~-28 ~36 ~27 ~-28 blue_carpet
fill ~-37 ~27 ~-27 ~37 ~27 ~-27 blue_carpet
fill ~-37 ~27 ~-26 ~37 ~27 ~-26 blue_carpet
fill ~-38 ~27 ~-25 ~38 ~27 ~-25 blue_carpet
fill ~-39 ~27 ~-24 ~-7 ~27 ~-24 blue_carpet
fill ~7 ~27 ~-24 ~39 ~27 ~-24 blue_carpet
fill ~-39 ~27 ~-23 ~-10 ~27 ~-23 blue_carpet
fill ~10 ~27 ~-23 ~39 ~27 ~-23 blue_carpet
fill ~-40 ~27 ~-22 ~-12 ~27 ~-22 blue_carpet
fill ~12 ~27 ~-22 ~40 ~27 ~-22 blue_carpet
fill ~-40 ~27 ~-21 ~-14 ~27 ~-21 blue_carpet
fill ~14 ~27 ~-21 ~40 ~27 ~-21 blue_carpet
fill ~-41 ~27 ~-20 ~-15 ~27 ~-20 blue_carpet
fill ~15 ~27 ~-20 ~41 ~27 ~-20 blue_carpet
fill ~-41 ~27 ~-19 ~-17 ~27 ~-19 blue_carpet
fill ~17 ~27 ~-19 ~41 ~27 ~-19 blue_carpet
fill ~-42 ~27 ~-18 ~-18 ~27 ~-18 blue_carpet
fill ~18 ~27 ~-18 ~42 ~27 ~-18 blue_carpet
fill ~-42 ~27 ~-17 ~-19 ~27 ~-17 blue_carpet
fill ~19 ~27 ~-17 ~42 ~27 ~-17 blue_carpet
fill ~-43 ~27 ~-16 ~-20 ~27 ~-16 blue_carpet
fill ~20 ~27 ~-16 ~43 ~27 ~-16 blue_carpet
fill ~-43 ~27 ~-15 ~-20 ~27 ~-15 blue_carpet
fill ~20 ~27 ~-15 ~43 ~27 ~-15 blue_carpet
fill ~-43 ~27 ~-14 ~-21 ~27 ~-14 blue_carpet
fill ~21 ~27 ~-14 ~43 ~27 ~-14 blue_carpet
fill ~-44 ~27 ~-13 ~-22 ~27 ~-13 blue_carpet
fill ~22 ~27 ~-13 ~44 ~27 ~-13 blue_carpet
fill ~-44 ~27 ~-12 ~-22 ~27 ~-12 blue_carpet
fill ~22 ~27 ~-12 ~44 ~27 ~-12 blue_carpet
fill ~-44 ~27 ~-11 ~-23 ~27 ~-11 blue_carpet
fill ~23 ~27 ~-11 ~44 ~27 ~-11 blue_carpet
fill ~-44 ~27 ~-10 ~-23 ~27 ~-10 blue_carpet
fill ~23 ~27 ~-10 ~44 ~27 ~-10 blue_carpet
fill ~-45 ~27 ~-9 ~-24 ~27 ~-9 blue_carpet
fill ~24 ~27 ~-9 ~45 ~27 ~-9 blue_carpet
fill ~-45 ~27 ~-8 ~-24 ~27 ~-8 blue_carpet
fill ~24 ~27 ~-8 ~45 ~27 ~-8 blue_carpet
fill ~-45 ~27 ~-7 ~-24 ~27 ~-7 blue_carpet
fill ~24 ~27 ~-7 ~45 ~27 ~-7 blue_carpet
fill ~-45 ~27 ~-6 ~-25 ~27 ~-6 blue_carpet
fill ~25 ~27 ~-6 ~45 ~27 ~-6 blue_carpet
fill ~-45 ~27 ~-5 ~-25 ~27 ~-5 blue_carpet
fill ~25 ~27 ~-5 ~45 ~27 ~-5 blue_carpet
fill ~-45 ~27 ~-4 ~-25 ~27 ~-4 blue_carpet
fill ~25 ~27 ~-4 ~45 ~27 ~-4 blue_carpet
fill ~-45 ~27 ~-3 ~-25 ~27 ~-3 blue_carpet
fill ~25 ~27 ~-3 ~45 ~27 ~-3 blue_carpet
fill ~-45 ~27 ~-2 ~-25 ~27 ~-2 blue_carpet
fill ~25 ~27 ~-2 ~45 ~27 ~-2 blue_carpet
fill ~-45 ~27 ~-1 ~-25 ~27 ~-1 blue_carpet
fill ~25 ~27 ~-1 ~45 ~27 ~-1 blue_carpet
fill ~-45 ~27 ~0 ~-25 ~27 ~0 blue_carpet
fill ~25 ~27 ~0 ~45 ~27 ~0 blue_carpet
fill ~-45 ~27 ~1 ~-25 ~27 ~1 blue_carpet
fill ~25 ~27 ~1 ~45 ~27 ~1 blue_carpet
fill ~-45 ~27 ~2 ~-25 ~27 ~2 blue_carpet
fill ~25 ~27 ~2 ~45 ~27 ~2 blue_carpet
fill ~-45 ~27 ~3 ~-25 ~27 ~3 blue_carpet
fill ~25 ~27 ~3 ~45 ~27 ~3 blue_carpet
fill ~-45 ~27 ~4 ~-25 ~27 ~4 blue_carpet
fill ~25 ~27 ~4 ~45 ~27 ~4 blue_carpet
fill ~-45 ~27 ~5 ~-25 ~27 ~5 blue_carpet
fill ~25 ~27 ~5 ~45 ~27 ~5 blue_carpet
fill ~-45 ~27 ~6 ~-25 ~27 ~6 blue_carpet
fill ~25 ~27 ~6 ~45 ~27 ~6 blue_carpet
fill ~-45 ~27 ~7 ~-24 ~27 ~7 blue_carpet
fill ~24 ~27 ~7 ~45 ~27 ~7 blue_carpet
fill ~-45 ~27 ~8 ~-24 ~27 ~8 blue_carpet
fill ~24 ~27 ~8 ~45 ~27 ~8 blue_carpet
fill ~-45 ~27 ~9 ~-24 ~27 ~9 blue_carpet
fill ~24 ~27 ~9 ~45 ~27 ~9 blue_carpet
fill ~-44 ~27 ~10 ~-23 ~27 ~10 blue_carpet
fill ~23 ~27 ~10 ~44 ~27 ~10 blue_carpet
fill ~-44 ~27 ~11 ~-23 ~27 ~11 blue_carpet
fill ~23 ~27 ~11 ~44 ~27 ~11 blue_carpet
fill ~-44 ~27 ~12 ~-22 ~27 ~12 blue_carpet
fill ~22 ~27 ~12 ~44 ~27 ~12 blue_carpet
fill ~-44 ~27 ~13 ~-22 ~27 ~13 blue_carpet
fill ~22 ~27 ~13 ~44 ~27 ~13 blue_carpet
fill ~-43 ~27 ~14 ~-21 ~27 ~14 blue_carpet
fill ~21 ~27 ~14 ~43 ~27 ~14 blue_carpet
fill ~-43 ~27 ~15 ~-20 ~27 ~15 blue_carpet
fill ~20 ~27 ~15 ~43 ~27 ~15 blue_carpet
fill ~-43 ~27 ~16 ~-20 ~27 ~16 blue_carpet
fill ~20 ~27 ~16 ~43 ~27 ~16 blue_carpet
fill ~-42 ~27 ~17 ~-19 ~27 ~17 blue_carpet
fill ~19 ~27 ~17 ~42 ~27 ~17 blue_carpet
fill ~-42 ~27 ~18 ~-18 ~27 ~18 blue_carpet
fill ~18 ~27 ~18 ~42 ~27 ~18 blue_carpet
fill ~-41 ~27 ~19 ~-17 ~27 ~19 blue_carpet
fill ~17 ~27 ~19 ~41 ~27 ~19 blue_carpet
fill ~-41 ~27 ~20 ~-15 ~27 ~20 blue_carpet
fill ~15 ~27 ~20 ~41 ~27 ~20 blue_carpet
fill ~-40 ~27 ~21 ~-14 ~27 ~21 blue_carpet
fill ~14 ~27 ~21 ~40 ~27 ~21 blue_carpet
fill ~-40 ~27 ~22 ~-12 ~27 ~22 blue_carpet
fill ~12 ~27 ~22 ~40 ~27 ~22 blue_carpet
fill ~-39 ~27 ~23 ~-10 ~27 ~23 blue_carpet
fill ~10 ~27 ~23 ~39 ~27 ~23 blue_carpet
fill ~-39 ~27 ~24 ~-7 ~27 ~24 blue_carpet
fill ~7 ~27 ~24 ~39 ~27 ~24 blue_carpet
fill ~-38 ~27 ~25 ~38 ~27 ~25 blue_carpet
fill ~-37 ~27 ~26 ~37 ~27 ~26 blue_carpet
fill ~-37 ~27 ~27 ~37 ~27 ~27 blue_carpet
fill ~-36 ~27 ~28 ~36 ~27 ~28 blue_carpet
fill ~-35 ~27 ~29 ~35 ~27 ~29 blue_carpet
fill ~-34 ~27 ~30 ~34 ~27 ~30 blue_carpet
fill ~-33 ~27 ~31 ~33 ~27 ~31 blue_carpet
fill ~-33 ~27 ~32 ~33 ~27 ~32 blue_carpet
fill ~-32 ~27 ~33 ~32 ~27 ~33 blue_carpet
fill ~-30 ~27 ~34 ~30 ~27 ~34 blue_carpet
fill ~-29 ~27 ~35 ~29 ~27 ~35 blue_carpet
fill ~-28 ~27 ~36 ~28 ~27 ~36 blue_carpet
fill ~-27 ~27 ~37 ~27 ~27 ~37 blue_carpet
fill ~-25 ~27 ~38 ~25 ~27 ~38 blue_carpet
fill ~-24 ~27 ~39 ~24 ~27 ~39 blue_carpet
fill ~-22 ~27 ~40 ~22 ~27 ~40 blue_carpet
fill ~-20 ~27 ~41 ~20 ~27 ~41 blue_carpet
fill ~-18 ~27 ~42 ~18 ~27 ~42 blue_carpet
fill ~-16 ~27 ~43 ~16 ~27 ~43 blue_carpet
fill ~-13 ~27 ~44 ~13 ~27 ~44 blue_carpet
fill ~-9 ~27 ~45 ~9 ~27 ~45 blue_carpet
fill ~-7 ~27 ~-27 ~7 ~27 ~-27 cyan_carpet
fill ~-10 ~27 ~-26 ~-8 ~27 ~-26 cyan_carpet
fill ~8 ~27 ~-26 ~10 ~27 ~-26 cyan_carpet
fill ~-12 ~27 ~-25 ~-11 ~27 ~-25 cyan_carpet
fill ~11 ~27 ~-25 ~12 ~27 ~-25 cyan_carpet
fill ~-14 ~27 ~-24 ~-13 ~27 ~-24 cyan_carpet
fill ~13 ~27 ~-24 ~14 ~27 ~-24 cyan_carpet
fill ~-15 ~27 ~-23 ~-15 ~27 ~-23 cyan_carpet
fill ~15 ~27 ~-23 ~15 ~27 ~-23 cyan_carpet
fill ~-17 ~27 ~-22 ~-16 ~27 ~-22 cyan_carpet
fill ~16 ~27 ~-22 ~17 ~27 ~-22 cyan_carpet
fill ~-18 ~27 ~-21 ~-17 ~27 ~-21 cyan_carpet
fill ~17 ~27 ~-21 ~18 ~27 ~-21 cyan_carpet
fill ~-19 ~27 ~-20 ~-19 ~27 ~-20 cyan_carpet
fill ~19 ~27 ~-20 ~19 ~27 ~-20 cyan_carpet
fill ~-20 ~27 ~-19 ~-20 ~27 ~-19 cyan_carpet
fill ~20 ~27 ~-19 ~20 ~27 ~-19 cyan_carpet
fill ~-21 ~27 ~-18 ~-21 ~27 ~-18 cyan_carpet
fill ~21 ~27 ~-18 ~21 ~27 ~-18 cyan_carpet
fill ~-22 ~27 ~-17 ~-21 ~27 ~-17 cyan_carpet
fill ~21 ~27 ~-17 ~22 ~27 ~-17 cyan_carpet
fill ~-22 ~27 ~-16 ~-22 ~27 ~-16 cyan_carpet
fill ~22 ~27 ~-16 ~22 ~27 ~-16 cyan_carpet
fill ~-23 ~27 ~-15 ~-23 ~27 ~-15 cyan_carpet
fill ~23 ~27 ~-15 ~23 ~27 ~-15 cyan_carpet
fill ~-24 ~27 ~-14 ~-24 ~27 ~-14 cyan_carpet
fill ~24 ~27 ~-14 ~24 ~27 ~-14 cyan_carpet
fill ~-24 ~27 ~-13 ~-24 ~27 ~-13 cyan_carpet
fill ~24 ~27 ~-13 ~24 ~27 ~-13 cyan_carpet
fill ~-25 ~27 ~-12 ~-25 ~27 ~-12 cyan_carpet
fill ~25 ~27 ~-12 ~25 ~27 ~-12 cyan_carpet
fill ~-25 ~27 ~-11 ~-25 ~27 ~-11 cyan_carpet
fill ~25 ~27 ~-11 ~25 ~27 ~-11 cyan_carpet
fill ~-26 ~27 ~-10 ~-26 ~27 ~-10 cyan_carpet
fill ~26 ~27 ~-10 ~26 ~27 ~-10 cyan_carpet
fill ~-26 ~27 ~-9 ~-26 ~27 ~-9 cyan_carpet
fill ~26 ~27 ~-9 ~26 ~27 ~-9 cyan_carpet
fill ~-26 ~27 ~-8 ~-26 ~27 ~-8 cyan_carpet
fill ~26 ~27 ~-8 ~26 ~27 ~-8 cyan_carpet
fill ~-27 ~27 ~-7 ~-27 ~27 ~-7 cyan_carpet
fill ~27 ~27 ~-7 ~27 ~27 ~-7 cyan_carpet
fill ~-27 ~27 ~-6 ~-27 ~27 ~-6 cyan_carpet
fill ~27 ~27 ~-6 ~27 ~27 ~-6 cyan_carpet
fill ~-27 ~27 ~-5 ~-27 ~27 ~-5 cyan_carpet
fill ~27 ~27 ~-5 ~27 ~27 ~-5 cyan_carpet
fill ~-27 ~27 ~-4 ~-27 ~27 ~-4 cyan_carpet
fill ~27 ~27 ~-4 ~27 ~27 ~-4 cyan_carpet
fill ~-27 ~27 ~-3 ~-27 ~27 ~-3 cyan_carpet
fill ~27 ~27 ~-3 ~27 ~27 ~-3 cyan_carpet
fill ~-27 ~27 ~-2 ~-27 ~27 ~-2 cyan_carpet
fill ~27 ~27 ~-2 ~27 ~27 ~-2 cyan_carpet
fill ~-27 ~27 ~-1 ~-27 ~27 ~-1 cyan_carpet
fill ~27 ~27 ~-1 ~27 ~27 ~-1 cyan_carpet
fill ~-27 ~27 ~0 ~-27 ~27 ~0 cyan_carpet
fill ~27 ~27 ~0 ~27 ~27 ~0 cyan_carpet
fill ~-27 ~27 ~1 ~-27 ~27 ~1 cyan_carpet
fill ~27 ~27 ~1 ~27 ~27 ~1 cyan_carpet
fill ~-27 ~27 ~2 ~-27 ~27 ~2 cyan_carpet
fill ~27 ~27 ~2 ~27 ~27 ~2 cyan_carpet
fill ~-27 ~27 ~3 ~-27 ~27 ~3 cyan_carpet
fill ~27 ~27 ~3 ~27 ~27 ~3 cyan_carpet
fill ~-27 ~27 ~4 ~-27 ~27 ~4 cyan_carpet
fill ~27 ~27 ~4 ~27 ~27 ~4 cyan_carpet
fill ~-27 ~27 ~5 ~-27 ~27 ~5 cyan_carpet
fill ~27 ~27 ~5 ~27 ~27 ~5 cyan_carpet
fill ~-27 ~27 ~6 ~-27 ~27 ~6 cyan_carpet
fill ~27 ~27 ~6 ~27 ~27 ~6 cyan_carpet
fill ~-27 ~27 ~7 ~-27 ~27 ~7 cyan_carpet
fill ~27 ~27 ~7 ~27 ~27 ~7 cyan_carpet
fill ~-26 ~27 ~8 ~-26 ~27 ~8 cyan_carpet
fill ~26 ~27 ~8 ~26 ~27 ~8 cyan_carpet
fill ~-26 ~27 ~9 ~-26 ~27 ~9 cyan_carpet
fill ~26 ~27 ~9 ~26 ~27 ~9 cyan_carpet
fill ~-26 ~27 ~10 ~-26 ~27 ~10 cyan_carpet
fill ~26 ~27 ~10 ~26 ~27 ~10 cyan_carpet
fill ~-25 ~27 ~11 ~-25 ~27 ~11 cyan_carpet
fill ~25 ~27 ~11 ~25 ~27 ~11 cyan_carpet
fill ~-25 ~27 ~12 ~-25 ~27 ~12 cyan_carpet
fill ~25 ~27 ~12 ~25 ~27 ~12 cyan_carpet
fill ~-24 ~27 ~13 ~-24 ~27 ~13 cyan_carpet
fill ~24 ~27 ~13 ~24 ~27 ~13 cyan_carpet
fill ~-24 ~27 ~14 ~-24 ~27 ~14 cyan_carpet
fill ~24 ~27 ~14 ~24 ~27 ~14 cyan_carpet
fill ~-23 ~27 ~15 ~-23 ~27 ~15 cyan_carpet
fill ~23 ~27 ~15 ~23 ~27 ~15 cyan_carpet
fill ~-22 ~27 ~16 ~-22 ~27 ~16 cyan_carpet
fill ~22 ~27 ~16 ~22 ~27 ~16 cyan_carpet
fill ~-22 ~27 ~17 ~-21 ~27 ~17 cyan_carpet
fill ~21 ~27 ~17 ~22 ~27 ~17 cyan_carpet
fill ~-21 ~27 ~18 ~-21 ~27 ~18 cyan_carpet
fill ~21 ~27 ~18 ~21 ~27 ~18 cyan_carpet
fill ~-20 ~27 ~19 ~-20 ~27 ~19 cyan_carpet
fill ~20 ~27 ~19 ~20 ~27 ~19 cyan_carpet
fill ~-19 ~27 ~20 ~-19 ~27 ~20 cyan_carpet
fill ~19 ~27 ~20 ~19 ~27 ~20 cyan_carpet
fill ~-18 ~27 ~21 ~-17 ~27 ~21 cyan_carpet
fill ~17 ~27 ~21 ~18 ~27 ~21 cyan_carpet
fill ~-17 ~27 ~22 ~-16 ~27 ~22 cyan_carpet
fill ~16 ~27 ~22 ~17 ~27 ~22 cyan_carpet
fill ~-15 ~27 ~23 ~-15 ~27 ~23 cyan_carpet
fill ~15 ~27 ~23 ~15 ~27 ~23 cyan_carpet
fill ~-14 ~27 ~24 ~-13 ~27 ~24 cyan_carpet
fill ~13 ~27 ~24 ~14 ~27 ~24 cyan_carpet
fill ~-12 ~27 ~25 ~-11 ~27 ~25 cyan_carpet
fill ~11 ~27 ~25 ~12 ~27 ~25 cyan_carpet
fill ~-10 ~27 ~26 ~-8 ~27 ~26 cyan_carpet
fill ~8 ~27 ~26 ~10 ~27 ~26 cyan_carpet
fill ~-7 ~27 ~27 ~7 ~27 ~27 cyan_carpet
fill ~-2 ~25 ~-25 ~2 ~26 ~-25 smooth_quartz
fill ~-7 ~25 ~-24 ~7 ~26 ~-24 smooth_quartz
fill ~-10 ~25 ~-23 ~-7 ~26 ~-23 smooth_quartz
fill ~7 ~25 ~-23 ~10 ~26 ~-23 smooth_quartz
fill ~-12 ~25 ~-22 ~-10 ~26 ~-22 smooth_quartz
fill ~10 ~25 ~-22 ~12 ~26 ~-22 smooth_quartz
fill ~-13 ~25 ~-21 ~-12 ~26 ~-21 smooth_quartz
fill ~12 ~25 ~-21 ~13 ~26 ~-21 smooth_quartz
fill ~-15 ~25 ~-20 ~-13 ~26 ~-20 smooth_quartz
fill ~13 ~25 ~-20 ~15 ~26 ~-20 smooth_quartz
fill ~-16 ~25 ~-19 ~-15 ~26 ~-19 smooth_quartz
fill ~15 ~25 ~-19 ~16 ~26 ~-19 smooth_quartz
fill ~-17 ~25 ~-18 ~-16 ~26 ~-18 smooth_quartz
fill ~16 ~25 ~-18 ~17 ~26 ~-18 smooth_quartz
fill ~-18 ~25 ~-17 ~-17 ~26 ~-17 smooth_quartz
fill ~17 ~25 ~-17 ~18 ~26 ~-17 smooth_quartz
fill ~-19 ~25 ~-16 ~-18 ~26 ~-16 smooth_quartz
fill ~18 ~25 ~-16 ~19 ~26 ~-16 smooth_quartz
fill ~-20 ~25 ~-15 ~-19 ~26 ~-15 smooth_quartz
fill ~19 ~25 ~-15 ~20 ~26 ~-15 smooth_quartz
fill ~-20 ~25 ~-14 ~-20 ~26 ~-14 smooth_quartz
fill ~20 ~25 ~-14 ~20 ~26 ~-14 smooth_quartz
fill ~-21 ~25 ~-13 ~-20 ~26 ~-13 smooth_quartz
fill ~20 ~25 ~-13 ~21 ~26 ~-13 smooth_quartz
fill ~-22 ~25 ~-12 ~-21 ~26 ~-12 smooth_quartz
fill ~21 ~25 ~-12 ~22 ~26 ~-12 smooth_quartz
fill ~-22 ~25 ~-11 ~-22 ~26 ~-11 smooth_quartz
fill ~22 ~25 ~-11 ~22 ~26 ~-11 smooth_quartz
fill ~-23 ~25 ~-10 ~-22 ~26 ~-10 smooth_quartz
fill ~22 ~25 ~-10 ~23 ~26 ~-10 smooth_quartz
fill ~-23 ~25 ~-9 ~-23 ~26 ~-9 smooth_quartz
fill ~23 ~25 ~-9 ~23 ~26 ~-9 smooth_quartz
fill ~-23 ~25 ~-8 ~-23 ~26 ~-8 smooth_quartz
fill ~23 ~25 ~-8 ~23 ~26 ~-8 smooth_quartz
fill ~-24 ~25 ~-7 ~-23 ~26 ~-7 smooth_quartz
fill ~23 ~25 ~-7 ~24 ~26 ~-7 smooth_quartz
fill ~-24 ~25 ~-6 ~-24 ~26 ~-6 smooth_quartz
fill ~24 ~25 ~-6 ~24 ~26 ~-6 smooth_quartz
fill ~-24 ~25 ~-5 ~-24 ~26 ~-5 smooth_quartz
fill ~24 ~25 ~-5 ~24 ~26 ~-5 smooth_quartz
fill ~-24 ~25 ~-4 ~-24 ~26 ~-4 smooth_quartz
fill ~24 ~25 ~-4 ~24 ~26 ~-4 smooth_quartz
fill ~-24 ~25 ~-3 ~-24 ~26 ~-3 smooth_quartz
fill ~24 ~25 ~-3 ~24 ~26 ~-3 smooth_quartz
fill ~-25 ~25 ~-2 ~-24 ~26 ~-2 smooth_quartz
fill ~24 ~25 ~-2 ~25 ~26 ~-2 smooth_quartz
fill ~-25 ~25 ~-1 ~-24 ~26 ~-1 smooth_quartz
fill ~24 ~25 ~-1 ~25 ~26 ~-1 smooth_quartz
fill ~-25 ~25 ~0 ~-24 ~26 ~0 smooth_quartz
fill ~24 ~25 ~0 ~25 ~26 ~0 smooth_quartz
fill ~-25 ~25 ~1 ~-24 ~26 ~1 smooth_quartz
fill ~24 ~25 ~1 ~25 ~26 ~1 smooth_quartz
fill ~-25 ~25 ~2 ~-24 ~26 ~2 smooth_quartz
fill ~24 ~25 ~2 ~25 ~26 ~2 smooth_quartz
fill ~-24 ~25 ~3 ~-24 ~26 ~3 smooth_quartz
fill ~24 ~25 ~3 ~24 ~26 ~3 smooth_quartz
fill ~-24 ~25 ~4 ~-24 ~26 ~4 smooth_quartz
fill ~24 ~25 ~4 ~24 ~26 ~4 smooth_quartz
fill ~-24 ~25 ~5 ~-24 ~26 ~5 smooth_quartz
fill ~24 ~25 ~5 ~24 ~26 ~5 smooth_quartz
fill ~-24 ~25 ~6 ~-24 ~26 ~6 smooth_quartz
fill ~24 ~25 ~6 ~24 ~26 ~6 smooth_quartz
fill ~-24 ~25 ~7 ~-23 ~26 ~7 smooth_quartz
fill ~23 ~25 ~7 ~24 ~26 ~7 smooth_quartz
fill ~-23 ~25 ~8 ~-23 ~26 ~8 smooth_quartz
fill ~23 ~25 ~8 ~23 ~26 ~8 smooth_quartz
fill ~-23 ~25 ~9 ~-23 ~26 ~9 smooth_quartz
fill ~23 ~25 ~9 ~23 ~26 ~9 smooth_quartz
fill ~-23 ~25 ~10 ~-22 ~26 ~10 smooth_quartz
fill ~22 ~25 ~10 ~23 ~26 ~10 smooth_quartz
fill ~-22 ~25 ~11 ~-22 ~26 ~11 smooth_quartz
fill ~22 ~25 ~11 ~22 ~26 ~11 smooth_quartz
fill ~-22 ~25 ~12 ~-21 ~26 ~12 smooth_quartz
fill ~21 ~25 ~12 ~22 ~26 ~12 smooth_quartz
fill ~-21 ~25 ~13 ~-20 ~26 ~13 smooth_quartz
fill ~20 ~25 ~13 ~21 ~26 ~13 smooth_quartz
fill ~-20 ~25 ~14 ~-20 ~26 ~14 smooth_quartz
fill ~20 ~25 ~14 ~20 ~26 ~14 smooth_quartz
fill ~-20 ~25 ~15 ~-19 ~26 ~15 smooth_quartz
fill ~19 ~25 ~15 ~20 ~26 ~15 smooth_quartz
fill ~-19 ~25 ~16 ~-18 ~26 ~16 smooth_quartz
fill ~18 ~25 ~16 ~19 ~26 ~16 smooth_quartz
fill ~-18 ~25 ~17 ~-17 ~26 ~17 smooth_quartz
fill ~17 ~25 ~17 ~18 ~26 ~17 smooth_quartz
fill ~-17 ~25 ~18 ~-16 ~26 ~18 smooth_quartz
fill ~16 ~25 ~18 ~17 ~26 ~18 smooth_quartz
fill ~-16 ~25 ~19 ~-15 ~26 ~19 smooth_quartz
fill ~15 ~25 ~19 ~16 ~26 ~19 smooth_quartz
fill ~-15 ~25 ~20 ~-13 ~26 ~20 smooth_quartz
fill ~13 ~25 ~20 ~15 ~26 ~20 smooth_quartz
fill ~-13 ~25 ~21 ~-12 ~26 ~21 smooth_quartz
fill ~12 ~25 ~21 ~13 ~26 ~21 smooth_quartz
fill ~-12 ~25 ~22 ~-10 ~26 ~22 smooth_quartz
fill ~10 ~25 ~22 ~12 ~26 ~22 smooth_quartz
fill ~-10 ~25 ~23 ~-7 ~26 ~23 smooth_quartz
fill ~7 ~25 ~23 ~10 ~26 ~23 smooth_quartz
fill ~-7 ~25 ~24 ~7 ~26 ~24 smooth_quartz
fill ~-2 ~25 ~25 ~2 ~26 ~25 smooth_quartz
fill ~-2 ~25 ~-26 ~2 ~25 ~-26 ochre_froglight
fill ~-7 ~25 ~-25 ~-3 ~25 ~-25 ochre_froglight
fill ~3 ~25 ~-25 ~7 ~25 ~-25 ochre_froglight
fill ~-10 ~25 ~-24 ~-8 ~25 ~-24 ochre_froglight
fill ~8 ~25 ~-24 ~10 ~25 ~-24 ochre_froglight
fill ~-12 ~25 ~-23 ~-11 ~25 ~-23 ochre_froglight
fill ~11 ~25 ~-23 ~12 ~25 ~-23 ochre_froglight
fill ~-14 ~25 ~-22 ~-13 ~25 ~-22 ochre_froglight
fill ~13 ~25 ~-22 ~14 ~25 ~-22 ochre_froglight
fill ~-15 ~25 ~-21 ~-14 ~25 ~-21 ochre_froglight
fill ~14 ~25 ~-21 ~15 ~25 ~-21 ochre_froglight
fill ~-16 ~25 ~-20 ~-16 ~25 ~-20 ochre_froglight
fill ~16 ~25 ~-20 ~16 ~25 ~-20 ochre_froglight
fill ~-17 ~25 ~-19 ~-17 ~25 ~-19 ochre_froglight
fill ~17 ~25 ~-19 ~17 ~25 ~-19 ochre_froglight
fill ~-18 ~25 ~-18 ~-18 ~25 ~-18 ochre_froglight
fill ~18 ~25 ~-18 ~18 ~25 ~-18 ochre_froglight
fill ~-19 ~25 ~-17 ~-19 ~25 ~-17 ochre_froglight
fill ~19 ~25 ~-17 ~19 ~25 ~-17 ochre_froglight
fill ~-20 ~25 ~-16 ~-20 ~25 ~-16 ochre_froglight
fill ~20 ~25 ~-16 ~20 ~25 ~-16 ochre_froglight
fill ~-21 ~25 ~-15 ~-21 ~25 ~-15 ochre_froglight
fill ~21 ~25 ~-15 ~21 ~25 ~-15 ochre_froglight
fill ~-22 ~25 ~-14 ~-21 ~25 ~-14 ochre_froglight
fill ~21 ~25 ~-14 ~22 ~25 ~-14 ochre_froglight
fill ~-22 ~25 ~-13 ~-22 ~25 ~-13 ochre_froglight
fill ~22 ~25 ~-13 ~22 ~25 ~-13 ochre_froglight
fill ~-23 ~25 ~-12 ~-23 ~25 ~-12 ochre_froglight
fill ~23 ~25 ~-12 ~23 ~25 ~-12 ochre_froglight
fill ~-23 ~25 ~-11 ~-23 ~25 ~-11 ochre_froglight
fill ~23 ~25 ~-11 ~23 ~25 ~-11 ochre_froglight
fill ~-24 ~25 ~-10 ~-24 ~25 ~-10 ochre_froglight
fill ~24 ~25 ~-10 ~24 ~25 ~-10 ochre_froglight
fill ~-24 ~25 ~-9 ~-24 ~25 ~-9 ochre_froglight
fill ~24 ~25 ~-9 ~24 ~25 ~-9 ochre_froglight
fill ~-24 ~25 ~-8 ~-24 ~25 ~-8 ochre_froglight
fill ~24 ~25 ~-8 ~24 ~25 ~-8 ochre_froglight
fill ~-25 ~25 ~-7 ~-25 ~25 ~-7 ochre_froglight
fill ~25 ~25 ~-7 ~25 ~25 ~-7 ochre_froglight
fill ~-25 ~25 ~-6 ~-25 ~25 ~-6 ochre_froglight
fill ~25 ~25 ~-6 ~25 ~25 ~-6 ochre_froglight
fill ~-25 ~25 ~-5 ~-25 ~25 ~-5 ochre_froglight
fill ~25 ~25 ~-5 ~25 ~25 ~-5 ochre_froglight
fill ~-25 ~25 ~-4 ~-25 ~25 ~-4 ochre_froglight
fill ~25 ~25 ~-4 ~25 ~25 ~-4 ochre_froglight
fill ~-25 ~25 ~-3 ~-25 ~25 ~-3 ochre_froglight
fill ~25 ~25 ~-3 ~25 ~25 ~-3 ochre_froglight
fill ~-26 ~25 ~-2 ~-26 ~25 ~-2 ochre_froglight
fill ~26 ~25 ~-2 ~26 ~25 ~-2 ochre_froglight
fill ~-26 ~25 ~-1 ~-26 ~25 ~-1 ochre_froglight
fill ~26 ~25 ~-1 ~26 ~25 ~-1 ochre_froglight
fill ~-26 ~25 ~0 ~-26 ~25 ~0 ochre_froglight
fill ~26 ~25 ~0 ~26 ~25 ~0 ochre_froglight
fill ~-26 ~25 ~1 ~-26 ~25 ~1 ochre_froglight
fill ~26 ~25 ~1 ~26 ~25 ~1 ochre_froglight
fill ~-26 ~25 ~2 ~-26 ~25 ~2 ochre_froglight
fill ~26 ~25 ~2 ~26 ~25 ~2 ochre_froglight
fill ~-25 ~25 ~3 ~-25 ~25 ~3 ochre_froglight
fill ~25 ~25 ~3 ~25 ~25 ~3 ochre_froglight
fill ~-25 ~25 ~4 ~-25 ~25 ~4 ochre_froglight
fill ~25 ~25 ~4 ~25 ~25 ~4 ochre_froglight
fill ~-25 ~25 ~5 ~-25 ~25 ~5 ochre_froglight
fill ~25 ~25 ~5 ~25 ~25 ~5 ochre_froglight
fill ~-25 ~25 ~6 ~-25 ~25 ~6 ochre_froglight
fill ~25 ~25 ~6 ~25 ~25 ~6 ochre_froglight
fill ~-25 ~25 ~7 ~-25 ~25 ~7 ochre_froglight
fill ~25 ~25 ~7 ~25 ~25 ~7 ochre_froglight
fill ~-24 ~25 ~8 ~-24 ~25 ~8 ochre_froglight
fill ~24 ~25 ~8 ~24 ~25 ~8 ochre_froglight
fill ~-24 ~25 ~9 ~-24 ~25 ~9 ochre_froglight
fill ~24 ~25 ~9 ~24 ~25 ~9 ochre_froglight
fill ~-24 ~25 ~10 ~-24 ~25 ~10 ochre_froglight
fill ~24 ~25 ~10 ~24 ~25 ~10 ochre_froglight
fill ~-23 ~25 ~11 ~-23 ~25 ~11 ochre_froglight
fill ~23 ~25 ~11 ~23 ~25 ~11 ochre_froglight
fill ~-23 ~25 ~12 ~-23 ~25 ~12 ochre_froglight
fill ~23 ~25 ~12 ~23 ~25 ~12 ochre_froglight
fill ~-22 ~25 ~13 ~-22 ~25 ~13 ochre_froglight
fill ~22 ~25 ~13 ~22 ~25 ~13 ochre_froglight
fill ~-22 ~25 ~14 ~-21 ~25 ~14 ochre_froglight
fill ~21 ~25 ~14 ~22 ~25 ~14 ochre_froglight
fill ~-21 ~25 ~15 ~-21 ~25 ~15 ochre_froglight
fill ~21 ~25 ~15 ~21 ~25 ~15 ochre_froglight
fill ~-20 ~25 ~16 ~-20 ~25 ~16 ochre_froglight
fill ~20 ~25 ~16 ~20 ~25 ~16 ochre_froglight
fill ~-19 ~25 ~17 ~-19 ~25 ~17 ochre_froglight
fill ~19 ~25 ~17 ~19 ~25 ~17 ochre_froglight
fill ~-18 ~25 ~18 ~-18 ~25 ~18 ochre_froglight
fill ~18 ~25 ~18 ~18 ~25 ~18 ochre_froglight
fill ~-17 ~25 ~19 ~-17 ~25 ~19 ochre_froglight
fill ~17 ~25 ~19 ~17 ~25 ~19 ochre_froglight
fill ~-16 ~25 ~20 ~-16 ~25 ~20 ochre_froglight
fill ~16 ~25 ~20 ~16 ~25 ~20 ochre_froglight
fill ~-15 ~25 ~21 ~-14 ~25 ~21 ochre_froglight
fill ~14 ~25 ~21 ~15 ~25 ~21 ochre_froglight
fill ~-14 ~25 ~22 ~-13 ~25 ~22 ochre_froglight
fill ~13 ~25 ~22 ~14 ~25 ~22 ochre_froglight
fill ~-12 ~25 ~23 ~-11 ~25 ~23 ochre_froglight
fill ~11 ~25 ~23 ~12 ~25 ~23 ochre_froglight
fill ~-10 ~25 ~24 ~-8 ~25 ~24 ochre_froglight
fill ~8 ~25 ~24 ~10 ~25 ~24 ochre_froglight
fill ~-7 ~25 ~25 ~-3 ~25 ~25 ochre_froglight
fill ~3 ~25 ~25 ~7 ~25 ~25 ochre_froglight
fill ~-2 ~25 ~26 ~2 ~25 ~26 ochre_froglight
setblock ~18 ~26 ~17 smooth_quartz
setblock ~18 ~27 ~17 glass_pane[north=true,south=false,west=true,east=false]
setblock ~18 ~28 ~17 spruce_slab
setblock ~1 ~26 ~-24 smooth_quartz
setblock ~1 ~27 ~-24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~1 ~28 ~-24 spruce_slab
setblock ~-12 ~26 ~22 smooth_quartz
setblock ~-12 ~27 ~22 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-12 ~28 ~22 spruce_slab
setblock ~-19 ~26 ~16 smooth_quartz
setblock ~-19 ~27 ~16 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-19 ~28 ~16 spruce_slab
setblock ~-13 ~26 ~-20 smooth_quartz
setblock ~-13 ~27 ~-20 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-13 ~28 ~-20 spruce_slab
setblock ~12 ~26 ~-21 smooth_quartz
setblock ~12 ~27 ~-21 glass_pane[north=true,south=false,west=false,east=true]
setblock ~12 ~28 ~-21 spruce_slab
setblock ~-22 ~26 ~11 smooth_quartz
setblock ~-22 ~27 ~11 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-22 ~28 ~11 spruce_slab
setblock ~3 ~26 ~-24 smooth_quartz
setblock ~3 ~27 ~-24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~3 ~28 ~-24 spruce_slab
setblock ~-3 ~26 ~24 smooth_quartz
setblock ~-3 ~27 ~24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-3 ~28 ~24 spruce_slab
setblock ~1 ~26 ~24 smooth_quartz
setblock ~1 ~27 ~24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~1 ~28 ~24 spruce_slab
setblock ~19 ~26 ~-16 smooth_quartz
setblock ~19 ~27 ~-16 glass_pane[north=false,south=true,west=true,east=false]
setblock ~19 ~28 ~-16 spruce_slab
setblock ~-21 ~26 ~12 smooth_quartz
setblock ~-21 ~27 ~12 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-21 ~28 ~12 spruce_slab
setblock ~-9 ~26 ~-23 smooth_quartz
setblock ~-9 ~27 ~-23 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-9 ~28 ~-23 spruce_slab
setblock ~22 ~26 ~10 smooth_quartz
setblock ~22 ~27 ~10 glass_pane[north=false,south=true,west=false,east=true]
setblock ~22 ~28 ~10 spruce_slab
setblock ~-18 ~26 ~-17 smooth_quartz
setblock ~-18 ~27 ~-17 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-18 ~28 ~-17 spruce_slab
setblock ~-17 ~26 ~-18 smooth_quartz
setblock ~-17 ~27 ~-18 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-17 ~28 ~-18 spruce_slab
setblock ~3 ~26 ~24 smooth_quartz
setblock ~3 ~27 ~24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~3 ~28 ~24 spruce_slab
setblock ~20 ~26 ~-15 smooth_quartz
setblock ~20 ~27 ~-15 glass_pane[north=false,south=true,west=true,east=false]
setblock ~20 ~28 ~-15 spruce_slab
setblock ~24 ~26 ~1 smooth_quartz
setblock ~24 ~27 ~1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~24 ~28 ~1 spruce_slab
setblock ~23 ~26 ~-10 smooth_quartz
setblock ~23 ~27 ~-10 glass_pane[north=false,south=true,west=true,east=false]
setblock ~23 ~28 ~-10 spruce_slab
setblock ~-21 ~26 ~-13 smooth_quartz
setblock ~-21 ~27 ~-13 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-21 ~28 ~-13 spruce_slab
setblock ~-19 ~26 ~-16 smooth_quartz
setblock ~-19 ~27 ~-16 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-19 ~28 ~-16 spruce_slab
setblock ~8 ~26 ~-23 smooth_quartz
setblock ~8 ~27 ~-23 glass_pane[north=false,south=false,west=true,east=true]
setblock ~8 ~28 ~-23 spruce_slab
setblock ~-24 ~26 ~6 smooth_quartz
setblock ~-24 ~27 ~6 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-24 ~28 ~6 spruce_slab
setblock ~-16 ~26 ~19 smooth_quartz
setblock ~-16 ~27 ~19 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-16 ~28 ~19 spruce_slab
setblock ~20 ~26 ~15 smooth_quartz
setblock ~20 ~27 ~15 glass_pane[north=true,south=false,west=true,east=false]
setblock ~20 ~28 ~15 spruce_slab
setblock ~22 ~26 ~12 smooth_quartz
setblock ~22 ~27 ~12 glass_pane[north=true,south=false,west=true,east=false]
setblock ~22 ~28 ~12 spruce_slab
setblock ~-7 ~26 ~-24 smooth_quartz
setblock ~-7 ~27 ~-24 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-7 ~28 ~-24 spruce_slab
setblock ~-10 ~26 ~23 smooth_quartz
setblock ~-10 ~27 ~23 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-10 ~28 ~23 spruce_slab
setblock ~-20 ~26 ~-15 smooth_quartz
setblock ~-20 ~27 ~-15 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-20 ~28 ~-15 spruce_slab
setblock ~-15 ~26 ~-19 smooth_quartz
setblock ~-15 ~27 ~-19 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-15 ~28 ~-19 spruce_slab
setblock ~-23 ~26 ~7 smooth_quartz
setblock ~-23 ~27 ~7 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-23 ~28 ~7 spruce_slab
setblock ~24 ~26 ~-6 smooth_quartz
setblock ~24 ~27 ~-6 glass_pane[north=true,south=true,west=false,east=false]
setblock ~24 ~28 ~-6 spruce_slab
setblock ~20 ~26 ~-13 smooth_quartz
setblock ~20 ~27 ~-13 glass_pane[north=true,south=false,west=false,east=true]
setblock ~20 ~28 ~-13 spruce_slab
setblock ~24 ~26 ~3 smooth_quartz
setblock ~24 ~27 ~3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~24 ~28 ~3 spruce_slab
setblock ~14 ~26 ~-20 smooth_quartz
setblock ~14 ~27 ~-20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~14 ~28 ~-20 spruce_slab
setblock ~-5 ~26 ~-24 smooth_quartz
setblock ~-5 ~27 ~-24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-5 ~28 ~-24 spruce_slab
setblock ~23 ~26 ~-8 smooth_quartz
setblock ~23 ~27 ~-8 glass_pane[north=true,south=true,west=false,east=false]
setblock ~23 ~28 ~-8 spruce_slab
setblock ~10 ~26 ~22 smooth_quartz
setblock ~10 ~27 ~22 glass_pane[north=false,south=true,west=false,east=true]
setblock ~10 ~28 ~22 spruce_slab
setblock ~13 ~26 ~21 smooth_quartz
setblock ~13 ~27 ~21 glass_pane[north=true,south=false,west=true,east=false]
setblock ~13 ~28 ~21 spruce_slab
setblock ~17 ~26 ~-18 smooth_quartz
setblock ~17 ~27 ~-18 glass_pane[north=false,south=true,west=true,east=false]
setblock ~17 ~28 ~-18 spruce_slab
setblock ~-7 ~26 ~24 smooth_quartz
setblock ~-7 ~27 ~24 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-7 ~28 ~24 spruce_slab
setblock ~7 ~26 ~23 smooth_quartz
setblock ~7 ~27 ~23 glass_pane[north=false,south=true,west=false,east=true]
setblock ~7 ~28 ~23 spruce_slab
setblock ~-15 ~26 ~20 smooth_quartz
setblock ~-15 ~27 ~20 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-15 ~28 ~20 spruce_slab
setblock ~-23 ~26 ~-9 smooth_quartz
setblock ~-23 ~27 ~-9 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-23 ~28 ~-9 spruce_slab
setblock ~-22 ~26 ~-10 smooth_quartz
setblock ~-22 ~27 ~-10 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-22 ~28 ~-10 spruce_slab
setblock ~-20 ~26 ~-13 smooth_quartz
setblock ~-20 ~27 ~-13 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-20 ~28 ~-13 spruce_slab
setblock ~12 ~26 ~22 smooth_quartz
setblock ~12 ~27 ~22 glass_pane[north=true,south=false,west=true,east=false]
setblock ~12 ~28 ~22 spruce_slab
setblock ~-23 ~26 ~9 smooth_quartz
setblock ~-23 ~27 ~9 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-23 ~28 ~9 spruce_slab
setblock ~24 ~26 ~-4 smooth_quartz
setblock ~24 ~27 ~-4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~24 ~28 ~-4 spruce_slab
setblock ~-5 ~26 ~24 smooth_quartz
setblock ~-5 ~27 ~24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-5 ~28 ~24 spruce_slab
setblock ~24 ~26 ~5 smooth_quartz
setblock ~24 ~27 ~5 glass_pane[north=true,south=true,west=false,east=false]
setblock ~24 ~28 ~5 spruce_slab
setblock ~21 ~26 ~-12 smooth_quartz
setblock ~21 ~27 ~-12 glass_pane[north=true,south=false,west=false,east=true]
setblock ~21 ~28 ~-12 spruce_slab
setblock ~-20 ~26 ~14 smooth_quartz
setblock ~-20 ~27 ~14 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-20 ~28 ~14 spruce_slab
setblock ~22 ~26 ~-11 smooth_quartz
setblock ~22 ~27 ~-11 glass_pane[north=true,south=true,west=false,east=false]
setblock ~22 ~28 ~-11 spruce_slab
setblock ~-24 ~26 ~1 smooth_quartz
setblock ~-24 ~27 ~1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-24 ~28 ~1 spruce_slab
setblock ~16 ~26 ~19 smooth_quartz
setblock ~16 ~27 ~19 glass_pane[north=true,south=false,west=true,east=false]
setblock ~16 ~28 ~19 spruce_slab
setblock ~18 ~26 ~16 smooth_quartz
setblock ~18 ~27 ~16 glass_pane[north=false,south=true,west=false,east=true]
setblock ~18 ~28 ~16 spruce_slab
setblock ~-18 ~26 ~17 smooth_quartz
setblock ~-18 ~27 ~17 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-18 ~28 ~17 spruce_slab
setblock ~10 ~26 ~-22 smooth_quartz
setblock ~10 ~27 ~-22 glass_pane[north=true,south=false,west=false,east=true]
setblock ~10 ~28 ~-22 spruce_slab
setblock ~-12 ~26 ~21 smooth_quartz
setblock ~-12 ~27 ~21 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-12 ~28 ~21 spruce_slab
setblock ~-23 ~26 ~-7 smooth_quartz
setblock ~-23 ~27 ~-7 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-23 ~28 ~-7 spruce_slab
setblock ~13 ~26 ~-20 smooth_quartz
setblock ~13 ~27 ~-20 glass_pane[north=true,south=false,west=false,east=true]
setblock ~13 ~28 ~-20 spruce_slab
setblock ~-11 ~26 ~22 smooth_quartz
setblock ~-11 ~27 ~22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-11 ~28 ~22 spruce_slab
setblock ~-13 ~26 ~-21 smooth_quartz
setblock ~-13 ~27 ~-21 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-13 ~28 ~-21 spruce_slab
setblock ~12 ~26 ~-22 smooth_quartz
setblock ~12 ~27 ~-22 glass_pane[north=false,south=true,west=true,east=false]
setblock ~12 ~28 ~-22 spruce_slab
setblock ~-22 ~26 ~10 smooth_quartz
setblock ~-22 ~27 ~10 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-22 ~28 ~10 spruce_slab
setblock ~-12 ~26 ~-22 smooth_quartz
setblock ~-12 ~27 ~-22 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-12 ~28 ~-22 spruce_slab
setblock ~24 ~26 ~-2 smooth_quartz
setblock ~24 ~27 ~-2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~24 ~28 ~-2 spruce_slab
setblock ~24 ~26 ~7 smooth_quartz
setblock ~24 ~27 ~7 glass_pane[north=true,south=false,west=true,east=false]
setblock ~24 ~28 ~7 spruce_slab
setblock ~24 ~26 ~-1 smooth_quartz
setblock ~24 ~27 ~-1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~24 ~28 ~-1 spruce_slab
setblock ~-24 ~26 ~-6 smooth_quartz
setblock ~-24 ~27 ~-6 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-24 ~28 ~-6 spruce_slab
setblock ~-24 ~26 ~3 smooth_quartz
setblock ~-24 ~27 ~3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-24 ~28 ~3 spruce_slab
setblock ~-17 ~26 ~18 smooth_quartz
setblock ~-17 ~27 ~18 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-17 ~28 ~18 spruce_slab
setblock ~-14 ~26 ~-20 smooth_quartz
setblock ~-14 ~27 ~-20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-14 ~28 ~-20 spruce_slab
setblock ~2 ~26 ~-24 smooth_quartz
setblock ~2 ~27 ~-24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~2 ~28 ~-24 spruce_slab
setblock ~23 ~26 ~8 smooth_quartz
setblock ~23 ~27 ~8 glass_pane[north=true,south=true,west=false,east=false]
setblock ~23 ~28 ~8 spruce_slab
setblock ~6 ~26 ~-24 smooth_quartz
setblock ~6 ~27 ~-24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~6 ~28 ~-24 spruce_slab
setblock ~-16 ~26 ~-18 smooth_quartz
setblock ~-16 ~27 ~-18 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-16 ~28 ~-18 spruce_slab
setblock ~24 ~26 ~0 smooth_quartz
setblock ~24 ~27 ~0 glass_pane[north=true,south=true,west=false,east=false]
setblock ~24 ~28 ~0 spruce_slab
setblock ~-11 ~26 ~-22 smooth_quartz
setblock ~-11 ~27 ~-22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-11 ~28 ~-22 spruce_slab
setblock ~-22 ~26 ~12 smooth_quartz
setblock ~-22 ~27 ~12 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-22 ~28 ~12 spruce_slab
setblock ~-10 ~26 ~-23 smooth_quartz
setblock ~-10 ~27 ~-23 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-10 ~28 ~-23 spruce_slab
setblock ~4 ~26 ~-24 smooth_quartz
setblock ~4 ~27 ~-24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~4 ~28 ~-24 spruce_slab
setblock ~18 ~26 ~-16 smooth_quartz
setblock ~18 ~27 ~-16 glass_pane[north=true,south=false,west=false,east=true]
setblock ~18 ~28 ~-16 spruce_slab
setblock ~-24 ~26 ~-4 smooth_quartz
setblock ~-24 ~27 ~-4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-24 ~28 ~-4 spruce_slab
setblock ~2 ~26 ~24 smooth_quartz
setblock ~2 ~27 ~24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~2 ~28 ~24 spruce_slab
setblock ~-24 ~26 ~5 smooth_quartz
setblock ~-24 ~27 ~5 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-24 ~28 ~5 spruce_slab
setblock ~-8 ~26 ~23 smooth_quartz
setblock ~-8 ~27 ~23 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-8 ~28 ~23 spruce_slab
setblock ~-16 ~26 ~18 smooth_quartz
setblock ~-16 ~27 ~18 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-16 ~28 ~18 spruce_slab
setblock ~19 ~26 ~-15 smooth_quartz
setblock ~19 ~27 ~-15 glass_pane[north=true,south=false,west=false,east=true]
setblock ~19 ~28 ~-15 spruce_slab
setblock ~20 ~26 ~14 smooth_quartz
setblock ~20 ~27 ~14 glass_pane[north=true,south=true,west=false,east=false]
setblock ~20 ~28 ~14 spruce_slab
setblock ~22 ~26 ~11 smooth_quartz
setblock ~22 ~27 ~11 glass_pane[north=true,south=true,west=false,east=false]
setblock ~22 ~28 ~11 spruce_slab
setblock ~21 ~26 ~13 smooth_quartz
setblock ~21 ~27 ~13 glass_pane[north=true,south=false,west=true,east=false]
setblock ~21 ~28 ~13 spruce_slab
setblock ~23 ~26 ~10 smooth_quartz
setblock ~23 ~27 ~10 glass_pane[north=true,south=false,west=true,east=false]
setblock ~23 ~28 ~10 spruce_slab
setblock ~6 ~26 ~24 smooth_quartz
setblock ~6 ~27 ~24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~6 ~28 ~24 spruce_slab
setblock ~-8 ~26 ~-23 smooth_quartz
setblock ~-8 ~27 ~-23 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-8 ~28 ~-23 spruce_slab
setblock ~-13 ~26 ~20 smooth_quartz
setblock ~-13 ~27 ~20 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-13 ~28 ~20 spruce_slab
setblock ~-17 ~26 ~-17 smooth_quartz
setblock ~-17 ~27 ~-17 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-17 ~28 ~-17 spruce_slab
setblock ~15 ~26 ~-19 smooth_quartz
setblock ~15 ~27 ~-19 glass_pane[north=true,south=false,west=false,east=true]
setblock ~15 ~28 ~-19 spruce_slab
setblock ~7 ~26 ~-23 smooth_quartz
setblock ~7 ~27 ~-23 glass_pane[north=true,south=false,west=false,east=true]
setblock ~7 ~28 ~-23 spruce_slab
setblock ~24 ~26 ~-7 smooth_quartz
setblock ~24 ~27 ~-7 glass_pane[north=false,south=true,west=true,east=false]
setblock ~24 ~28 ~-7 spruce_slab
setblock ~4 ~26 ~24 smooth_quartz
setblock ~4 ~27 ~24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~4 ~28 ~24 spruce_slab
setblock ~24 ~26 ~2 smooth_quartz
setblock ~24 ~27 ~2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~24 ~28 ~2 spruce_slab
setblock ~17 ~26 ~18 smooth_quartz
setblock ~17 ~27 ~18 glass_pane[north=true,south=false,west=true,east=false]
setblock ~17 ~28 ~18 spruce_slab
setblock ~19 ~26 ~15 smooth_quartz
setblock ~19 ~27 ~15 glass_pane[north=false,south=true,west=false,east=true]
setblock ~19 ~28 ~15 spruce_slab
setblock ~-21 ~26 ~-12 smooth_quartz
setblock ~-21 ~27 ~-12 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-21 ~28 ~-12 spruce_slab
setblock ~-19 ~26 ~-15 smooth_quartz
setblock ~-19 ~27 ~-15 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-19 ~28 ~-15 spruce_slab
setblock ~9 ~26 ~23 smooth_quartz
setblock ~9 ~27 ~23 glass_pane[north=false,south=false,west=true,east=true]
setblock ~9 ~28 ~23 spruce_slab
setblock ~-24 ~26 ~-1 smooth_quartz
setblock ~-24 ~27 ~-1 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-24 ~28 ~-1 spruce_slab
setblock ~-24 ~26 ~-2 smooth_quartz
setblock ~-24 ~27 ~-2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-24 ~28 ~-2 spruce_slab
setblock ~-24 ~26 ~7 smooth_quartz
setblock ~-24 ~27 ~7 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-24 ~28 ~7 spruce_slab
setblock ~-7 ~26 ~23 smooth_quartz
setblock ~-7 ~27 ~23 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-7 ~28 ~23 spruce_slab
setblock ~9 ~26 ~-23 smooth_quartz
setblock ~9 ~27 ~-23 glass_pane[north=false,south=false,west=true,east=true]
setblock ~9 ~28 ~-23 spruce_slab
setblock ~-15 ~26 ~19 smooth_quartz
setblock ~-15 ~27 ~19 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-15 ~28 ~19 spruce_slab
setblock ~15 ~26 ~20 smooth_quartz
setblock ~15 ~27 ~20 glass_pane[north=true,south=false,west=true,east=false]
setblock ~15 ~28 ~20 spruce_slab
setblock ~-23 ~26 ~-10 smooth_quartz
setblock ~-23 ~27 ~-10 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-23 ~28 ~-10 spruce_slab
setblock ~-22 ~26 ~-11 smooth_quartz
setblock ~-22 ~27 ~-11 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-22 ~28 ~-11 spruce_slab
setblock ~-20 ~26 ~-14 smooth_quartz
setblock ~-20 ~27 ~-14 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-20 ~28 ~-14 spruce_slab
setblock ~12 ~26 ~21 smooth_quartz
setblock ~12 ~27 ~21 glass_pane[north=false,south=true,west=false,east=true]
setblock ~12 ~28 ~21 spruce_slab
setblock ~-19 ~26 ~15 smooth_quartz
setblock ~-19 ~27 ~15 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-19 ~28 ~15 spruce_slab
setblock ~16 ~26 ~-18 smooth_quartz
setblock ~16 ~27 ~-18 glass_pane[north=true,south=false,west=false,east=true]
setblock ~16 ~28 ~-18 spruce_slab
setblock ~-2 ~26 ~-24 smooth_quartz
setblock ~-2 ~27 ~-24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-2 ~28 ~-24 spruce_slab
setblock ~-1 ~26 ~-24 smooth_quartz
setblock ~-1 ~27 ~-24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-1 ~28 ~-24 spruce_slab
setblock ~24 ~26 ~-5 smooth_quartz
setblock ~24 ~27 ~-5 glass_pane[north=true,south=true,west=false,east=false]
setblock ~24 ~28 ~-5 spruce_slab
setblock ~24 ~26 ~4 smooth_quartz
setblock ~24 ~27 ~4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~24 ~28 ~4 spruce_slab
setblock ~10 ~26 ~23 smooth_quartz
setblock ~10 ~27 ~23 glass_pane[north=true,south=false,west=true,east=false]
setblock ~10 ~28 ~23 spruce_slab
setblock ~22 ~26 ~-12 smooth_quartz
setblock ~22 ~27 ~-12 glass_pane[north=false,south=true,west=true,east=false]
setblock ~22 ~28 ~-12 spruce_slab
setblock ~11 ~26 ~22 smooth_quartz
setblock ~11 ~27 ~22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~11 ~28 ~22 spruce_slab
setblock ~-24 ~26 ~0 smooth_quartz
setblock ~-24 ~27 ~0 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-24 ~28 ~0 spruce_slab
setblock ~-18 ~26 ~16 smooth_quartz
setblock ~-18 ~27 ~16 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-18 ~28 ~16 spruce_slab
setblock ~17 ~26 ~-17 smooth_quartz
setblock ~17 ~27 ~-17 glass_pane[north=true,south=false,west=false,east=true]
setblock ~17 ~28 ~-17 spruce_slab
setblock ~0 ~26 ~-24 smooth_quartz
setblock ~0 ~27 ~-24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~0 ~28 ~-24 spruce_slab
setblock ~-23 ~26 ~-8 smooth_quartz
setblock ~-23 ~27 ~-8 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-23 ~28 ~-8 spruce_slab
setblock ~13 ~26 ~-21 smooth_quartz
setblock ~13 ~27 ~-21 glass_pane[north=false,south=true,west=true,east=false]
setblock ~13 ~28 ~-21 spruce_slab
setblock ~-1 ~26 ~24 smooth_quartz
setblock ~-1 ~27 ~24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-1 ~28 ~24 spruce_slab
setblock ~-2 ~26 ~24 smooth_quartz
setblock ~-2 ~27 ~24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-2 ~28 ~24 spruce_slab
setblock ~24 ~26 ~-3 smooth_quartz
setblock ~24 ~27 ~-3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~24 ~28 ~-3 spruce_slab
setblock ~24 ~26 ~6 smooth_quartz
setblock ~24 ~27 ~6 glass_pane[north=true,south=true,west=false,east=false]
setblock ~24 ~28 ~6 spruce_slab
setblock ~-24 ~26 ~-7 smooth_quartz
setblock ~-24 ~27 ~-7 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-24 ~28 ~-7 spruce_slab
setblock ~22 ~26 ~-10 smooth_quartz
setblock ~22 ~27 ~-10 glass_pane[north=true,south=false,west=false,east=true]
setblock ~22 ~28 ~-10 spruce_slab
setblock ~0 ~26 ~24 smooth_quartz
setblock ~0 ~27 ~24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~0 ~28 ~24 spruce_slab
setblock ~-24 ~26 ~2 smooth_quartz
setblock ~-24 ~27 ~2 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-24 ~28 ~2 spruce_slab
setblock ~-17 ~26 ~17 smooth_quartz
setblock ~-17 ~27 ~17 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-17 ~28 ~17 spruce_slab
setblock ~11 ~26 ~-22 smooth_quartz
setblock ~11 ~27 ~-22 glass_pane[north=false,south=false,west=true,east=true]
setblock ~11 ~28 ~-22 spruce_slab
setblock ~23 ~26 ~7 smooth_quartz
setblock ~23 ~27 ~7 glass_pane[north=false,south=true,west=false,east=true]
setblock ~23 ~28 ~7 spruce_slab
setblock ~-21 ~26 ~13 smooth_quartz
setblock ~-21 ~27 ~13 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-21 ~28 ~13 spruce_slab
setblock ~-10 ~26 ~22 smooth_quartz
setblock ~-10 ~27 ~22 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-10 ~28 ~22 spruce_slab
setblock ~-18 ~26 ~-16 smooth_quartz
setblock ~-18 ~27 ~-16 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-18 ~28 ~-16 spruce_slab
setblock ~-16 ~26 ~-19 smooth_quartz
setblock ~-16 ~27 ~-19 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-16 ~28 ~-19 spruce_slab
setblock ~18 ~26 ~-17 smooth_quartz
setblock ~18 ~27 ~-17 glass_pane[north=false,south=true,west=true,east=false]
setblock ~18 ~28 ~-17 spruce_slab
setblock ~-15 ~26 ~-20 smooth_quartz
setblock ~-15 ~27 ~-20 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-15 ~28 ~-20 spruce_slab
setblock ~-12 ~26 ~-21 smooth_quartz
setblock ~-12 ~27 ~-21 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-12 ~28 ~-21 spruce_slab
setblock ~20 ~26 ~-14 smooth_quartz
setblock ~20 ~27 ~-14 glass_pane[north=true,south=true,west=false,east=false]
setblock ~20 ~28 ~-14 spruce_slab
setblock ~-24 ~26 ~-5 smooth_quartz
setblock ~-24 ~27 ~-5 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-24 ~28 ~-5 spruce_slab
setblock ~-6 ~26 ~-24 smooth_quartz
setblock ~-6 ~27 ~-24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-6 ~28 ~-24 spruce_slab
setblock ~5 ~26 ~-24 smooth_quartz
setblock ~5 ~27 ~-24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~5 ~28 ~-24 spruce_slab
setblock ~-9 ~26 ~23 smooth_quartz
setblock ~-9 ~27 ~23 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-9 ~28 ~23 spruce_slab
setblock ~-24 ~26 ~4 smooth_quartz
setblock ~-24 ~27 ~4 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-24 ~28 ~4 spruce_slab
setblock ~23 ~26 ~-9 smooth_quartz
setblock ~23 ~27 ~-9 glass_pane[north=true,south=true,west=false,east=false]
setblock ~23 ~28 ~-9 spruce_slab
setblock ~13 ~26 ~20 smooth_quartz
setblock ~13 ~27 ~20 glass_pane[north=false,south=true,west=false,east=true]
setblock ~13 ~28 ~20 spruce_slab
setblock ~20 ~26 ~13 smooth_quartz
setblock ~20 ~27 ~13 glass_pane[north=false,south=true,west=false,east=true]
setblock ~20 ~28 ~13 spruce_slab
setblock ~21 ~26 ~12 smooth_quartz
setblock ~21 ~27 ~12 glass_pane[north=false,south=true,west=false,east=true]
setblock ~21 ~28 ~12 spruce_slab
setblock ~23 ~26 ~9 smooth_quartz
setblock ~23 ~27 ~9 glass_pane[north=true,south=true,west=false,east=false]
setblock ~23 ~28 ~9 spruce_slab
setblock ~15 ~26 ~-20 smooth_quartz
setblock ~15 ~27 ~-20 glass_pane[north=false,south=true,west=true,east=false]
setblock ~15 ~28 ~-20 spruce_slab
setblock ~-7 ~26 ~-23 smooth_quartz
setblock ~-7 ~27 ~-23 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-7 ~28 ~-23 spruce_slab
setblock ~-4 ~26 ~-24 smooth_quartz
setblock ~-4 ~27 ~-24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-4 ~28 ~-24 spruce_slab
setblock ~7 ~26 ~-24 smooth_quartz
setblock ~7 ~27 ~-24 glass_pane[north=false,south=true,west=true,east=false]
setblock ~7 ~28 ~-24 spruce_slab
setblock ~17 ~26 ~17 smooth_quartz
setblock ~17 ~27 ~17 glass_pane[north=false,south=true,west=false,east=true]
setblock ~17 ~28 ~17 spruce_slab
setblock ~-10 ~26 ~-22 smooth_quartz
setblock ~-10 ~27 ~-22 glass_pane[north=true,south=false,west=true,east=false]
setblock ~-10 ~28 ~-22 spruce_slab
setblock ~-23 ~26 ~8 smooth_quartz
setblock ~-23 ~27 ~8 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-23 ~28 ~8 spruce_slab
setblock ~5 ~26 ~24 smooth_quartz
setblock ~5 ~27 ~24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~5 ~28 ~24 spruce_slab
setblock ~8 ~26 ~23 smooth_quartz
setblock ~8 ~27 ~23 glass_pane[north=false,south=false,west=true,east=true]
setblock ~8 ~28 ~23 spruce_slab
setblock ~-6 ~26 ~24 smooth_quartz
setblock ~-6 ~27 ~24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-6 ~28 ~24 spruce_slab
setblock ~-14 ~26 ~20 smooth_quartz
setblock ~-14 ~27 ~20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-14 ~28 ~20 spruce_slab
setblock ~21 ~26 ~-13 smooth_quartz
setblock ~21 ~27 ~-13 glass_pane[north=false,south=true,west=true,east=false]
setblock ~21 ~28 ~-13 spruce_slab
setblock ~-24 ~26 ~-3 smooth_quartz
setblock ~-24 ~27 ~-3 glass_pane[north=true,south=true,west=false,east=false]
setblock ~-24 ~28 ~-3 spruce_slab
setblock ~-20 ~26 ~13 smooth_quartz
setblock ~-20 ~27 ~13 glass_pane[north=false,south=true,west=true,east=false]
setblock ~-20 ~28 ~13 spruce_slab
setblock ~23 ~26 ~-7 smooth_quartz
setblock ~23 ~27 ~-7 glass_pane[north=true,south=false,west=false,east=true]
setblock ~23 ~28 ~-7 spruce_slab
setblock ~15 ~26 ~19 smooth_quartz
setblock ~15 ~27 ~19 glass_pane[north=false,south=true,west=false,east=true]
setblock ~15 ~28 ~19 spruce_slab
setblock ~16 ~26 ~18 smooth_quartz
setblock ~16 ~27 ~18 glass_pane[north=false,south=true,west=false,east=true]
setblock ~16 ~28 ~18 spruce_slab
setblock ~10 ~26 ~-23 smooth_quartz
setblock ~10 ~27 ~-23 glass_pane[north=false,south=true,west=true,east=false]
setblock ~10 ~28 ~-23 spruce_slab
setblock ~7 ~26 ~24 smooth_quartz
setblock ~7 ~27 ~24 glass_pane[north=true,south=false,west=true,east=false]
setblock ~7 ~28 ~24 spruce_slab
setblock ~-4 ~26 ~24 smooth_quartz
setblock ~-4 ~27 ~24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-4 ~28 ~24 spruce_slab
setblock ~-13 ~26 ~21 smooth_quartz
setblock ~-13 ~27 ~21 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-13 ~28 ~21 spruce_slab
setblock ~-22 ~26 ~-12 smooth_quartz
setblock ~-22 ~27 ~-12 glass_pane[north=false,south=true,west=false,east=true]
setblock ~-22 ~28 ~-12 spruce_slab
setblock ~16 ~26 ~-19 smooth_quartz
setblock ~16 ~27 ~-19 glass_pane[north=false,south=true,west=true,east=false]
setblock ~16 ~28 ~-19 spruce_slab
setblock ~14 ~26 ~20 smooth_quartz
setblock ~14 ~27 ~20 glass_pane[north=false,south=false,west=true,east=true]
setblock ~14 ~28 ~20 spruce_slab
setblock ~19 ~26 ~16 smooth_quartz
setblock ~19 ~27 ~16 glass_pane[north=true,south=false,west=true,east=false]
setblock ~19 ~28 ~16 spruce_slab
setblock ~-23 ~26 ~10 smooth_quartz
setblock ~-23 ~27 ~10 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-23 ~28 ~10 spruce_slab
setblock ~-20 ~26 ~15 smooth_quartz
setblock ~-20 ~27 ~15 glass_pane[north=true,south=false,west=false,east=true]
setblock ~-20 ~28 ~15 spruce_slab
setblock ~-3 ~26 ~-24 smooth_quartz
setblock ~-3 ~27 ~-24 glass_pane[north=false,south=false,west=true,east=true]
setblock ~-3 ~28 ~-24 spruce_slab
fill ~-8 ~34 ~-48 ~8 ~34 ~-48 smooth_quartz
fill ~-13 ~34 ~-47 ~13 ~34 ~-47 smooth_quartz
fill ~-16 ~34 ~-46 ~16 ~34 ~-46 smooth_quartz
fill ~-18 ~34 ~-45 ~18 ~34 ~-45 smooth_quartz
fill ~-21 ~34 ~-44 ~21 ~34 ~-44 smooth_quartz
fill ~-23 ~34 ~-43 ~23 ~34 ~-43 smooth_quartz
fill ~-24 ~34 ~-42 ~24 ~34 ~-42 smooth_quartz
fill ~-26 ~34 ~-41 ~26 ~34 ~-41 smooth_quartz
fill ~-27 ~34 ~-40 ~27 ~34 ~-40 smooth_quartz
fill ~-29 ~34 ~-39 ~29 ~34 ~-39 smooth_quartz
fill ~-30 ~34 ~-38 ~30 ~34 ~-38 smooth_quartz
fill ~-31 ~34 ~-37 ~31 ~34 ~-37 smooth_quartz
fill ~-32 ~34 ~-36 ~32 ~34 ~-36 smooth_quartz
fill ~-34 ~34 ~-35 ~34 ~34 ~-35 smooth_quartz
fill ~-35 ~34 ~-34 ~35 ~34 ~-34 smooth_quartz
fill ~-35 ~34 ~-33 ~35 ~34 ~-33 smooth_quartz
fill ~-36 ~34 ~-32 ~36 ~34 ~-32 smooth_quartz
fill ~-37 ~34 ~-31 ~37 ~34 ~-31 smooth_quartz
fill ~-38 ~34 ~-30 ~38 ~34 ~-30 smooth_quartz
fill ~-39 ~34 ~-29 ~39 ~34 ~-29 smooth_quartz
fill ~-39 ~34 ~-28 ~39 ~34 ~-28 smooth_quartz
fill ~-40 ~34 ~-27 ~40 ~34 ~-27 smooth_quartz
fill ~-41 ~34 ~-26 ~41 ~34 ~-26 smooth_quartz
fill ~-41 ~34 ~-25 ~41 ~34 ~-25 smooth_quartz
fill ~-42 ~34 ~-24 ~42 ~34 ~-24 smooth_quartz
fill ~-43 ~34 ~-23 ~-7 ~34 ~-23 smooth_quartz
fill ~7 ~34 ~-23 ~43 ~34 ~-23 smooth_quartz
fill ~-43 ~34 ~-22 ~-10 ~34 ~-22 smooth_quartz
fill ~10 ~34 ~-22 ~43 ~34 ~-22 smooth_quartz
fill ~-44 ~34 ~-21 ~-12 ~34 ~-21 smooth_quartz
fill ~12 ~34 ~-21 ~44 ~34 ~-21 smooth_quartz
fill ~-44 ~34 ~-20 ~-14 ~34 ~-20 smooth_quartz
fill ~14 ~34 ~-20 ~44 ~34 ~-20 smooth_quartz
fill ~-44 ~34 ~-19 ~-15 ~34 ~-19 smooth_quartz
fill ~15 ~34 ~-19 ~44 ~34 ~-19 smooth_quartz
fill ~-45 ~34 ~-18 ~-16 ~34 ~-18 smooth_quartz
fill ~16 ~34 ~-18 ~45 ~34 ~-18 smooth_quartz
fill ~-45 ~34 ~-17 ~-17 ~34 ~-17 smooth_quartz
fill ~17 ~34 ~-17 ~45 ~34 ~-17 smooth_quartz
fill ~-46 ~34 ~-16 ~-18 ~34 ~-16 smooth_quartz
fill ~18 ~34 ~-16 ~46 ~34 ~-16 smooth_quartz
fill ~-46 ~34 ~-15 ~-19 ~34 ~-15 smooth_quartz
fill ~19 ~34 ~-15 ~46 ~34 ~-15 smooth_quartz
fill ~-46 ~34 ~-14 ~-20 ~34 ~-14 smooth_quartz
fill ~20 ~34 ~-14 ~46 ~34 ~-14 smooth_quartz
fill ~-47 ~34 ~-13 ~-21 ~34 ~-13 smooth_quartz
fill ~21 ~34 ~-13 ~47 ~34 ~-13 smooth_quartz
fill ~-47 ~34 ~-12 ~-21 ~34 ~-12 smooth_quartz
fill ~21 ~34 ~-12 ~47 ~34 ~-12 smooth_quartz
fill ~-47 ~34 ~-11 ~-22 ~34 ~-11 smooth_quartz
fill ~22 ~34 ~-11 ~47 ~34 ~-11 smooth_quartz
fill ~-47 ~34 ~-10 ~-22 ~34 ~-10 smooth_quartz
fill ~22 ~34 ~-10 ~47 ~34 ~-10 smooth_quartz
fill ~-47 ~34 ~-9 ~-23 ~34 ~-9 smooth_quartz
fill ~23 ~34 ~-9 ~47 ~34 ~-9 smooth_quartz
fill ~-48 ~34 ~-8 ~-23 ~34 ~-8 smooth_quartz
fill ~23 ~34 ~-8 ~48 ~34 ~-8 smooth_quartz
fill ~-48 ~34 ~-7 ~-23 ~34 ~-7 smooth_quartz
fill ~23 ~34 ~-7 ~48 ~34 ~-7 smooth_quartz
fill ~-48 ~34 ~-6 ~-24 ~34 ~-6 smooth_quartz
fill ~24 ~34 ~-6 ~48 ~34 ~-6 smooth_quartz
fill ~-48 ~34 ~-5 ~-24 ~34 ~-5 smooth_quartz
fill ~24 ~34 ~-5 ~48 ~34 ~-5 smooth_quartz
fill ~-48 ~34 ~-4 ~-24 ~34 ~-4 smooth_quartz
fill ~24 ~34 ~-4 ~48 ~34 ~-4 smooth_quartz
fill ~-48 ~34 ~-3 ~-24 ~34 ~-3 smooth_quartz
fill ~24 ~34 ~-3 ~48 ~34 ~-3 smooth_quartz
fill ~-48 ~34 ~-2 ~-24 ~34 ~-2 smooth_quartz
fill ~24 ~34 ~-2 ~48 ~34 ~-2 smooth_quartz
fill ~-48 ~34 ~-1 ~-24 ~34 ~-1 smooth_quartz
fill ~24 ~34 ~-1 ~48 ~34 ~-1 smooth_quartz
fill ~-48 ~34 ~0 ~-24 ~34 ~0 smooth_quartz
fill ~24 ~34 ~0 ~48 ~34 ~0 smooth_quartz
fill ~-48 ~34 ~1 ~-24 ~34 ~1 smooth_quartz
fill ~24 ~34 ~1 ~48 ~34 ~1 smooth_quartz
fill ~-48 ~34 ~2 ~-24 ~34 ~2 smooth_quartz
fill ~24 ~34 ~2 ~48 ~34 ~2 smooth_quartz
fill ~-48 ~34 ~3 ~-24 ~34 ~3 smooth_quartz
fill ~24 ~34 ~3 ~48 ~34 ~3 smooth_quartz
fill ~-48 ~34 ~4 ~-24 ~34 ~4 smooth_quartz
fill ~24 ~34 ~4 ~48 ~34 ~4 smooth_quartz
fill ~-48 ~34 ~5 ~-24 ~34 ~5 smooth_quartz
fill ~24 ~34 ~5 ~48 ~34 ~5 smooth_quartz
fill ~-48 ~34 ~6 ~-24 ~34 ~6 smooth_quartz
fill ~24 ~34 ~6 ~48 ~34 ~6 smooth_quartz
fill ~-48 ~34 ~7 ~-23 ~34 ~7 smooth_quartz
fill ~23 ~34 ~7 ~48 ~34 ~7 smooth_quartz
fill ~-48 ~34 ~8 ~-23 ~34 ~8 smooth_quartz
fill ~23 ~34 ~8 ~48 ~34 ~8 smooth_quartz
fill ~-47 ~34 ~9 ~-23 ~34 ~9 smooth_quartz
fill ~23 ~34 ~9 ~47 ~34 ~9 smooth_quartz
fill ~-47 ~34 ~10 ~-22 ~34 ~10 smooth_quartz
fill ~22 ~34 ~10 ~47 ~34 ~10 smooth_quartz
fill ~-47 ~34 ~11 ~-22 ~34 ~11 smooth_quartz
fill ~22 ~34 ~11 ~47 ~34 ~11 smooth_quartz
fill ~-47 ~34 ~12 ~-21 ~34 ~12 smooth_quartz
fill ~21 ~34 ~12 ~47 ~34 ~12 smooth_quartz
fill ~-47 ~34 ~13 ~-21 ~34 ~13 smooth_quartz
fill ~21 ~34 ~13 ~47 ~34 ~13 smooth_quartz
fill ~-46 ~34 ~14 ~-20 ~34 ~14 smooth_quartz
fill ~20 ~34 ~14 ~46 ~34 ~14 smooth_quartz
fill ~-46 ~34 ~15 ~-19 ~34 ~15 smooth_quartz
fill ~19 ~34 ~15 ~46 ~34 ~15 smooth_quartz
fill ~-46 ~34 ~16 ~-18 ~34 ~16 smooth_quartz
fill ~18 ~34 ~16 ~46 ~34 ~16 smooth_quartz
fill ~-45 ~34 ~17 ~-17 ~34 ~17 smooth_quartz
fill ~17 ~34 ~17 ~45 ~34 ~17 smooth_quartz
fill ~-45 ~34 ~18 ~-16 ~34 ~18 smooth_quartz
fill ~16 ~34 ~18 ~45 ~34 ~18 smooth_quartz
fill ~-44 ~34 ~19 ~-15 ~34 ~19 smooth_quartz
fill ~15 ~34 ~19 ~44 ~34 ~19 smooth_quartz
fill ~-44 ~34 ~20 ~-14 ~34 ~20 smooth_quartz
fill ~14 ~34 ~20 ~44 ~34 ~20 smooth_quartz
fill ~-44 ~34 ~21 ~-12 ~34 ~21 smooth_quartz
fill ~12 ~34 ~21 ~44 ~34 ~21 smooth_quartz
fill ~-43 ~34 ~22 ~-10 ~34 ~22 smooth_quartz
fill ~10 ~34 ~22 ~43 ~34 ~22 smooth_quartz
fill ~-43 ~34 ~23 ~-7 ~34 ~23 smooth_quartz
fill ~7 ~34 ~23 ~43 ~34 ~23 smooth_quartz
fill ~-42 ~34 ~24 ~42 ~34 ~24 smooth_quartz
fill ~-41 ~34 ~25 ~41 ~34 ~25 smooth_quartz
fill ~-41 ~34 ~26 ~41 ~34 ~26 smooth_quartz
fill ~-40 ~34 ~27 ~40 ~34 ~27 smooth_quartz
fill ~-39 ~34 ~28 ~39 ~34 ~28 smooth_quartz
fill ~-39 ~34 ~29 ~39 ~34 ~29 smooth_quartz
fill ~-38 ~34 ~30 ~38 ~34 ~30 smooth_quartz
fill ~-37 ~34 ~31 ~37 ~34 ~31 smooth_quartz
fill ~-36 ~34 ~32 ~36 ~34 ~32 smooth_quartz
fill ~-35 ~34 ~33 ~35 ~34 ~33 smooth_quartz
fill ~-35 ~34 ~34 ~35 ~34 ~34 smooth_quartz
fill ~-34 ~34 ~35 ~34 ~34 ~35 smooth_quartz
fill ~-32 ~34 ~36 ~32 ~34 ~36 smooth_quartz
fill ~-31 ~34 ~37 ~31 ~34 ~37 smooth_quartz
fill ~-30 ~34 ~38 ~30 ~34 ~38 smooth_quartz
fill ~-29 ~34 ~39 ~29 ~34 ~39 smooth_quartz
fill ~-27 ~34 ~40 ~27 ~34 ~40 smooth_quartz
fill ~-26 ~34 ~41 ~26 ~34 ~41 smooth_quartz
fill ~-24 ~34 ~42 ~24 ~34 ~42 smooth_quartz
fill ~-23 ~34 ~43 ~23 ~34 ~43 smooth_quartz
fill ~-21 ~34 ~44 ~21 ~34 ~44 smooth_quartz
fill ~-18 ~34 ~45 ~18 ~34 ~45 smooth_quartz
fill ~-16 ~34 ~46 ~16 ~34 ~46 smooth_quartz
fill ~-13 ~34 ~47 ~13 ~34 ~47 smooth_quartz
fill ~-8 ~34 ~48 ~8 ~34 ~48 smooth_quartz
setblock ~-40 ~34 ~-20 ochre_froglight
setblock ~-40 ~34 ~-15 ochre_froglight
setblock ~-40 ~34 ~-10 ochre_froglight
setblock ~-40 ~34 ~-5 ochre_froglight
setblock ~-40 ~34 ~0 ochre_froglight
setblock ~-40 ~34 ~5 ochre_froglight
setblock ~-40 ~34 ~10 ochre_froglight
setblock ~-40 ~34 ~15 ochre_froglight
setblock ~-40 ~34 ~20 ochre_froglight
setblock ~-35 ~34 ~-25 ochre_froglight
setblock ~-35 ~34 ~-20 ochre_froglight
setblock ~-35 ~34 ~-15 ochre_froglight
setblock ~-35 ~34 ~-10 ochre_froglight
setblock ~-35 ~34 ~-5 ochre_froglight
setblock ~-35 ~34 ~0 ochre_froglight
setblock ~-35 ~34 ~5 ochre_froglight
setblock ~-35 ~34 ~10 ochre_froglight
setblock ~-35 ~34 ~15 ochre_froglight
setblock ~-35 ~34 ~20 ochre_froglight
setblock ~-35 ~34 ~25 ochre_froglight
setblock ~-30 ~34 ~-30 ochre_froglight
setblock ~-30 ~34 ~-25 ochre_froglight
setblock ~-30 ~34 ~-20 ochre_froglight
setblock ~-30 ~34 ~-15 ochre_froglight
setblock ~-30 ~34 ~-10 ochre_froglight
setblock ~-30 ~34 ~-5 ochre_froglight
setblock ~-30 ~34 ~0 ochre_froglight
setblock ~-30 ~34 ~5 ochre_froglight
setblock ~-30 ~34 ~10 ochre_froglight
setblock ~-30 ~34 ~15 ochre_froglight
setblock ~-30 ~34 ~20 ochre_froglight
setblock ~-30 ~34 ~25 ochre_froglight
setblock ~-30 ~34 ~30 ochre_froglight
setblock ~-25 ~34 ~-35 ochre_froglight
setblock ~-25 ~34 ~-30 ochre_froglight
setblock ~-25 ~34 ~-25 ochre_froglight
setblock ~-25 ~34 ~-20 ochre_froglight
setblock ~-25 ~34 ~-15 ochre_froglight
setblock ~-25 ~34 ~-10 ochre_froglight
setblock ~-25 ~34 ~10 ochre_froglight
setblock ~-25 ~34 ~15 ochre_froglight
setblock ~-25 ~34 ~20 ochre_froglight
setblock ~-25 ~34 ~25 ochre_froglight
setblock ~-25 ~34 ~30 ochre_froglight
setblock ~-25 ~34 ~35 ochre_froglight
setblock ~-20 ~34 ~-40 ochre_froglight
setblock ~-20 ~34 ~-35 ochre_froglight
setblock ~-20 ~34 ~-30 ochre_froglight
setblock ~-20 ~34 ~-25 ochre_froglight
setblock ~-20 ~34 ~-20 ochre_froglight
setblock ~-20 ~34 ~20 ochre_froglight
setblock ~-20 ~34 ~25 ochre_froglight
setblock ~-20 ~34 ~30 ochre_froglight
setblock ~-20 ~34 ~35 ochre_froglight
setblock ~-20 ~34 ~40 ochre_froglight
setblock ~-15 ~34 ~-40 ochre_froglight
setblock ~-15 ~34 ~-35 ochre_froglight
setblock ~-15 ~34 ~-30 ochre_froglight
setblock ~-15 ~34 ~-25 ochre_froglight
setblock ~-15 ~34 ~25 ochre_froglight
setblock ~-15 ~34 ~30 ochre_froglight
setblock ~-15 ~34 ~35 ochre_froglight
setblock ~-15 ~34 ~40 ochre_froglight
setblock ~-10 ~34 ~-40 ochre_froglight
setblock ~-10 ~34 ~-35 ochre_froglight
setblock ~-10 ~34 ~-30 ochre_froglight
setblock ~-10 ~34 ~-25 ochre_froglight
setblock ~-10 ~34 ~25 ochre_froglight
setblock ~-10 ~34 ~30 ochre_froglight
setblock ~-10 ~34 ~35 ochre_froglight
setblock ~-10 ~34 ~40 ochre_froglight
setblock ~-5 ~34 ~-40 ochre_froglight
setblock ~-5 ~34 ~-35 ochre_froglight
setblock ~-5 ~34 ~-30 ochre_froglight
setblock ~-5 ~34 ~30 ochre_froglight
setblock ~-5 ~34 ~35 ochre_froglight
setblock ~-5 ~34 ~40 ochre_froglight
setblock ~0 ~34 ~-40 ochre_froglight
setblock ~0 ~34 ~-35 ochre_froglight
setblock ~0 ~34 ~-30 ochre_froglight
setblock ~0 ~34 ~30 ochre_froglight
setblock ~0 ~34 ~35 ochre_froglight
setblock ~0 ~34 ~40 ochre_froglight
setblock ~5 ~34 ~-40 ochre_froglight
setblock ~5 ~34 ~-35 ochre_froglight
setblock ~5 ~34 ~-30 ochre_froglight
setblock ~5 ~34 ~30 ochre_froglight
setblock ~5 ~34 ~35 ochre_froglight
setblock ~5 ~34 ~40 ochre_froglight
setblock ~10 ~34 ~-40 ochre_froglight
setblock ~10 ~34 ~-35 ochre_froglight
setblock ~10 ~34 ~-30 ochre_froglight
setblock ~10 ~34 ~-25 ochre_froglight
setblock ~10 ~34 ~25 ochre_froglight
setblock ~10 ~34 ~30 ochre_froglight
setblock ~10 ~34 ~35 ochre_froglight
setblock ~10 ~34 ~40 ochre_froglight
setblock ~15 ~34 ~-40 ochre_froglight
setblock ~15 ~34 ~-35 ochre_froglight
setblock ~15 ~34 ~-30 ochre_froglight
setblock ~15 ~34 ~-25 ochre_froglight
setblock ~15 ~34 ~25 ochre_froglight
setblock ~15 ~34 ~30 ochre_froglight
setblock ~15 ~34 ~35 ochre_froglight
setblock ~15 ~34 ~40 ochre_froglight
setblock ~20 ~34 ~-40 ochre_froglight
setblock ~20 ~34 ~-35 ochre_froglight
setblock ~20 ~34 ~-30 ochre_froglight
setblock ~20 ~34 ~-25 ochre_froglight
setblock ~20 ~34 ~-20 ochre_froglight
setblock ~20 ~34 ~20 ochre_froglight
setblock ~20 ~34 ~25 ochre_froglight
setblock ~20 ~34 ~30 ochre_froglight
setblock ~20 ~34 ~35 ochre_froglight
setblock ~20 ~34 ~40 ochre_froglight
setblock ~25 ~34 ~-35 ochre_froglight
setblock ~25 ~34 ~-30 ochre_froglight
setblock ~25 ~34 ~-25 ochre_froglight
setblock ~25 ~34 ~-20 ochre_froglight
setblock ~25 ~34 ~-15 ochre_froglight
setblock ~25 ~34 ~-10 ochre_froglight
setblock ~25 ~34 ~10 ochre_froglight
setblock ~25 ~34 ~15 ochre_froglight
setblock ~25 ~34 ~20 ochre_froglight
setblock ~25 ~34 ~25 ochre_froglight
setblock ~25 ~34 ~30 ochre_froglight
setblock ~25 ~34 ~35 ochre_froglight
setblock ~30 ~34 ~-30 ochre_froglight
setblock ~30 ~34 ~-25 ochre_froglight
setblock ~30 ~34 ~-20 ochre_froglight
setblock ~30 ~34 ~-15 ochre_froglight
setblock ~30 ~34 ~-10 ochre_froglight
setblock ~30 ~34 ~-5 ochre_froglight
setblock ~30 ~34 ~0 ochre_froglight
setblock ~30 ~34 ~5 ochre_froglight
setblock ~30 ~34 ~10 ochre_froglight
setblock ~30 ~34 ~15 ochre_froglight
setblock ~30 ~34 ~20 ochre_froglight
setblock ~30 ~34 ~25 ochre_froglight
setblock ~30 ~34 ~30 ochre_froglight
setblock ~35 ~34 ~-25 ochre_froglight
setblock ~35 ~34 ~-20 ochre_froglight
setblock ~35 ~34 ~-15 ochre_froglight
setblock ~35 ~34 ~-10 ochre_froglight
setblock ~35 ~34 ~-5 ochre_froglight
setblock ~35 ~34 ~0 ochre_froglight
setblock ~35 ~34 ~5 ochre_froglight
setblock ~35 ~34 ~10 ochre_froglight
setblock ~35 ~34 ~15 ochre_froglight
setblock ~35 ~34 ~20 ochre_froglight
setblock ~35 ~34 ~25 ochre_froglight
setblock ~40 ~34 ~-20 ochre_froglight
setblock ~40 ~34 ~-15 ochre_froglight
setblock ~40 ~34 ~-10 ochre_froglight
setblock ~40 ~34 ~-5 ochre_froglight
setblock ~40 ~34 ~0 ochre_froglight
setblock ~40 ~34 ~5 ochre_froglight
setblock ~40 ~34 ~10 ochre_froglight
setblock ~40 ~34 ~15 ochre_froglight
setblock ~40 ~34 ~20 ochre_froglight
fill ~-2 ~33 ~-25 ~2 ~34 ~-25 smooth_quartz
fill ~-7 ~33 ~-24 ~7 ~34 ~-24 smooth_quartz
fill ~-10 ~33 ~-23 ~-7 ~34 ~-23 smooth_quartz
fill ~7 ~33 ~-23 ~10 ~34 ~-23 smooth_quartz
fill ~-12 ~33 ~-22 ~-10 ~34 ~-22 smooth_quartz
fill ~10 ~33 ~-22 ~12 ~34 ~-22 smooth_quartz
fill ~-13 ~33 ~-21 ~-12 ~34 ~-21 smooth_quartz
fill ~12 ~33 ~-21 ~13 ~34 ~-21 smooth_quartz
fill ~-15 ~33 ~-20 ~-13 ~34 ~-20 smooth_quartz
fill ~13 ~33 ~-20 ~15 ~34 ~-20 smooth_quartz
fill ~-16 ~33 ~-19 ~-15 ~34 ~-19 smooth_quartz
fill ~15 ~33 ~-19 ~16 ~34 ~-19 smooth_quartz
fill ~-17 ~33 ~-18 ~-16 ~34 ~-18 smooth_quartz
fill ~16 ~33 ~-18 ~17 ~34 ~-18 smooth_quartz
fill ~-18 ~33 ~-17 ~-17 ~34 ~-17 smooth_quartz
fill ~17 ~33 ~-17 ~18 ~34 ~-17 smooth_quartz
fill ~-19 ~33 ~-16 ~-18 ~34 ~-16 smooth_quartz
fill ~18 ~33 ~-16 ~19 ~34 ~-16 smooth_quartz
fill ~-20 ~33 ~-15 ~-19 ~34 ~-15 smooth_quartz
fill ~19 ~33 ~-15 ~20 ~34 ~-15 smooth_quartz
fill ~-20 ~33 ~-14 ~-20 ~34 ~-14 smooth_quartz
fill ~20 ~33 ~-14 ~20 ~34 ~-14 smooth_quartz
fill ~-21 ~33 ~-13 ~-20 ~34 ~-13 smooth_quartz
fill ~20 ~33 ~-13 ~21 ~34 ~-13 smooth_quartz
fill ~-22 ~33 ~-12 ~-21 ~34 ~-12 smooth_quartz
fill ~21 ~33 ~-12 ~22 ~34 ~-12 smooth_quartz
fill ~-22 ~33 ~-11 ~-22 ~34 ~-11 smooth_quartz
fill ~22 ~33 ~-11 ~22 ~34 ~-11 smooth_quartz
fill ~-23 ~33 ~-10 ~-22 ~34 ~-10 smooth_quartz
fill ~22 ~33 ~-10 ~23 ~34 ~-10 smooth_quartz
fill ~-23 ~33 ~-9 ~-23 ~34 ~-9 smooth_quartz
fill ~23 ~33 ~-9 ~23 ~34 ~-9 smooth_quartz
fill ~-23 ~33 ~-8 ~-23 ~34 ~-8 smooth_quartz
fill ~23 ~33 ~-8 ~23 ~34 ~-8 smooth_quartz
fill ~-24 ~33 ~-7 ~-23 ~34 ~-7 smooth_quartz
fill ~23 ~33 ~-7 ~24 ~34 ~-7 smooth_quartz
fill ~-24 ~33 ~-6 ~-24 ~34 ~-6 smooth_quartz
fill ~24 ~33 ~-6 ~24 ~34 ~-6 smooth_quartz
fill ~-24 ~33 ~-5 ~-24 ~34 ~-5 smooth_quartz
fill ~24 ~33 ~-5 ~24 ~34 ~-5 smooth_quartz
fill ~-24 ~33 ~-4 ~-24 ~34 ~-4 smooth_quartz
fill ~24 ~33 ~-4 ~24 ~34 ~-4 smooth_quartz
fill ~-24 ~33 ~-3 ~-24 ~34 ~-3 smooth_quartz
fill ~24 ~33 ~-3 ~24 ~34 ~-3 smooth_quartz
fill ~-25 ~33 ~-2 ~-24 ~34 ~-2 smooth_quartz
fill ~24 ~33 ~-2 ~25 ~34 ~-2 smooth_quartz
fill ~-25 ~33 ~-1 ~-24 ~34 ~-1 smooth_quartz
fill ~24 ~33 ~-1 ~25 ~34 ~-1 smooth_quartz
fill ~-25 ~33 ~0 ~-24 ~34 ~0 smooth_quartz
fill ~24 ~33 ~0 ~25 ~34 ~0 smooth_quartz
fill ~-25 ~33 ~1 ~-24 ~34 ~1 smooth_quartz
fill ~24 ~33 ~1 ~25 ~34 ~1 smooth_quartz
fill ~-25 ~33 ~2 ~-24 ~34 ~2 smooth_quartz
fill ~24 ~33 ~2 ~25 ~34 ~2 smooth_quartz
fill ~-24 ~33 ~3 ~-24 ~34 ~3 smooth_quartz
fill ~24 ~33 ~3 ~24 ~34 ~3 smooth_quartz
fill ~-24 ~33 ~4 ~-24 ~34 ~4 smooth_quartz
fill ~24 ~33 ~4 ~24 ~34 ~4 smooth_quartz
fill ~-24 ~33 ~5 ~-24 ~34 ~5 smooth_quartz
fill ~24 ~33 ~5 ~24 ~34 ~5 smooth_quartz
fill ~-24 ~33 ~6 ~-24 ~34 ~6 smooth_quartz
fill ~24 ~33 ~6 ~24 ~34 ~6 smooth_quartz
fill ~-24 ~33 ~7 ~-23 ~34 ~7 smooth_quartz
fill ~23 ~33 ~7 ~24 ~34 ~7 smooth_quartz
fill ~-23 ~33 ~8 ~-23 ~34 ~8 smooth_quartz
fill ~23 ~33 ~8 ~23 ~34 ~8 smooth_quartz
fill ~-23 ~33 ~9 ~-23 ~34 ~9 smooth_quartz
fill ~23 ~33 ~9 ~23 ~34 ~9 smooth_quartz
fill ~-23 ~33 ~10 ~-22 ~34 ~10 smooth_quartz
fill ~22 ~33 ~10 ~23 ~34 ~10 smooth_quartz
fill ~-22 ~33 ~11 ~-22 ~34 ~11 smooth_quartz
fill ~22 ~33 ~11 ~22 ~34 ~11 smooth_quartz
fill ~-22 ~33 ~12 ~-21 ~34 ~12 smooth_quartz
fill ~21 ~33 ~12 ~22 ~34 ~12 smooth_quartz
fill ~-21 ~33 ~13 ~-20 ~34 ~13 smooth_quartz
fill ~20 ~33 ~13 ~21 ~34 ~13 smooth_quartz
fill ~-20 ~33 ~14 ~-20 ~34 ~14 smooth_quartz
fill ~20 ~33 ~14 ~20 ~34 ~14 smooth_quartz
fill ~-20 ~33 ~15 ~-19 ~34 ~15 smooth_quartz
fill ~19 ~33 ~15 ~20 ~34 ~15 smooth_quartz
fill ~-19 ~33 ~16 ~-18 ~34 ~16 smooth_quartz
fill ~18 ~33 ~16 ~19 ~34 ~16 smooth_quartz
fill ~-18 ~33 ~17 ~-17 ~34 ~17 smooth_quartz
fill ~17 ~33 ~17 ~18 ~34 ~17 smooth_quartz
fill ~-17 ~33 ~18 ~-16 ~34 ~18 smooth_quartz
fill ~16 ~33 ~18 ~17 ~34 ~18 smooth_quartz
fill ~-16 ~33 ~19 ~-15 ~34 ~19 smooth_quartz
fill ~15 ~33 ~19 ~16 ~34 ~19 smooth_quartz
fill ~-15 ~33 ~20 ~-13 ~34 ~20 smooth_quartz
fill ~13 ~33 ~20 ~15 ~34 ~20 smooth_quartz
fill ~-13 ~33 ~21 ~-12 ~34 ~21 smooth_quartz
fill ~12 ~33 ~21 ~13 ~34 ~21 smooth_quartz
fill ~-12 ~33 ~22 ~-10 ~34 ~22 smooth_quartz
fill ~10 ~33 ~22 ~12 ~34 ~22 smooth_quartz
fill ~-10 ~33 ~23 ~-7 ~34 ~23 smooth_quartz
fill ~7 ~33 ~23 ~10 ~34 ~23 smooth_quartz
fill ~-7 ~33 ~24 ~7 ~34 ~24 smooth_quartz
fill ~-2 ~33 ~25 ~2 ~34 ~25 smooth_quartz
